//
//  ContentView.swift
//  gsdk-example
//
//  Created by Lee Seongjik on 2021-05-10.
//

import SwiftUI
import UIKit
import NIO
import NIOSSL
import GRPC
import SwiftProtobuf
import NIOHTTP2
import NIOHTTP1
import NIOHPACK

let gatewayAddr: String = "192.168.28.111"
let gatewayPort: Int = 4000

let deviceAddr: String = "192.168.28.162"
let devicePort: Int32 = 51211
let useSSL: Bool = false

func setupTLS() -> ClientConnection? {
    do {
        //Step i: get certificate path from Bundle
        let certificatePath = Bundle.main.path(forResource: "ca", ofType: "crt")
        //Step ii: create TLS configuration
        var configuration = TLSConfiguration.forClient(applicationProtocols: ["h2"])
        configuration.trustRoots = .file(certificatePath!) //anchors the ca certificate to trust roots for TLS configuration. Not required incase of insecure communication with host
        //Step iii: generate SSL context
        let sslContext = try NIOSSLContext(configuration: configuration)
        let handler = try NIOSSLClientHandler(context: sslContext, serverHostname: gatewayAddr + "\(gatewayPort)")
        //Step iv: Create an event loop group
        let group = MultiThreadedEventLoopGroup(numberOfThreads: 1)
        //Step v: Create client connection builder
        let builder: ClientConnection.Builder
        builder = ClientConnection.secure(group: group).withTLS(trustRoots: configuration.trustRoots!)
        //Step vi: Start the connection and create the client
        let connection = builder.connect(host: gatewayAddr, port: gatewayPort)
        print("Connection Status=>:\(connection)")
        
        return connection
    }
    catch {
        print("Cannot connect to the gateway: \(error)")
        return nil
    }
}

let maxNumOfLog = 2
var numOfLog = 0

func test(conn: ClientConnection, view: ContentView) {
    let connectSvc = ConnectSvc(conn: conn)
    if let devList = connectSvc.getDeviceList() {
        view.setMsg(msg: String(format: "Device list: %@", devList.description))
    }

    var connInfo = Gsdk_Connect_ConnectInfo.with{
        $0.ipaddr = deviceAddr
        $0.port = devicePort
        $0.useSsl = useSSL
    }
    
    let deviceID = connectSvc.connect(connInfo: connInfo)
    
    if let devList = connectSvc.getDeviceList() {
        view.setMsg(msg: String(format: "Device list after connecting to %d: %@", deviceID, devList.description))
    }
    
    view.setCmd(cmd: String(format: "Generate %d real time events...", maxNumOfLog))

    let eventSvc = EventSvc(conn: conn)
    eventSvc.startMonitoring(deviceID: deviceID)
    eventSvc.subscribeRealtimeLog(deviceID: deviceID, callback: view.eventCallback)
    eventSvc.stopMonitoring(deviceID: deviceID)
    
    connectSvc.disconnectAll()
    
    view.setCmd(cmd: "Finished.")
}

struct ContentView: View {
    @State private var gateway: String =  String(format:"%@:%d", gatewayAddr, gatewayPort)
    @State private var device: String = String(format:"%@:%d", deviceAddr, devicePort)
    @State private var cmd: String = "Press Connect to start the test"
    @State private var msg: String = ""
    @State private var buttonDisabled = false
    
    func setCmd(cmd: String) {
        DispatchQueue.main.async{
            self.cmd = cmd
        }
    }
    
    func setMsg(msg: String) {
        DispatchQueue.main.async{
            self.msg = msg
        }
    }
    
    func eventCallback(eventLog: Gsdk_Event_EventLog) -> Bool {
        setMsg(msg: String(format: "Event: %@", eventLog.debugDescription))
        
        numOfLog += 1
        
        return (numOfLog >= maxNumOfLog)
    }
    
    var body: some View {
        VStack() {
            HStack {
                Label("Gateway", systemImage:"bolt.fill")
                    .frame(width: 80.0, alignment: .leading)
                    .labelStyle(TitleOnlyLabelStyle())
                    .font(.headline)
                Spacer()
                TextField("Gateway", text: $gateway)
            }
            HStack {
                Label("Device", systemImage:"bolt.fill")
                    .frame(width: 80.0, alignment: .leading)
                    .labelStyle(TitleOnlyLabelStyle())
                    .font(.headline)
                Spacer()
                TextField("Device", text: $device)
            }
            TextEditor(text: $msg)
            Spacer()
            Button("Connect") {
                msg = "Connecting..."
                buttonDisabled = true
                DispatchQueue.global(qos: .background).async {
                    if let connection = setupTLS() {
                        test(conn: connection, view: self)
                    }
                }
            }
            .foregroundColor(.white)
            .padding()
            .background(Color.accentColor)
            .cornerRadius(8)
            .disabled(buttonDisabled)

            TextField("Command", text: $cmd)
 
        }.padding(5)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
        }
    }
}
