//
//  gsdk_exampleApp.swift
//  gsdk-example
//
//  Created by Lee Seongjik on 2021-05-10.
//

import SwiftUI

@main
struct gsdk_exampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
