//
//  EventSvc.swift
//  gsdk-example
//
//  Created by Lee Seongjik on 2021-05-10.
//

import GRPC

let queueSize: Int32 = 16

class EventSvc {
    var client: Gsdk_Event_EventClient
    
    init(conn: ClientConnection) {
        self.client = Gsdk_Event_EventClient(channel: conn)
    }
    
    func startMonitoring(deviceID: UInt32) {
        do {
            let request = Gsdk_Event_EnableMonitoringRequest.with{
                $0.deviceID = deviceID
            }
            try client.enableMonitoring(request).response.wait()
        }
        catch {
            print("Cannot enable monitoring: \(error)")
        }
    }

    func stopMonitoring(deviceID: UInt32) {
        do {
            let request = Gsdk_Event_DisableMonitoringRequest.with{
                $0.deviceID = deviceID
            }
            try client.disableMonitoring(request).response.wait()
        }
        catch {
            print("Cannot disable monitoring: \(error)")
        }
    }
    
    func subscribeRealtimeLog(deviceID: UInt32, callback: @escaping ((Gsdk_Event_EventLog) -> Bool)) {
        do {
            let request = Gsdk_Event_SubscribeRealtimeLogRequest.with{
                $0.queueSize = queueSize
                $0.deviceIds = [deviceID]
            }
            
            var call: ServerStreamingCall<Gsdk_Event_SubscribeRealtimeLogRequest, Gsdk_Event_EventLog>?
            call = client.subscribeRealtimeLog(request) { eventLog in
                let stop = callback(eventLog)
                if(stop) {
                    call?.cancel(promise: nil)
                }
            }
            try call?.status.wait()
        }
        catch {
            print("Cannot subscribe realtime log: \(error)")
        }
    }
}
