//
//  ConnectSvc.swift
//  gsdk-example
//
//  Created by Lee Seongjik on 2021-05-10.
//

import GRPC

class ConnectSvc {
    var client: Gsdk_Connect_ConnectClient
    
    init(conn: ClientConnection) {
        self.client = Gsdk_Connect_ConnectClient(channel: conn)
    }
    
    func getDeviceList() -> [Gsdk_Connect_DeviceInfo]? {
        do {
            let request = Gsdk_Connect_GetDeviceListRequest()
            let response = try client.getDeviceList(request).response.wait()
            
            return response.deviceInfos
        }
        catch {
            print("Cannot get the device list: \(error)")
            return nil
        }
    }
    
    func connect(connInfo: Gsdk_Connect_ConnectInfo) -> UInt32 {
        do {
            let request = Gsdk_Connect_ConnectRequest.with {
                $0.connectInfo = connInfo
            }
            let response = try client.connect(request).response.wait()
            
            return response.deviceID
        }
        catch {
            print("Cannot connect to the device: \(error)")
            return 0
        }
    }
    
    func disconnectAll() {
        do {
            let request = Gsdk_Connect_DisconnectAllRequest()
            try client.disconnectAll(request).response.wait()
        }
        catch {
            print("Cannot disconnect all devices: \(error)")
        }
    }
}
