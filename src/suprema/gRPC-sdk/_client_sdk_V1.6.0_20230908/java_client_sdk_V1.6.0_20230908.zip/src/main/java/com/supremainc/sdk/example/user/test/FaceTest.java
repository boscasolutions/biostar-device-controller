package com.supremainc.sdk.example.user.test;

import java.util.List;
import java.util.ArrayList;

import com.supremainc.sdk.face.FaceData;
import com.supremainc.sdk.face.FaceEnrollThreshold;
import com.supremainc.sdk.example.face.FaceSvc;
import com.supremainc.sdk.user.UserFace;
import com.supremainc.sdk.example.user.UserSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class FaceTest {
  private FaceSvc faceSvc;
  private UserSvc userSvc;

  public FaceTest(FaceSvc faceSvc, UserSvc userSvc) {
    this.faceSvc = faceSvc;
    this.userSvc = userSvc;
  }

  public void test(int deviceID, String userID) throws Exception {
    System.out.printf("\n===== Face Test =====\n\n");

    System.out.printf(">> Enroll a unregistered face on the device...\n");

    FaceData faceData = faceSvc.scan(deviceID, FaceEnrollThreshold.BS2_FACE_ENROLL_THRESHOLD_DEFAULT);

    List<UserFace> userFaces = new ArrayList<UserFace>();
    userFaces.add(UserFace.newBuilder().setUserID(userID).addFaces(faceData).build());

    userSvc.setFace(deviceID, userFaces);

    KeyInput.pressEnter(">> Try to authenticate the enrolled face. And, press ENTER to end the test.\n");
  }
}

