package com.supremainc.sdk.example.sync;

import java.util.List;
import java.util.ArrayList;

import com.supremainc.sdk.user.UserHdr;
import com.supremainc.sdk.user.UserInfo;
import com.supremainc.sdk.card.CardData;
import com.supremainc.sdk.event.EventLog;
import com.supremainc.sdk.err.MultiErrorResponse;

import com.supremainc.sdk.example.user.UserSvc;
import com.supremainc.sdk.example.card.CardSvc;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.event.EventCallback;
import com.supremainc.sdk.example.err.ErrSvc;

class UserMgr implements EventCallback{
  private UserSvc userSvc;
  private CardSvc cardSvc;
  private TestConfig testConfig;
  private DeviceMgr devMgr;
  private EventMgr eventMgr;

  private List<String> enrolledIDs;

  private static final int BS2_EVENT_USER_ENROLL_SUCCESS = 0x2000;
  private static final int BS2_EVENT_USER_UPDATE_SUCCESS = 0x2200;
  private static final int BS2_EVENT_USER_DELETE_SUCCESS = 0x2400;
  private static final int BS2_EVENT_USER_DELETE_ALL_SUCCESS = 0x2600;

  public UserMgr(UserSvc userSvc, CardSvc cardSvc, TestConfig config, DeviceMgr devMgr, EventMgr eventMgr) {
    this.userSvc = userSvc;
    this.cardSvc = cardSvc;
    this.testConfig = config;
    this.devMgr = devMgr;
    this.eventMgr = eventMgr;

    enrolledIDs = new ArrayList<String>();
  }

  public void enrollUser(String userID) throws Exception {
    int enrollDeviceID = testConfig.getEnrollDevice().getDeviceID();

    System.out.printf(">>> Place a unregistered CSN card on the device %d...\n", enrollDeviceID);

    CardData cardData = cardSvc.scan(enrollDeviceID);

    if(cardData.getCSNCardData() == null) {
      System.out.printf("This test does not support a smart card\n");
      return;
    }

    List<UserInfo> newUsers = new ArrayList<UserInfo>();
    UserHdr hdr = UserHdr.newBuilder().setID(userID).setNumOfCard(1).build();
    newUsers.add(UserInfo.newBuilder().setHdr(hdr).addCards(cardData.getCSNCardData()).build());

    userSvc.enroll(enrollDeviceID, newUsers);
  }

  public void deleteUser(String userID) throws Exception {
    List<String> userIDs = new ArrayList<String>();
    userIDs.add(userID);

    userSvc.delete(testConfig.getEnrollDevice().getDeviceID(), userIDs);
  }

  public List<UserInfo> getNewUser(int deviceID) throws Exception {
    if(enrolledIDs.size() == 0) {
      System.out.printf("No new user\n");
      return new ArrayList<UserInfo>();
    }

    return userSvc.getUser(deviceID, enrolledIDs);
  }

  public void syncUser(EventLog eventLog) throws Exception {
    // Handle only the events of the enrollment device
    if(eventLog.getDeviceID() != testConfig.getEnrollDevice().getDeviceID()) {
      return;
    }

    List<Integer> connectedIDs = devMgr.getConnectedDevices(false);
    List<Integer> targetDeviceIDs = testConfig.getTargetDeviceIDs(connectedIDs);

    if(targetDeviceIDs.size() == 0) {
      System.out.printf("No device to sync\n");
      return;
    }

    if(eventLog.getEventCode() == BS2_EVENT_USER_ENROLL_SUCCESS || eventLog.getEventCode() == BS2_EVENT_USER_UPDATE_SUCCESS) {
      System.out.printf("Trying to synchronize the enrolled user %s...\n", eventLog.getUserID());

      List<String> userIDs = new ArrayList<String>();
      userIDs.add(eventLog.getUserID());
      List<UserInfo> newUserInfos = userSvc.getUser(eventLog.getDeviceID(), userIDs);

      try {
        userSvc.enrollMulti(targetDeviceIDs, newUserInfos);
      } catch (Exception e) {
        MultiErrorResponse deviceErrs = ErrSvc.getMultiError(e);
        System.out.printf("Enroll errors: %s", deviceErrs);
      } 

      if(!enrolledIDs.contains(eventLog.getUserID())) {
        enrolledIDs.add(eventLog.getUserID());
      }

      // Generate a MultiErrorResponse 
		  // It should fail since the users are duplicated.
/*      try {
        userSvc.enrollMulti(targetDeviceIDs, newUserInfos);
      } catch (Exception e) {
        MultiErrorResponse deviceErrs = ErrSvc.getMultiError(e);
        System.out.printf("Multi errors: %s", deviceErrs);
      } */
    } else if(eventLog.getEventCode() == BS2_EVENT_USER_DELETE_SUCCESS) {
      System.out.printf("Trying to synchronize the deleted user %s...\n", eventLog.getUserID());

      List<String> userIDs = new ArrayList<String>();
      userIDs.add(eventLog.getUserID());
      userSvc.deleteMulti(targetDeviceIDs, userIDs);

      enrolledIDs.remove(eventLog.getUserID());      
    } else if(eventLog.getEventCode() == BS2_EVENT_USER_DELETE_ALL_SUCCESS) {
      System.out.printf("Trying to synchronize deleting all users...\n");

      userSvc.deleteAllMulti(targetDeviceIDs);

      enrolledIDs.clear();
    }
  }

  public void handle(EventLog event) {
    eventMgr.printEvent(event);

    try {
      syncUser(event);
    } catch (Exception e) {
      System.out.printf("Cannot synchronize the user: %s", e); 
    }
  }
}