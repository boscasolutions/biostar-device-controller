package com.supremainc.sdk.example.rs485;

import java.util.List;

import com.supremainc.sdk.rs485.RS485Config;
import com.supremainc.sdk.rs485.RS485Grpc;
import com.supremainc.sdk.rs485.SlaveDeviceInfo;
import com.supremainc.sdk.rs485.GetConfigRequest;
import com.supremainc.sdk.rs485.GetConfigResponse;
import com.supremainc.sdk.rs485.SetConfigRequest;
import com.supremainc.sdk.rs485.SearchDeviceRequest;
import com.supremainc.sdk.rs485.SearchDeviceResponse;
import com.supremainc.sdk.rs485.GetDeviceRequest;
import com.supremainc.sdk.rs485.GetDeviceResponse;
import com.supremainc.sdk.rs485.SetDeviceRequest;


public class RS485Svc {
  private final RS485Grpc.RS485BlockingStub rs485Stub;

  public RS485Svc(RS485Grpc.RS485BlockingStub stub) {
    rs485Stub = stub;
  }

  public RS485Config getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = rs485Stub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, RS485Config config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    rs485Stub.setConfig(request);
  }

  public List<SlaveDeviceInfo> searchSlave(int deviceID) throws Exception {
    SearchDeviceRequest request = SearchDeviceRequest.newBuilder().setDeviceID(deviceID).build();
    SearchDeviceResponse response = rs485Stub.searchDevice(request);

    return response.getSlaveInfosList();
  }

  public List<SlaveDeviceInfo> getSlave(int deviceID) throws Exception {
    GetDeviceRequest request = GetDeviceRequest.newBuilder().setDeviceID(deviceID).build();
    GetDeviceResponse response = rs485Stub.getDevice(request);

    return response.getSlaveInfosList();
  }

  public void setSlave(int deviceID, List<SlaveDeviceInfo> slaveInfos) throws Exception {
    SetDeviceRequest request = SetDeviceRequest.newBuilder().setDeviceID(deviceID).addAllSlaveInfos(slaveInfos).build();
    rs485Stub.setDevice(request);
  }
}