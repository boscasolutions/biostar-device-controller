package com.supremainc.sdk.example.err;

import com.supremainc.sdk.err.MultiErrorResponse;
import com.google.protobuf.Any;
import com.google.rpc.Status;
import io.grpc.protobuf.StatusProto;

public class ErrSvc {
  static public MultiErrorResponse getMultiError(Exception e) {
    Status status = StatusProto.fromThrowable(e);
    MultiErrorResponse response = null;

    for(Any any: status.getDetailsList()) {
      if(any.is(MultiErrorResponse.class)) {
        try {
          response = any.unpack(MultiErrorResponse.class);
        } catch (Exception ge) {
          System.out.printf("Cannot unpack MultiErrorResponse: %s", ge); 
        }
        break;
      }
    }

    return response;
  }
}