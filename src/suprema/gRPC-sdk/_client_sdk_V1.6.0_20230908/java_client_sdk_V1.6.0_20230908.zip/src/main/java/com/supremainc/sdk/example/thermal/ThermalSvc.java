package com.supremainc.sdk.example.thermal;

import java.util.List;

import com.supremainc.sdk.thermal.ThermalConfig;
import com.supremainc.sdk.thermal.ThermalGrpc;
import com.supremainc.sdk.thermal.GetConfigRequest;
import com.supremainc.sdk.thermal.GetConfigResponse;
import com.supremainc.sdk.thermal.SetConfigRequest;
import com.supremainc.sdk.thermal.SetConfigResponse;
import com.supremainc.sdk.thermal.TemperatureLog;
import com.supremainc.sdk.thermal.GetTemperatureLogRequest;
import com.supremainc.sdk.thermal.GetTemperatureLogResponse;

public class ThermalSvc {
  private final ThermalGrpc.ThermalBlockingStub thermalStub;

  public ThermalSvc(ThermalGrpc.ThermalBlockingStub stub) {
    thermalStub = stub;
  }

  public ThermalConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = thermalStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, ThermalConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = thermalStub.setConfig(request);
  }

  public List<TemperatureLog> getTemperatureLog(int deviceID, int startEventID, int maxNumOfLog) throws Exception {
    GetTemperatureLogRequest request = GetTemperatureLogRequest.newBuilder().setDeviceID(deviceID).setStartEventID(startEventID).setMaxNumOfLog(maxNumOfLog).build();
    GetTemperatureLogResponse response = thermalStub.getTemperatureLog(request);
 
    return response.getTemperatureEventsList();
  } 
}