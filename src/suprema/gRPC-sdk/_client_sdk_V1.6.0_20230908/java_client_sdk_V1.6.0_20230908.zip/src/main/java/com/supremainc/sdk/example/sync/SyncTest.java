package com.supremainc.sdk.example.sync;

import java.util.List;

import com.supremainc.sdk.connect.ConnectGrpc;
import com.supremainc.sdk.user.UserGrpc;
import com.supremainc.sdk.card.CardGrpc;
import com.supremainc.sdk.event.EventGrpc;
import com.supremainc.sdk.example.client.GatewayClient;
import com.supremainc.sdk.example.connect.ConnectSvc;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.user.UserSvc;
import com.supremainc.sdk.example.card.CardSvc;
import com.supremainc.sdk.example.cli.KeyInput;

public class SyncTest {
  private static final String GATEWAY_CA_FILE = "cert/gateway/ca.crt";
  private static final String GATEWAY_ADDR = "192.168.0.2";
  private static final int GATEWAY_PORT = 4000;

  private static final String SYNC_CONFIG_FILE = "./sync_config.json";
  private static final String CODE_MAP_FILE = "./event_code.json";

  private GatewayClient gatewayClient;
  private ConnectSvc connectSvc;
  private UserSvc userSvc;
  private CardSvc cardSvc;
  private EventSvc eventSvc;  
  private DeviceMgr deviceMgr;
  private EventMgr eventMgr;  
  private UserMgr userMgr; 

  public SyncTest(GatewayClient client, TestConfig config) {
    gatewayClient = client;

    connectSvc = new ConnectSvc(ConnectGrpc.newBlockingStub(client.getChannel())); 
    userSvc = new UserSvc(UserGrpc.newBlockingStub(client.getChannel()));  
    cardSvc = new CardSvc(CardGrpc.newBlockingStub(client.getChannel()));
    eventSvc = new EventSvc(EventGrpc.newBlockingStub(client.getChannel()));
    try {
      eventSvc.initCodeMap(CODE_MAP_FILE);
    } catch (Exception e) {
      System.out.printf("Cannot initialize the event map file: %s", e); 
    }

    deviceMgr = new DeviceMgr(connectSvc, config);
    eventMgr = new EventMgr(eventSvc, config);
    userMgr = new UserMgr(userSvc, cardSvc, config, deviceMgr, eventMgr);
  }  

  public static void main(String[] args) throws Exception {
    GatewayClient client = new GatewayClient();

    try {
      client.connect(GATEWAY_CA_FILE, GATEWAY_ADDR, GATEWAY_PORT);
    } catch (Exception e) {
      System.out.printf("Cannot connect to the gateway: %s", e); 
      System.exit(-1);
    }

    TestConfig config = new TestConfig();

    try {
      config.read(SYNC_CONFIG_FILE);
    } catch (Exception e) {
      System.out.printf("Cannot read the configuration file %s: %s", SYNC_CONFIG_FILE, e); 
      System.exit(-1);
    } 

    SyncTest syncTest = new SyncTest(client, config);

    try {
      System.out.printf("Trying to connect to the devices...\n");

      syncTest.deviceMgr.handleConnection(syncTest.eventMgr);
      syncTest.deviceMgr.connectToDevices();
      syncTest.eventMgr.handleEvent(syncTest.userMgr);

      KeyInput.pressEnter("\n>>> Press ENTER to show the test menu\n\n");      

      new TestMenu(syncTest.deviceMgr, syncTest.eventMgr, syncTest.userMgr, config).show();

    } catch (Exception e) {
      System.out.printf("Cannot complete the synchronization test: %s", e); 
      e.printStackTrace(System.out);
    } finally {
      syncTest.deviceMgr.deleteConnection();
      syncTest.eventMgr.stopHandleEvent();
      client.close();
    }
  }
}