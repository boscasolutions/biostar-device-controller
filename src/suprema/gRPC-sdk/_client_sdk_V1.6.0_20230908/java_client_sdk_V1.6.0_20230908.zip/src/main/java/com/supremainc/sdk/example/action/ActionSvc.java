package com.supremainc.sdk.example.action;

import com.supremainc.sdk.action.TriggerActionConfig;
import com.supremainc.sdk.action.TriggerActionGrpc;
import com.supremainc.sdk.action.GetConfigRequest;
import com.supremainc.sdk.action.GetConfigResponse;
import com.supremainc.sdk.action.SetConfigRequest;
import com.supremainc.sdk.action.SetConfigResponse;

public class ActionSvc {
  private final TriggerActionGrpc.TriggerActionBlockingStub actionStub;

  public ActionSvc(TriggerActionGrpc.TriggerActionBlockingStub stub) {
    actionStub = stub;
  }

  public TriggerActionConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = actionStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, TriggerActionConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = actionStub.setConfig(request);
  }
}