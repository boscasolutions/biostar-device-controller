package com.supremainc.sdk.example.quick;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.supremainc.sdk.example.user.UserSvc;
import com.google.protobuf.ByteString;
import com.supremainc.sdk.device.CapabilityInfo;
import com.supremainc.sdk.example.finger.FingerSvc;
import com.supremainc.sdk.user.UserHdr;
import com.supremainc.sdk.user.UserInfo;
import com.supremainc.sdk.user.UserFinger;
import com.supremainc.sdk.finger.FingerData;
import com.supremainc.sdk.finger.TemplateFormat;
import com.supremainc.sdk.example.face.FaceSvc;
import com.supremainc.sdk.user.UserFace;
import com.supremainc.sdk.face.FaceData;
import com.supremainc.sdk.face.FaceEnrollThreshold;

class UserTest {
  private static final int NUM_OF_NEW_USER = 3;
  private static final int QUALITY_THRESHOLD = 50;

  private UserSvc userSvc;
  private FingerSvc fingerSvc;
  private FaceSvc faceSvc;

  public UserTest(UserSvc uSvc, FingerSvc fSvc, FaceSvc faceSvc) {
    userSvc = uSvc;
    fingerSvc = fSvc;
    this.faceSvc = faceSvc;
  }

  public void test(int deviceID, CapabilityInfo capabilityInfo) throws Exception {
    List<UserHdr> userHdrs = userSvc.getList(deviceID);

    System.out.printf("User list: \n%s\n\n", userHdrs);    

    List<String> userIDs = new ArrayList<String>();
    ListIterator<UserHdr> hdrIter = userHdrs.listIterator();

    while(hdrIter.hasNext()) {
      userIDs.add(hdrIter.next().getID());
    }

    List<UserInfo> userInfos = userSvc.getUser(deviceID, userIDs);
    ListIterator<UserInfo> userIter = userInfos.listIterator();

    while(userIter.hasNext()) {
      UserInfo info = userIter.next();
      System.out.printf("User: %s\n%s%s\n", info.getName(), info.getHdr(), info.getSetting());
    }

    List<UserInfo> newUsers = new ArrayList<UserInfo>();
    List<String> newUserIDs = new ArrayList<String>();

    for(int i = 0; i < NUM_OF_NEW_USER; i++) {
      UserHdr hdr = UserHdr.newBuilder().setID(String.format("%d", (int)(Math.random() * Integer.MAX_VALUE))).build();
      newUsers.add(UserInfo.newBuilder().setHdr(hdr).build());
      newUserIDs.add(hdr.getID());
    }

    userSvc.enroll(deviceID, newUsers);
    
    userHdrs = userSvc.getList(deviceID);
    System.out.printf("User list after enrolling new users: \n%s\n\n", userHdrs);    

    if (capabilityInfo.getFingerSupported()) {
      try {
        testFinger(deviceID, newUserIDs.get(0));
      } catch (Exception e) {
        System.out.printf("Cannot comlete the fingerprint test: %s", e); 
      }
    }

    if (capabilityInfo.getFaceSupported()) {
      try {
        testFace(deviceID, newUserIDs.get(0));
      } catch (Exception e) {
        System.out.printf("Cannot comlete the face test: %s", e); 
      }
    }

    userSvc.delete(deviceID, newUserIDs);

    userHdrs = userSvc.getList(deviceID);
    System.out.printf("User list after deleting new users: \n%s\n\n", userHdrs);    
  }

  public void testFinger(int deviceID, String userID) throws Exception {
    List<String> userIDs = new ArrayList<String>();
    userIDs.add(userID);

    List<UserInfo> userInfos = userSvc.getUser(deviceID, userIDs);
    ListIterator<UserInfo> userIter = userInfos.listIterator();

    if(userIter.hasNext()) {
      System.out.printf("User without fingerprint:\n%s\n", userIter.next());
    }

    List<UserFinger> userFingers = new ArrayList<UserFinger>();
    List<ByteString> templateData = new ArrayList<ByteString>();
    
    System.out.printf(">>> Scan a finger for user %s\n", userID);
    templateData.add(fingerSvc.scan(deviceID, TemplateFormat.TEMPLATE_FORMAT_SUPREMA, QUALITY_THRESHOLD));

    System.out.printf(">>> Scan the same finger for user %s\n", userID);
    templateData.add(fingerSvc.scan(deviceID, TemplateFormat.TEMPLATE_FORMAT_SUPREMA, QUALITY_THRESHOLD));

    FingerData fingerData = FingerData.newBuilder().setIndex(0).setFlag(0).addAllTemplates(templateData).build();
    userFingers.add(UserFinger.newBuilder().setUserID(userID).addFingers(fingerData).build());

    userSvc.setFinger(deviceID, userFingers);

    userInfos = userSvc.getUser(deviceID, userIDs);
    userIter = userInfos.listIterator();

    if(userIter.hasNext()) {
      System.out.printf("User after adding fingerprints:\n%s\n", userIter.next());
    }
  }

  public void testFace(int deviceID, String userID) throws Exception {
    List<String> userIDs = new ArrayList<String>();
    userIDs.add(userID);

    List<UserInfo> userInfos = userSvc.getUser(deviceID, userIDs);
    ListIterator<UserInfo> userIter = userInfos.listIterator();

    if (userIter.hasNext()) {
      System.out.printf("User without face:\n%s\n", userIter.next());
    }

    List<UserFace> userFaces = new ArrayList<UserFace>();
    
    System.out.printf(">>> Scan a face for user %s\n", userID);

    FaceData faceData = faceSvc.scan(deviceID, FaceEnrollThreshold.BS2_FACE_ENROLL_THRESHOLD_DEFAULT);

    userFaces.add(UserFace.newBuilder().setUserID(userID).addFaces(faceData).build());

    userSvc.setFace(deviceID, userFaces);

    userInfos = userSvc.getUser(deviceID, userIDs);
    userIter = userInfos.listIterator();

    if(userIter.hasNext()) {
      System.out.printf("User after adding faces:\n%s\n", userIter.next());
    }
  }
}

