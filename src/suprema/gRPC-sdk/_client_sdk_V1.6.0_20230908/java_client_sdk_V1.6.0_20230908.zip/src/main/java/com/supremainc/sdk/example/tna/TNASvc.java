package com.supremainc.sdk.example.tna;

import java.util.List;

import com.supremainc.sdk.tna.TNAConfig;
import com.supremainc.sdk.tna.TNAGrpc;
import com.supremainc.sdk.tna.GetConfigRequest;
import com.supremainc.sdk.tna.GetConfigResponse;
import com.supremainc.sdk.tna.SetConfigRequest;
import com.supremainc.sdk.tna.SetConfigResponse;
import com.supremainc.sdk.tna.TNALog;
import com.supremainc.sdk.tna.GetTNALogRequest;
import com.supremainc.sdk.tna.GetTNALogResponse;

public class TNASvc {
  private final TNAGrpc.TNABlockingStub tnaStub;

  public TNASvc(TNAGrpc.TNABlockingStub stub) {
    tnaStub = stub;
  }

  public TNAConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = tnaStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, TNAConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = tnaStub.setConfig(request);
  }

  public List<TNALog> getTNALog(int deviceID, int startEventID, int maxNumOfLog) throws Exception {
    GetTNALogRequest request = GetTNALogRequest.newBuilder().setDeviceID(deviceID).setStartEventID(startEventID).setMaxNumOfLog(maxNumOfLog).build();
    GetTNALogResponse response = tnaStub.getTNALog(request);
 
    return response.getTNAEventsList();
  } 
}