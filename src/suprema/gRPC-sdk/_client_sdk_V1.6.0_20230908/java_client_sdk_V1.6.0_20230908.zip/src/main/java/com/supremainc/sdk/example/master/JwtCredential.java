package com.supremainc.sdk.example.master;

import io.grpc.CallCredentials;
import io.grpc.Metadata;
import io.grpc.Status;
import java.util.concurrent.Executor;

import static io.grpc.Metadata.ASCII_STRING_MARSHALLER;

/**
 * CallCredentials implementation, which carries the JWT value that will be propagated to the
 * server in the request metadata with the "Authorization" key and the "Bearer" prefix.
 */
public class JwtCredential extends CallCredentials {
  private static final Metadata.Key<String> JWT_TOKEN_KEY = Metadata.Key.of("token", ASCII_STRING_MARSHALLER);

  private String token;

  JwtCredential(String jwtToken) {
    this.token = jwtToken;
  }

  @Override
  public void applyRequestMetadata(final RequestInfo requestInfo, final Executor executor, final MetadataApplier metadataApplier) {
    executor.execute(new Runnable() {
      @Override
      public void run() {
        try {
          Metadata headers = new Metadata();
          headers.put(JWT_TOKEN_KEY, token);
          metadataApplier.apply(headers);
        } catch (Throwable e) {
          metadataApplier.fail(Status.UNAUTHENTICATED.withCause(e));
        }
      }
    });
  }

  @Override
  public void thisUsesUnstableApi() {
    // noop
  }
}
