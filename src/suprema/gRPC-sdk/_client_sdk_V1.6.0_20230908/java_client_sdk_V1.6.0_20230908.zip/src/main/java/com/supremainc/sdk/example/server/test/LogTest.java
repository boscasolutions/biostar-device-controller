package com.supremainc.sdk.example.server.test;

import java.time.Instant;

import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.event.EventCallback;
import com.supremainc.sdk.event.EventLog;

class LogTest implements EventCallback {
  private EventSvc eventSvc;

  public LogTest(EventSvc svc) {
    eventSvc = svc;
  }

  public void handle(EventLog eventLog) {
    System.out.printf("%s: Device %d, User %s, %s\n", Instant.ofEpochSecond(eventLog.getTimestamp()), eventLog.getDeviceID(), eventLog.getUserID(), eventSvc.getEventString(eventLog.getEventCode(), eventLog.getSubCode()));
  }
}

