package com.supremainc.sdk.example.sync;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.time.Instant;

import io.grpc.Context;
import io.grpc.Context.CancellableContext;

import com.supremainc.sdk.event.EventLog;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.event.EventCallback;


class EventMgr implements ConnectionCallback {
  private EventSvc eventSvc;
  private TestConfig testConfig;

  private CancellableContext monitoringCtx;
  private Context prevCtx;
  private Iterator<EventLog> eventStream;
  private EventCallback eventCallback;

  public static final int MAX_NUM_OF_LOG = 16384;

  public EventMgr(EventSvc svc, TestConfig config) {
    eventSvc = svc;
    testConfig = config;
  }

  public void handleEvent(EventCallback callback) throws Exception {
    eventSvc.setEventCallback(callback);
    eventSvc.startMonitoring();
  }  

  public void stopHandleEvent() throws Exception {
    eventSvc.stopMonitoring();
  }
  
  public List<EventLog> readNewLog(DeviceInfo devInfo, int maxNumOfLog) throws Exception {
    List<EventLog> eventLogs = eventSvc.getLog(devInfo.getDeviceID(), devInfo.getLastEventID() + 1, maxNumOfLog);

    if(eventLogs.size() > 0) {
      testConfig.updateLastEventID(devInfo.getDeviceID(), eventLogs.get(eventLogs.size() - 1).getID());
    }

    return eventLogs;
  }

  public void handleConnected(int deviceID) throws Exception {
    System.out.printf("***** Device %d is connected\n", deviceID);

    DeviceInfo dev = testConfig.getDeviceInfo(deviceID);
    if(dev == null) {
      System.out.printf("!!! Device %d is not in the configuration file", deviceID);
      return;
    }

    List<EventLog> eventLogs = new ArrayList<EventLog>();

    // read new logs
    while(true) {
      System.out.printf("[%d] Reading log records starting from %d...\n", deviceID, dev.getLastEventID());

      List<EventLog> newLogs = readNewLog(dev, MAX_NUM_OF_LOG);

      System.out.printf("[%d] Read %d events\n", deviceID, newLogs.size());

      eventLogs.addAll(newLogs);

      if(newLogs.size() < MAX_NUM_OF_LOG) { // read the last log
        break;
      }
    }

    // do something with the event logs
    // ...
    System.out.printf("[%d] The total number of new events: %d\n", deviceID, eventLogs.size());

    // enable real-time monitoring
    eventSvc.enableMonitoring(deviceID);
  }

  public void printEvent(EventLog event) {
    System.out.printf("[EVENT] %s: Device %d, User %s, %s\n", Instant.ofEpochSecond(event.getTimestamp()), event.getDeviceID(), event.getUserID(), eventSvc.getEventString(event.getEventCode(), event.getSubCode()));
  }
}