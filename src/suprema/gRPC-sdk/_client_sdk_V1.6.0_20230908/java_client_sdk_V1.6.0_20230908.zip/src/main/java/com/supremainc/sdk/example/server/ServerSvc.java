package com.supremainc.sdk.example.server;

import java.util.Iterator;

import com.supremainc.sdk.server.ServerGrpc;
import com.supremainc.sdk.server.ServerGrpc;
import com.supremainc.sdk.server.ServerRequest;
import com.supremainc.sdk.server.ServerErrorCode;
import com.supremainc.sdk.server.SubscribeRequest;
import com.supremainc.sdk.server.UnsubscribeRequest;
import com.supremainc.sdk.server.HandleVerifyRequest;
import com.supremainc.sdk.server.HandleIdentifyRequest;
import com.supremainc.sdk.user.UserInfo;

public class ServerSvc {
  private final ServerGrpc.ServerBlockingStub serverStub;

  public ServerSvc(ServerGrpc.ServerBlockingStub stub) {
    serverStub = stub;
  }

  public Iterator<ServerRequest> subscribe(int queueSize) throws Exception {
    SubscribeRequest request = SubscribeRequest.newBuilder().setQueueSize(queueSize).build();
    Iterator<ServerRequest> requestStream = serverStub.subscribe(request);

    return requestStream;
  }

  public void unsubscribe() throws Exception {
    UnsubscribeRequest request = UnsubscribeRequest.newBuilder().build();
    serverStub.unsubscribe(request);
  }

  public void handleVerify(ServerRequest serverReq, ServerErrorCode errCode, UserInfo userInfo) throws Exception {
    HandleVerifyRequest.Builder requestBuilder = HandleVerifyRequest.newBuilder()
                                                  .setDeviceID(serverReq.getDeviceID())
                                                  .setSeqNO(serverReq.getSeqNO())
                                                  .setErrCode(errCode);

    if(userInfo != null) {                                                  
      requestBuilder.setUser(userInfo);
    }

    serverStub.handleVerify(requestBuilder.build());
  }

  public void handleIdentify(ServerRequest serverReq, ServerErrorCode errCode, UserInfo userInfo) throws Exception {
    HandleIdentifyRequest.Builder requestBuilder = HandleIdentifyRequest.newBuilder()
                                                  .setDeviceID(serverReq.getDeviceID())
                                                  .setSeqNO(serverReq.getSeqNO())
                                                  .setErrCode(errCode);

    if(userInfo != null) {                                                  
      requestBuilder.setUser(userInfo);
    }

    serverStub.handleIdentify(requestBuilder.build());
  }
}


