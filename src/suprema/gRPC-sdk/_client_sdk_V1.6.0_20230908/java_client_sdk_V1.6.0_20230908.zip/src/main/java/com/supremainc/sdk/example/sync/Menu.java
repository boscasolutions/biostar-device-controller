package com.supremainc.sdk.example.sync;

import java.util.List;

import com.supremainc.sdk.event.EventLog;
import com.supremainc.sdk.user.UserInfo;

import com.supremainc.sdk.example.cli.Menu;
import com.supremainc.sdk.example.cli.MenuItem;
import com.supremainc.sdk.example.cli.MenuCallback;

class TestMenu {
  private Menu menu;

  private DeviceMgr devMgr;
  private EventMgr eventMgr;
  private UserMgr userMgr;
  private TestConfig testConfig;

  private static final String DEFAULT_USER_ID = "1234";
  private static final int MAX_NEW_LOG = 16;

  public TestMenu(DeviceMgr devMgr, EventMgr eventMgr, UserMgr userMgr, TestConfig config) {
    this.devMgr = devMgr;
    this.eventMgr = eventMgr;
    this.userMgr = userMgr;
    this.testConfig = config;

    MenuItem[] items = new MenuItem[6];

    items[0] = new MenuItem("1", "Show test devices", new ShowTestDevice(), false);
    items[1] = new MenuItem("2", "Show new events", new ShowNewEvent(), false);
    items[2] = new MenuItem("3", "Show new users", new ShowNewUser(), false);
    items[3] = new MenuItem("4", "Enroll a user", new EnrollUser(), false);
    items[4] = new MenuItem("5", "Delete a user", new DeleteUser(), false);
    items[5] = new MenuItem("q", "Quit", null, true);

    menu = new Menu(items);
  }

  public void show() {
    menu.show("Test Menu");    
  }

  public String getUserID() {
    String[] texts = new String[1];
    texts[0] = "Enter the user ID";
    
    String[] defaults = new String[1];
    defaults[0] = DEFAULT_USER_ID;

    String[] inputs = Menu.getUserInputs(texts, defaults);

    return inputs[0];
  }

  class ShowTestDevice implements MenuCallback {
    public void run() {
      System.out.printf("***** Test Configuration:\n%s\n\n", testConfig.getConfigData());
      try {
        System.out.printf("***** Connected Devices: %s\n", devMgr.getConnectedDevices(true));
      } catch (Exception e) {
        System.out.printf("Cannot get the device list: %s\n", e.getMessage());
      }
    }
  }

  class ShowNewEvent implements MenuCallback {
    public void run() {
      try {
        List<Integer> deviceIDs = devMgr.getConnectedDevices(false);
        for(int devID:deviceIDs) {
          DeviceInfo devInfo = testConfig.getDeviceInfo(devID);
          if(devInfo == null) {
            System.out.printf("Device %d is not in the configuration file\n", devID);
            continue;
          }

          System.out.printf("Read new event logs from device %d...\n", devID);
          List<EventLog> eventLogs = eventMgr.readNewLog(devInfo, EventMgr.MAX_NUM_OF_LOG);

          System.out.printf("Read %d event logs\n", eventLogs.size());

          int numOfLog = eventLogs.size();
          if(numOfLog > MAX_NEW_LOG) {
            numOfLog = MAX_NEW_LOG;
          }
      
          if(numOfLog > 0) {
            System.out.printf("Show the last %d events...\n", numOfLog);
            for(int i = 0; i < numOfLog; i++) {
              eventMgr.printEvent(eventLogs.get(numOfLog - i - 1));
            }
          }
        }
      } catch (Exception e) {
        System.out.printf("Cannot show the new events: %s\n", e.getMessage());
      }
    }
  }  

  class ShowNewUser implements MenuCallback {
    public void run() {
      try {
        List<Integer> deviceIDs = devMgr.getConnectedDevices(false);
        for(int devID:deviceIDs) {
          System.out.printf("Read new users from device %d...\n", devID);

          List<UserInfo> userInfos = userMgr.getNewUser(devID);
          System.out.printf("New users: %s\n", userInfos);
        }

      } catch (Exception e) {
        System.out.printf("Cannot show the new users: %s\n", e.getMessage());
      }
    }
  }  

  class EnrollUser implements MenuCallback {
    public void run() {
      try {
        userMgr.enrollUser(getUserID());
      } catch (Exception e) {
        System.out.printf("Cannot enroll user: %s\n", e.getMessage());
      }
    }
  }  

  class DeleteUser implements MenuCallback {
    public void run() {
      try {
        userMgr.deleteUser(getUserID());
      } catch (Exception e) {
        System.out.printf("Cannot delete user: %s\n", e.getMessage());
      }
    }
  }  

}


