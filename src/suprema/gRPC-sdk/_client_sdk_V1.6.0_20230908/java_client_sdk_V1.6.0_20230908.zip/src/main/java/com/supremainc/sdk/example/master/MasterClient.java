package com.supremainc.sdk.example.master;

import com.supremainc.sdk.example.client.GrpcClient;
import io.grpc.netty.NettyChannelBuilder;
import io.grpc.netty.GrpcSslContexts;
import io.netty.channel.ChannelOption;
import io.grpc.CallCredentials;
import io.grpc.CallOptions;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.supremainc.sdk.login.LoginGrpc;
import com.supremainc.sdk.login.LoginAdminRequest;
import com.supremainc.sdk.login.LoginAdminResponse;
import com.supremainc.sdk.login.LoginRequest;
import com.supremainc.sdk.login.LoginResponse;

import java.util.List;
import com.supremainc.sdk.tenant.TenantInfo;
import com.supremainc.sdk.tenant.TenantGrpc;
import com.supremainc.sdk.tenant.GetRequest;
import com.supremainc.sdk.tenant.GetResponse;
import com.supremainc.sdk.tenant.AddRequest;
import com.supremainc.sdk.tenant.AddResponse;

import java.io.File;

public class MasterClient extends GrpcClient {
  private static final String ADMIN_TENANT_ID = "administrator";
  private CallCredentials credentials;

  public CallCredentials getCredentials() {
    return credentials;
  }

  public void connectAdmin(String caCertFile, String adminCertFile, String adminKeyFile, String masterAddr, int masterPort) throws Exception {
    channel = NettyChannelBuilder.forAddress(masterAddr, masterPort)
    .sslContext(GrpcSslContexts.forClient().keyManager(new File(adminCertFile), new File(adminKeyFile), null).trustManager(new File(caCertFile)).build())
    .build();
  
    LoginGrpc.LoginBlockingStub loginStub = LoginGrpc.newBlockingStub(channel);

    LoginAdminRequest request = LoginAdminRequest.newBuilder().setAdminTenantCert(new String(Files.readAllBytes(Paths.get(adminCertFile)))).setTenantID(ADMIN_TENANT_ID).build();
    LoginAdminResponse response;

    response = loginStub.loginAdmin(request);
    credentials = new JwtCredential(response.getJwtToken());
  }

  public void initTenant(String tenantID, String gatewayID) throws Exception {
    TenantGrpc.TenantBlockingStub tenantStub = TenantGrpc.newBlockingStub(channel).withCallCredentials(credentials);

    try {
      GetRequest getRequest = GetRequest.newBuilder().addTenantIDs(tenantID).build();
      GetResponse getResponse = tenantStub.get(getRequest);

      if(getResponse.getTenantInfosList().size() == 1) { // tenant is already initialized
        System.out.printf("%s is already registered.", tenantID);
        return;
      }
    } catch (Exception e) {
    } 

    System.out.printf("%s is not found. Trying to add the tenant...\n", tenantID);     

    TenantInfo tenantInfo = TenantInfo.newBuilder().setTenantID(tenantID).addGatewayIDs(gatewayID).build();
    AddRequest addRequest = AddRequest.newBuilder().addTenantInfos(tenantInfo).build();
    AddResponse addResponse = tenantStub.add(addRequest);

    System.out.printf("%s is registered successfully.", tenantID); 
  }

  public void connectTenant(String caCertFile, String tenantCertFile, String tenantKeyFile, String masterAddr, int masterPort) throws Exception {
    channel = NettyChannelBuilder.forAddress(masterAddr, masterPort)
    .sslContext(GrpcSslContexts.forClient().keyManager(new File(tenantCertFile), new File(tenantKeyFile), null).trustManager(new File(caCertFile)).build())
    .build();
  
    LoginGrpc.LoginBlockingStub loginStub = LoginGrpc.newBlockingStub(channel);

    LoginRequest request = LoginRequest.newBuilder().setTenantCert(new String(Files.readAllBytes(Paths.get(tenantCertFile)))).build();
    LoginResponse response;

    response = loginStub.login(request);
    credentials = new JwtCredential(response.getJwtToken());
  }  
}

