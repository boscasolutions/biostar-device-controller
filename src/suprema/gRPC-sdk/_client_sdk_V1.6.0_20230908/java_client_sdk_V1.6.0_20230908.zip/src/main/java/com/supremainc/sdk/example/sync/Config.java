package com.supremainc.sdk.example.sync;

import java.util.List;
import java.util.ArrayList;
import java.nio.file.Files;
import java.nio.file.Paths;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.supremainc.sdk.connect.AsyncConnectInfo;

class DeviceInfo {
  private int device_id;
  private String ip_addr;
  private int port;
  private boolean use_ssl;
  private int last_event_id;

  public void updateLastEventID(int eventID) {
    last_event_id = eventID;
  }

  public AsyncConnectInfo convertToConnectInfo() {
    AsyncConnectInfo connInfo = AsyncConnectInfo.newBuilder().setDeviceID(device_id).setIPAddr(ip_addr).setPort(port).setUseSSL(use_ssl).build();
    return connInfo;
  }

  public int getDeviceID() {
    return device_id;
  }

  public int getLastEventID() {
    return last_event_id;
  }
}

class ConfigData {
  private DeviceInfo enroll_device;
  private DeviceInfo[] devices;

  public DeviceInfo getEnrollDevice() {
    return enroll_device;
  }

  public int getNumOfDevice() {
    return devices.length;
  }

  public DeviceInfo getDevice(int index) {
    return devices[index];
  }
}

class TestConfig {
  private ConfigData configData;
  private String configFile;

  public void read(String configFile) throws Exception {
    this.configFile = configFile;

    String jsonData = new String(Files.readAllBytes(Paths.get(configFile)));

    Gson gson = new Gson();
    configData = gson.fromJson(jsonData, ConfigData.class);
  }

  public void write() throws Exception {
    Gson gson = new GsonBuilder().setPrettyPrinting().create();
    String jsonData = gson.toJson(configData);

    Files.write(Paths.get(configFile), jsonData.getBytes());
  }

  public String getConfigData() {
    Gson gson = new GsonBuilder().setPrettyPrinting().create();
    return gson.toJson(configData);
  }

  public DeviceInfo getEnrollDevice() {
    return configData.getEnrollDevice();
  }

  public List<AsyncConnectInfo> getAsyncConnectInfo() {
    List<AsyncConnectInfo> infos = new ArrayList<AsyncConnectInfo>();

    infos.add(configData.getEnrollDevice().convertToConnectInfo());

    for(int i = 0; i < configData.getNumOfDevice(); i++) {
      infos.add(configData.getDevice(i).convertToConnectInfo());
    }

    return infos;
  }

  public DeviceInfo getDeviceInfo(int deviceID) {
    if(deviceID == configData.getEnrollDevice().getDeviceID()) {
      return configData.getEnrollDevice();
    }

    for(int i = 0; i < configData.getNumOfDevice(); i++) {
      if(deviceID == configData.getDevice(i).getDeviceID()) {
        return configData.getDevice(i);
      } 
    } 
    
    return null;
  }

  public List<Integer> getTargetDeviceIDs(List<Integer> connectedIDs) {
    List<Integer> targetIDs = new ArrayList<Integer>();

    for(int devID:connectedIDs) {
      for(int i = 0; i < configData.getNumOfDevice(); i++) {
        if(devID == configData.getDevice(i).getDeviceID()) {
          targetIDs.add(devID);
          break;
        } 
      }
    }
    
    return targetIDs;
  }

  public void updateLastEventID(int deviceID, int lastEventID) throws Exception {
    boolean updated = false;

    if(deviceID == configData.getEnrollDevice().getDeviceID()) {
      configData.getEnrollDevice().updateLastEventID(lastEventID);
      updated = true;
    } else {
      for(int i = 0; i < configData.getNumOfDevice(); i++) {
        if(deviceID == configData.getDevice(i).getDeviceID()) {
          configData.getDevice(i).updateLastEventID(lastEventID);
          updated = true;
          break;
        } 
      } 
    }

    if(updated) {
      write();
    }
  }
}

