package com.supremainc.sdk.example.tna.test;

import com.supremainc.sdk.example.client.GatewayClient;
import com.supremainc.sdk.tna.TNAGrpc;
import com.supremainc.sdk.tna.TNAConfig;
import com.supremainc.sdk.example.tna.TNASvc;
import com.supremainc.sdk.connect.ConnectGrpc;
import com.supremainc.sdk.connect.ConnectInfo;
import com.supremainc.sdk.example.connect.ConnectSvc;
import com.supremainc.sdk.event.EventGrpc;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.device.DeviceGrpc;
import com.supremainc.sdk.device.DeviceCapability;
import com.supremainc.sdk.example.device.DeviceSvc;

public class TNATest {
  private static final String CA_FILE = "cert/gateway/ca.crt";

  private static final String GATEWAY_ADDR = "192.168.0.2";
  private static final int GATEWAY_PORT = 4000;

  private static final String DEVICE_ADDR = "192.168.0.110";
  private static final int DEVICE_PORT = 51211;
  private static final boolean DEVICE_USE_SSL = false;  

  private static final String CODE_MAP_FILE = "./event_code.json";

  private GatewayClient gatewayClient;
  private TNASvc tnaSvc;
  private ConnectSvc connectSvc;
  private EventSvc eventSvc;
  private DeviceSvc deviceSvc;

  public TNATest(GatewayClient client) {
    gatewayClient = client;

    connectSvc = new ConnectSvc(ConnectGrpc.newBlockingStub(client.getChannel())); 
    tnaSvc = new TNASvc(TNAGrpc.newBlockingStub(client.getChannel())); 
    eventSvc = new EventSvc(EventGrpc.newBlockingStub(client.getChannel())); 
    deviceSvc = new DeviceSvc(DeviceGrpc.newBlockingStub(client.getChannel())); 
  }

  public static void main(String[] args) throws Exception {
    GatewayClient client = new GatewayClient();

    try {
      client.connect(CA_FILE, GATEWAY_ADDR, GATEWAY_PORT);
    } catch (Exception e) {
      System.out.printf("Cannot connect to the server: %s", e); 
      System.exit(-1);
    }

    TNATest tnaTest = new TNATest(client);

    int deviceID = 0;

    try {
      ConnectInfo connInfo = ConnectInfo.newBuilder().setIPAddr(DEVICE_ADDR).setPort(DEVICE_PORT).setUseSSL(DEVICE_USE_SSL).build();

      deviceID = tnaTest.connectSvc.connect(connInfo);      
    } catch (Exception e) {
      System.out.printf("Cannot connect to the device: %s", e); 
      client.close();
      System.exit(-1);
    }

    try {
      DeviceCapability capability = tnaTest.deviceSvc.getCapability(deviceID);

      if (!capability.getDisplaySupported()) {
        System.out.printf("T&A service is not supported by the device %d: %s", deviceID, capability); 
        tnaTest.connectSvc.disconnect(deviceID);
        client.close();
        System.exit(-1);  
      }

    } catch (Exception e) {
      System.out.printf("Cannot get the device info: %s", e); 
      tnaTest.connectSvc.disconnect(deviceID);
      client.close();
      System.exit(-1);
    }

    try {
      LogTest logTest = new LogTest(tnaTest.tnaSvc, tnaTest.eventSvc);
      ConfigTest configTest = new ConfigTest(tnaTest.tnaSvc);

      tnaTest.eventSvc.initCodeMap(CODE_MAP_FILE);
      tnaTest.eventSvc.startMonitoring(deviceID);
      tnaTest.eventSvc.setEventCallback(logTest);

      TNAConfig origConfig = configTest.test(deviceID);
      logTest.test(deviceID);

      tnaTest.tnaSvc.setConfig(deviceID, origConfig);

      tnaTest.eventSvc.stopMonitoring(deviceID);
    } catch (Exception e) {
      System.out.printf("Cannot complete the tna test for device %d: %s", deviceID, e); 
    } finally {
      tnaTest.connectSvc.disconnect(deviceID);
      client.close();
    }
  }
}

