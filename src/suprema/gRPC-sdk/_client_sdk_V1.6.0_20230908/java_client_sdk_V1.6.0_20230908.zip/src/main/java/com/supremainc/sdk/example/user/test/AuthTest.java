package com.supremainc.sdk.example.user.test;

import java.util.Arrays;

import com.supremainc.sdk.auth.AuthConfig;
import com.supremainc.sdk.auth.AuthSchedule;
import com.supremainc.sdk.auth.AuthMode;
import com.supremainc.sdk.example.auth.AuthSvc;
import com.supremainc.sdk.device.Type;
import com.supremainc.sdk.example.cli.KeyInput;

class AuthTest {
  private AuthSvc authSvc;

  public AuthTest(AuthSvc svc) {
    authSvc = svc;
  }

  public AuthConfig prepareAuthConfig(int deviceID) throws Exception {
    // Backup the original configuration
    AuthConfig origConfig = authSvc.getConfig(deviceID);
    System.out.printf("Original Config: %s\n\n", origConfig);

    // Enable private authentication for test
    AuthConfig testConfig = origConfig.toBuilder().setUsePrivateAuth(true).build();
    authSvc.setConfig(deviceID, testConfig);

    return origConfig;
  }

  public void test(int deviceID, boolean extendedAuthSupported) throws Exception {
    System.out.printf("\n===== Auth Mode Test =====\n\n");

    AuthConfig config;  

    if (extendedAuthSupported) {
      config = AuthConfig.newBuilder().setMatchTimeout(10).setAuthTimeout(15)
                .addAuthSchedules(AuthSchedule.newBuilder().setMode(AuthMode.AUTH_EXT_MODE_CARD_ONLY).setScheduleID(1)) // Card Only, Always
                .addAuthSchedules(AuthSchedule.newBuilder().setMode(AuthMode.AUTH_EXT_MODE_FINGERPRINT_ONLY).setScheduleID(1)) // Fingerprint Only, Always
                .addAuthSchedules(AuthSchedule.newBuilder().setMode(AuthMode.AUTH_EXT_MODE_FACE_ONLY).setScheduleID(1)) // Face Only, Always
                .build();
    } else {
      config = AuthConfig.newBuilder().setMatchTimeout(10).setAuthTimeout(15)
                .addAuthSchedules(AuthSchedule.newBuilder().setMode(AuthMode.AUTH_MODE_CARD_ONLY).setScheduleID(1)) // Card Only, Always
                .addAuthSchedules(AuthSchedule.newBuilder().setMode(AuthMode.AUTH_MODE_BIOMETRIC_ONLY).setScheduleID(1)) // Biometric Only, Always
                .build();
    }

    authSvc.setConfig(deviceID, config);

    KeyInput.pressEnter(">> Try to authenticate card or fingerprint or face. And, press ENTER for the next test.\n");

    if (extendedAuthSupported) {
      config = AuthConfig.newBuilder().setMatchTimeout(10).setAuthTimeout(15)
                .addAuthSchedules(AuthSchedule.newBuilder().setMode(AuthMode.AUTH_EXT_MODE_CARD_FACE).setScheduleID(1)) // Card + Face, Always
                .addAuthSchedules(AuthSchedule.newBuilder().setMode(AuthMode.AUTH_EXT_MODE_CARD_FINGERPRINT).setScheduleID(1)) // Card + Fingerprint, Always
                .build();
    } else {
      config = AuthConfig.newBuilder().setMatchTimeout(10).setAuthTimeout(15)
                .addAuthSchedules(AuthSchedule.newBuilder().setMode(AuthMode.AUTH_MODE_CARD_BIOMETRIC).setScheduleID(1)) // Card + Biometric, Always
                .build();
    }

    authSvc.setConfig(deviceID, config);

    KeyInput.pressEnter(">> Try to authenticate (card + fingerprint) or (card + face). And, press ENTER to end the test.\n");    

  }
}

