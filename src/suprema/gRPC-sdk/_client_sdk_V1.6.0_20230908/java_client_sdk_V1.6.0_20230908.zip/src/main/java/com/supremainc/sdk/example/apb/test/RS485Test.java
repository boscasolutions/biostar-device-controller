package com.supremainc.sdk.example.apb.test;

import java.util.List;
import java.util.ArrayList;
import java.lang.Thread;

import com.supremainc.sdk.rs485.RS485Config;
import com.supremainc.sdk.rs485.RS485Channel;
import com.supremainc.sdk.rs485.Mode;
import com.supremainc.sdk.rs485.SlaveDeviceInfo;
import com.supremainc.sdk.example.rs485.RS485Svc;

class RS485Test {
  private RS485Svc rs485Svc;
  private List<SlaveDeviceInfo> slaves;
  private List<SlaveDeviceInfo> registeredSlaves;

  public RS485Test(RS485Svc rs485Svc) {
    this.rs485Svc = rs485Svc;
    
    slaves = null;
    registeredSlaves = null;
  }

  public List<SlaveDeviceInfo> getSlaves() {
    return slaves;
  }

  public boolean checkSlaves(int deviceID) throws Exception {
    RS485Config config = rs485Svc.getConfig(deviceID);

    boolean hasMasterChannel = false;

    List<RS485Channel> channels = config.getChannelsList();

    for(int i = 0; i < channels.size(); i++) {
      if(channels.get(i).getMode() == Mode.MASTER) {
        hasMasterChannel = true;
        break;
      }
    }

    if(!hasMasterChannel) {
      System.out.printf("!! Only a master device can have slave devices. Skip the test.\n");
      return false;
    }

    slaves = rs485Svc.searchSlave(deviceID);
    if(slaves.size() == 0) {
      System.out.printf("!! No slave device is configured. Configure and wire the slave devices first.\n");
      return false;
    }

    System.out.printf("Found Slaves: %s\n", slaves);

    registeredSlaves = rs485Svc.getSlave(deviceID);
    System.out.printf("Registered Slaves: %s\n", registeredSlaves);

    if(registeredSlaves.size() == 0) {
      rs485Svc.setSlave(deviceID, slaves);
    }
    
    for(int i = 0; i < 10; i++) {
      List<SlaveDeviceInfo> newSlaves = rs485Svc.searchSlave(deviceID);
      if(newSlaves.get(0).getConnected()) {
        break;
      }

      System.out.printf("Waiting for the slave to be connected %d...\n", i);
      Thread.sleep(2000);
    }

    return true;
  }

  public void restoreSlaves(int deviceID) throws Exception {
    if(registeredSlaves != null) {
      rs485Svc.setSlave(deviceID, registeredSlaves);
    }
  }
}
