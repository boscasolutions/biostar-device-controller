package com.supremainc.sdk.example.wiegand.test;

import java.util.ArrayList;
import com.google.protobuf.ByteString;

import com.supremainc.sdk.wiegand.WiegandConfig;
import com.supremainc.sdk.wiegand.WiegandFormat;
import com.supremainc.sdk.wiegand.ParityField;
import com.supremainc.sdk.wiegand.WiegandParity;
import com.supremainc.sdk.wiegand.WiegandMode;
import com.supremainc.sdk.wiegand.WiegandOutType;
import com.supremainc.sdk.example.wiegand.WiegandSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class ConfigTest {
  private WiegandSvc wiegandSvc;

  public ConfigTest(WiegandSvc svc) {
    wiegandSvc = svc;
  }

  public void test(int deviceID) throws Exception {
    // Backup the original configuration
    WiegandConfig origConfig = wiegandSvc.getConfig(deviceID);
    System.out.printf("Original Config: %s\n\n", origConfig);

    System.out.printf("\n===== Wiegand Config Test =====\n\n");

    test26bit(deviceID);
    test37bit(deviceID);

    // Restore the original configuration
    wiegandSvc.setConfig(deviceID, origConfig);
  }

  // 26 bit standard
  // FC: 01 1111 1110 0000 0000 0000 0000 : 0x01fe0000
  // ID: 00 0000 0001 1111 1111 1111 1110 : 0x0001fffe
  // EP: 01 1111 1111 1110 0000 0000 0000 : 0x01ffe000, Pos 0, Type: Even
  // OP: 00 0000 0000 0001 1111 1111 1110 : 0x00001ffe, Pos 25, Type: Odd  

  private static final int WIEGAND_26BIT_LENGTH = 26;
  private static final int WIEGAND_26BIT_EVEN_PARITY_POS = 0;
  private static final int WIEGAND_26BIT_ODD_PARITY_POS = 25;

  private static final int OUT_PULSE_WIDTH = 40;
  private static final int OUT_PULSE_INTERVAL = 10000;

  public void test26bit(int deviceID) throws Exception {
    ArrayList<ByteString> idFields = new ArrayList<ByteString>();

    idFields.add(ByteString.copyFrom(new byte[]{0, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0})); // Facility Code
    idFields.add(ByteString.copyFrom(new byte[]{0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0})); // ID

    ArrayList<ParityField> parityFields = new ArrayList<ParityField>();

    ParityField evenParity = ParityField.newBuilder()
      .setParityPos(WIEGAND_26BIT_EVEN_PARITY_POS)
      .setParityType(WiegandParity.WIEGAND_PARITY_EVEN)
      .setData(ByteString.copyFrom(new byte[]{0, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0}))
      .build();

    ParityField oddParity = ParityField.newBuilder()
      .setParityPos(WIEGAND_26BIT_ODD_PARITY_POS)
      .setParityType(WiegandParity.WIEGAND_PARITY_ODD)
      .setData(ByteString.copyFrom(new byte[]{0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0}))
      .build();
    
    parityFields.add(evenParity);
    parityFields.add(oddParity);

    WiegandFormat std26bitFormat = WiegandFormat.newBuilder()
                      .setLength(WIEGAND_26BIT_LENGTH)
                      .addAllIDFields(idFields)
                      .addAllParityFields(parityFields)
                      .build();
                      
    WiegandConfig std26bitConfig = WiegandConfig.newBuilder()
                        .setMode(WiegandMode.WIEGAND_OUT_ONLY)
                        .setOutPulseWidth(OUT_PULSE_WIDTH)
                        .setOutPulseInterval(OUT_PULSE_INTERVAL)
                        .addFormats(std26bitFormat)
                        .setUseWiegandUserID(WiegandOutType.WIEGAND_OUT_USER_ID)
                        .build();

    wiegandSvc.setConfig(deviceID, std26bitConfig);
    
    WiegandConfig newConfig = wiegandSvc.getConfig(deviceID);
    System.out.printf("\n>>> Wiegand Config with Standard 26bit Format: %s\n", newConfig);
  }

  // 37 bit HID
  // FC: 0 1111 1111 1111 1111 0000 0000 0000 0000 0000 : 0x0ffff00000
  // ID: 0 0000 0000 0000 0000 1111 1111 1111 1111 1110 : 0x00000ffffe
  // EP: 0 1111 1111 1111 1111 1100 0000 0000 0000 0000 : 0x0ffffc0000, Pos 0, Type: Even
  // OP: 0 0000 0000 0000 0000 0111 1111 1111 1111 1110 : 0x000007fffe, Pos 36, Type: Odd

  private static final int WIEGAND_37BIT_LENGTH = 37;
  private static final int WIEGAND_37BIT_EVEN_PARITY_POS = 0;
  private static final int WIEGAND_37BIT_ODD_PARITY_POS = 36;

  public void test37bit(int deviceID) throws Exception {
    ArrayList<ByteString> idFields = new ArrayList<ByteString>();

    idFields.add(ByteString.copyFrom(new byte[]{0, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0})); // Facility Code
    idFields.add(ByteString.copyFrom(new byte[]{0, 0, 0, 0, 0, /**/ 0, 0 ,0 ,0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0})); // ID

    ArrayList<ParityField> parityFields = new ArrayList<ParityField>();

    ParityField evenParity = ParityField.newBuilder()
      .setParityPos(WIEGAND_37BIT_EVEN_PARITY_POS)
      .setParityType(WiegandParity.WIEGAND_PARITY_EVEN)
      .setData(ByteString.copyFrom(new byte[]{0, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0}))
      .build();

    ParityField oddParity = ParityField.newBuilder()
      .setParityPos(WIEGAND_37BIT_ODD_PARITY_POS)
      .setParityType(WiegandParity.WIEGAND_PARITY_ODD)
      .setData(ByteString.copyFrom(new byte[]{0, 0, 0, 0, 0, /**/ 0, 0 ,0 ,0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0}))
      .build();
    
    parityFields.add(evenParity);
    parityFields.add(oddParity);

    WiegandFormat hid37bitFormat = WiegandFormat.newBuilder()
                      .setLength(WIEGAND_37BIT_LENGTH)
                      .addAllIDFields(idFields)
                      .addAllParityFields(parityFields)
                      .build();
                      
    WiegandConfig hid37bitConfig = WiegandConfig.newBuilder()
                        .setMode(WiegandMode.WIEGAND_OUT_ONLY)
                        .setOutPulseWidth(OUT_PULSE_WIDTH)
                        .setOutPulseInterval(OUT_PULSE_INTERVAL)
                        .addFormats(hid37bitFormat)
                        .setUseWiegandUserID(WiegandOutType.WIEGAND_OUT_USER_ID)
                        .build();

    wiegandSvc.setConfig(deviceID, hid37bitConfig);
    
    WiegandConfig newConfig = wiegandSvc.getConfig(deviceID);
    System.out.printf("\n>>> Wiegand Config with HID 37bit Format: %s\n", newConfig);
  }

}



