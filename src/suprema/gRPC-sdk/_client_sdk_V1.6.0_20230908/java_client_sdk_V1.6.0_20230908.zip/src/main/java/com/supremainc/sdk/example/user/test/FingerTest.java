package com.supremainc.sdk.example.user.test;

import java.util.List;
import java.util.ArrayList;
import com.google.protobuf.ByteString;

import com.supremainc.sdk.finger.FingerData;
import com.supremainc.sdk.finger.TemplateFormat;
import com.supremainc.sdk.example.finger.FingerSvc;
import com.supremainc.sdk.user.UserFinger;
import com.supremainc.sdk.example.user.UserSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class FingerTest {
  private FingerSvc fingerSvc;
  private UserSvc userSvc;

  private static final int QUALITY_THRESHOLD = 50;
  private static final int NUM_OF_TEMPLATE = 2;

  public FingerTest(FingerSvc fingerSvc, UserSvc userSvc) {
    this.fingerSvc = fingerSvc;
    this.userSvc = userSvc;
  }

  public void test(int deviceID, String userID) throws Exception {
    System.out.printf("\n===== Finger Test =====\n\n");

    List<ByteString> templateData = new ArrayList<ByteString>();

    for(int i = 0; i < NUM_OF_TEMPLATE; i++) {
      if(i == 0) {
        System.out.printf(">> Scan a finger on the device...\n");
      } else {
        System.out.printf(">> Scan the same finger again on the device...\n");
      }

      templateData.add(fingerSvc.scan(deviceID, TemplateFormat.TEMPLATE_FORMAT_SUPREMA, QUALITY_THRESHOLD));
    }

    FingerData fingerData = FingerData.newBuilder().addAllTemplates(templateData).build();

    List<UserFinger> userFingers = new ArrayList<UserFinger>();
    userFingers.add(UserFinger.newBuilder().setUserID(userID).addFingers(fingerData).build());

    userSvc.setFinger(deviceID, userFingers);

    KeyInput.pressEnter(">> Try to authenticate the enrolled finger. And, press ENTER to end the test.\n");
  }
}

