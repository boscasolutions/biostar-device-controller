package com.supremainc.sdk.example.quick;

import java.io.FileOutputStream;
import java.util.Arrays;
import com.google.protobuf.ByteString;

import com.supremainc.sdk.example.display.DisplaySvc;
import com.supremainc.sdk.display.DisplayConfig;

class DisplayTest {
  private DisplaySvc displaySvc;

  public DisplayTest(DisplaySvc svc) {
    displaySvc = svc;
  }

  public void test(int deviceID) throws Exception {
    DisplayConfig displayConfig = displaySvc.getConfig(deviceID);

    System.out.printf("Display config: \n%s\n\n", displayConfig);
  }
}

