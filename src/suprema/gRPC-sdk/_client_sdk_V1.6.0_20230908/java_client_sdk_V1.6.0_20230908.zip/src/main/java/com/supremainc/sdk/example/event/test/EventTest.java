package com.supremainc.sdk.example.event.test;

import com.supremainc.sdk.example.client.GatewayClient;
import com.supremainc.sdk.event.EventGrpc;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.connect.ConnectGrpc;
import com.supremainc.sdk.connect.ConnectInfo;
import com.supremainc.sdk.example.connect.ConnectSvc;


public class EventTest {
  private static final String CA_FILE = "cert/gateway/ca.crt";

  private static final String GATEWAY_ADDR = "192.168.0.2";
  private static final int GATEWAY_PORT = 4000;

  private static final String DEVICE_ADDR = "192.168.0.110";
  private static final int DEVICE_PORT = 51211;
  private static final boolean DEVICE_USE_SSL = false;  

  private GatewayClient gatewayClient;
  private EventSvc eventSvc;
  private ConnectSvc connectSvc;

  public EventTest(GatewayClient client) {
    gatewayClient = client;

    connectSvc = new ConnectSvc(ConnectGrpc.newBlockingStub(client.getChannel())); 
    eventSvc = new EventSvc(EventGrpc.newBlockingStub(client.getChannel())); 
  }

  public static void main(String[] args) throws Exception {
    GatewayClient client = new GatewayClient();

    try {
      client.connect(CA_FILE, GATEWAY_ADDR, GATEWAY_PORT);
    } catch (Exception e) {
      System.out.printf("Cannot connect to the server: %s", e); 
      System.exit(-1);
    }

    EventTest eventTest = new EventTest(client);

    int deviceID = 0;

    try {
      ConnectInfo connInfo = ConnectInfo.newBuilder().setIPAddr(DEVICE_ADDR).setPort(DEVICE_PORT).setUseSSL(DEVICE_USE_SSL).build();

      deviceID = eventTest.connectSvc.connect(connInfo);      
    } catch (Exception e) {
      System.out.printf("Cannot connect to the device: %s", e); 
      client.close();
      System.exit(-1);
    }

    try {
      new LogTest(eventTest.eventSvc).test(deviceID);
    } catch (Exception e) {
      System.out.printf("Cannot complete the event test for device %d: %s", deviceID, e); 
    } finally {
      eventTest.connectSvc.disconnect(deviceID);
      client.close();
    }
  }
}

