package com.supremainc.sdk.example.door.test;

import java.util.List;
import java.util.ArrayList;

import com.supremainc.sdk.door.DoorInfo;
import com.supremainc.sdk.door.Relay;
import com.supremainc.sdk.door.Sensor;
import com.supremainc.sdk.door.ExitButton;
import com.supremainc.sdk.door.Status;
import com.supremainc.sdk.door.DoorFlag;
import com.supremainc.sdk.device.SwitchType;
import com.supremainc.sdk.access.AccessGroup;
import com.supremainc.sdk.access.AccessLevel;
import com.supremainc.sdk.access.DoorSchedule;
import com.supremainc.sdk.user.UserAccessGroup;
import com.supremainc.sdk.example.door.DoorSvc;
import com.supremainc.sdk.example.access.AccessSvc;
import com.supremainc.sdk.example.user.UserSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class AccessTest {
  private static final int TEST_DOOR_ID = 1;
  private static final int RELAY_PORT = 0; // 1st relay
  private static final int SENSOR_PORT = 0; // 1st input port
  private static final int EXIT_BUTTON_PORT = 1; // 2nd input port
  private static final int AUTO_LOCK_TIMEOUT = 3; // locked after 3 seconds
  private static final int HELD_OPEN_TIMEOUT = 10; // held open alarm after 10 seconds
  
  private static final int TEST_ACCESS_LEVEL_ID = 1;
  private static final int TEST_ACCESS_GROUP_ID = 1;
  private static final int ALWAYS_SCHEDULE_ID = 1; // ID 1 is reserved for 'always'

  private DoorSvc doorSvc;
  private AccessSvc accessSvc;
  private UserSvc userSvc;
  private LogTest logTest;

  public AccessTest(DoorSvc doorSvc, AccessSvc accessSvc, UserSvc userSvc, LogTest logTest) {
    this.doorSvc = doorSvc;
    this.accessSvc = accessSvc;
    this.userSvc = userSvc;
    this.logTest = logTest;
  }

  public void test(int deviceID) throws Exception {
    List<DoorInfo> origDoors = doorSvc.getList(deviceID);

    System.out.printf("Original Doors: %s\n", origDoors);
    testDoor(deviceID);
    testAccessGroup(deviceID);

    doorSvc.deleteAll(deviceID);

    if(origDoors.size() > 0) {
      doorSvc.add(deviceID, origDoors);
    }
  }

  void testDoor(int deviceID) throws Exception {
    Relay relay = Relay.newBuilder().setDeviceID(deviceID).setPort(RELAY_PORT).build();
    Sensor sensor = Sensor.newBuilder().setDeviceID(deviceID).setPort(SENSOR_PORT).setType(SwitchType.NORMALLY_OPEN).build();
    ExitButton button = ExitButton.newBuilder().setDeviceID(deviceID).setPort(EXIT_BUTTON_PORT).setType(SwitchType.NORMALLY_OPEN).build();

    DoorInfo door = DoorInfo.newBuilder()
                    .setDoorID(TEST_DOOR_ID)
                    .setName("Test Door")
                    .setEntryDeviceID(deviceID)
                    .setRelay(relay)
                    .setSensor(sensor)
                    .setButton(button)
                    .setAutoLockTimeout(AUTO_LOCK_TIMEOUT)
                    .setHeldOpenTimeout(HELD_OPEN_TIMEOUT)
                    .build();

    ArrayList<DoorInfo> doors = new ArrayList<DoorInfo>();
    doors.add(door);

    doorSvc.deleteAll(deviceID);
    doorSvc.add(deviceID, doors);

    System.out.printf("\n===== Door Test =====\n\n");

    List<DoorInfo> newDoors = doorSvc.getList(deviceID);

    System.out.printf("\nTest Doors: %s\n\n", newDoors);

    System.out.printf(">> Try to authenticate a registered credential. It should fail since you can access a door only with a proper access group.\n");
    KeyInput.pressEnter(">> Press ENTER for the next test.\n"); 
  }

  void testAccessGroup(int deviceID) throws Exception {
    String userID = logTest.getUserID(deviceID);

    if(userID == null) {
      System.out.printf("!! Cannot find ACCESS_DENIED event. You should have tried to authenticate a registered credentail for the test.\n");
      return;
    }

    ArrayList<String> userIDs = new ArrayList<String>();
    userIDs.add(userID);

    // backup access groups
    List<AccessGroup> origGroups = accessSvc.getList(deviceID);
    List<AccessLevel> origLevels = accessSvc.getLevelList(deviceID);
    List<UserAccessGroup> origUserAccessGroups = userSvc.getAccessGroup(deviceID, userIDs);

    System.out.printf("Original Access Groups: %s\n", origGroups);
    System.out.printf("Original Access Levels: %s\n\n", origLevels);
    System.out.printf("Original User Access Groups: %s\n\n", origUserAccessGroups);

    accessSvc.deleteAll(deviceID);
    accessSvc.deleteAllLevel(deviceID);

    // make an access group and assign it to the user
    ArrayList<DoorSchedule> doorSchedules = new ArrayList<DoorSchedule>();
    doorSchedules.add(DoorSchedule.newBuilder().setDoorID(TEST_DOOR_ID).setScheduleID(ALWAYS_SCHEDULE_ID).build()); // can access the test door all the time

    ArrayList<AccessLevel> accessLevels = new ArrayList<AccessLevel>();
    accessLevels.add(AccessLevel.newBuilder().setID(TEST_ACCESS_LEVEL_ID).addAllDoorSchedules(doorSchedules).build());

    accessSvc.addLevel(deviceID, accessLevels);

    ArrayList<AccessGroup> accessGroups = new ArrayList<AccessGroup>();
    accessGroups.add(AccessGroup.newBuilder().setID(TEST_ACCESS_GROUP_ID).addLevelIDs(TEST_ACCESS_LEVEL_ID).build());

    accessSvc.add(deviceID, accessGroups);

    List<UserAccessGroup> userAccessGroups = new ArrayList<UserAccessGroup>();
    userAccessGroups.add(UserAccessGroup.newBuilder().setUserID(userID).addAccessGroupIDs(TEST_ACCESS_GROUP_ID).build());

    userSvc.setAccessGroup(deviceID, userAccessGroups);

    List<AccessGroup> newGroups = accessSvc.getList(deviceID);
    List<AccessLevel> newLevels = accessSvc.getLevelList(deviceID);
    List<UserAccessGroup> newUserAccessGroups = userSvc.getAccessGroup(deviceID, userIDs);

    System.out.printf("\nTest Access Groups: %s\n", newGroups);
    System.out.printf("Test Access Levels: %s\n", newLevels);    
    System.out.printf("Test User Access Groups: %s\n\n", newUserAccessGroups);    

    System.out.printf(">> Try to authenticate the same registered credential. It should succeed since the access group is added.\n");
    KeyInput.pressEnter(">> Press ENTER for the next test.\n");

    testLock(deviceID);

    // restore the original access groups
    userSvc.setAccessGroup(deviceID, origUserAccessGroups);
    accessSvc.deleteAll(deviceID);
    accessSvc.deleteAllLevel(deviceID);

    if(origGroups.size() > 0) {
      accessSvc.add(deviceID, origGroups);
    }

    if(origLevels.size() > 0) {
      accessSvc.addLevel(deviceID, origLevels);
    }
  }

  void testLock(int deviceID) throws Exception {
    KeyInput.pressEnter(">> Press ENTER to unlock the door.\n"); 

    ArrayList<Integer> doorIDs = new ArrayList<Integer>();
    doorIDs.add(TEST_DOOR_ID);

    doorSvc.unlock(deviceID, doorIDs, DoorFlag.OPERATOR);
    List<Status> doorStatus = doorSvc.getStatus(deviceID);
    System.out.printf("\nStatus after unlocking the door: %s\n", doorStatus);

    KeyInput.pressEnter(">> Press ENTER to lock the door.\n"); 

    doorSvc.lock(deviceID, doorIDs, DoorFlag.OPERATOR);
    doorStatus = doorSvc.getStatus(deviceID);
    System.out.printf("\nStatus after locking the door: %s\n", doorStatus);

    System.out.printf(">> Try to authenticate the same registered credential. The relay should not work since the door is locked by the operator with the higher priority.\n");
    KeyInput.pressEnter(">> Press ENTER to release the door flag.\n");    

    doorSvc.release(deviceID, doorIDs, DoorFlag.OPERATOR);
    doorStatus = doorSvc.getStatus(deviceID);
    System.out.printf("\nStatus after releasing the door flag: %s\n", doorStatus);

    System.out.printf(">> Try to authenticate the same registered credential. The relay should work since the door flag is cleared.\n");
    KeyInput.pressEnter(">> Press ENTER for the next test.\n");    
  }
}

