package com.supremainc.sdk.example.event;

class EventCodeEntry {
  private int event_code;
  private String event_code_str;
  private int sub_code;
  private String sub_code_str;
  private String desc;

  public int getEventCode() {
    return event_code;
  }

  public int getSubCode() {
    return sub_code;
  }

  public String getDesc() {
    return desc;
  }
}

class EventCodeMap {
  private String title;
  private String version;
  private String date;
  private EventCodeEntry[] entries;

  public int getEntryLength() {
    return entries.length;
  }

  public EventCodeEntry getEntry(int index) {
    return entries[index];
  }
}
