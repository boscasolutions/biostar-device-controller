package com.supremainc.sdk.example.door.test;

import com.supremainc.sdk.example.client.GatewayClient;
import com.supremainc.sdk.door.DoorGrpc;
import com.supremainc.sdk.example.door.DoorSvc;
import com.supremainc.sdk.connect.ConnectGrpc;
import com.supremainc.sdk.connect.ConnectInfo;
import com.supremainc.sdk.example.connect.ConnectSvc;
import com.supremainc.sdk.event.EventGrpc;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.user.UserGrpc;
import com.supremainc.sdk.example.user.UserSvc;
import com.supremainc.sdk.access.AccessGrpc;
import com.supremainc.sdk.example.access.AccessSvc;


public class DoorTest {
  private static final String CA_FILE = "cert/gateway/ca.crt";

  private static final String GATEWAY_ADDR = "192.168.0.2";
  private static final int GATEWAY_PORT = 4000;

  private static final String DEVICE_ADDR = "192.168.0.110";
  private static final int DEVICE_PORT = 51211;
  private static final boolean DEVICE_USE_SSL = false;  

  private static final String CODE_MAP_FILE = "./event_code.json";

  private GatewayClient gatewayClient;
  private DoorSvc doorSvc;
  private ConnectSvc connectSvc;
  private EventSvc eventSvc;
  private AccessSvc accessSvc;
  private UserSvc userSvc;

  public DoorTest(GatewayClient client) {
    gatewayClient = client;

    connectSvc = new ConnectSvc(ConnectGrpc.newBlockingStub(client.getChannel())); 
    doorSvc = new DoorSvc(DoorGrpc.newBlockingStub(client.getChannel())); 
    eventSvc = new EventSvc(EventGrpc.newBlockingStub(client.getChannel())); 
    accessSvc = new AccessSvc(AccessGrpc.newBlockingStub(client.getChannel())); 
    userSvc = new UserSvc(UserGrpc.newBlockingStub(client.getChannel())); 
  }

  public static void main(String[] args) throws Exception {
    GatewayClient client = new GatewayClient();

    try {
      client.connect(CA_FILE, GATEWAY_ADDR, GATEWAY_PORT);
    } catch (Exception e) {
      System.out.printf("Cannot connect to the server: %s", e); 
      System.exit(-1);
    }

    DoorTest doorTest = new DoorTest(client);

    int deviceID = 0;

    try {
      ConnectInfo connInfo = ConnectInfo.newBuilder().setIPAddr(DEVICE_ADDR).setPort(DEVICE_PORT).setUseSSL(DEVICE_USE_SSL).build();

      deviceID = doorTest.connectSvc.connect(connInfo);      
    } catch (Exception e) {
      System.out.printf("Cannot connect to the device: %s", e); 
      client.close();
      System.exit(-1);
    }

    try {
      LogTest logTest = new LogTest(doorTest.eventSvc);

      doorTest.eventSvc.initCodeMap(CODE_MAP_FILE);
      doorTest.eventSvc.startMonitoring(deviceID);
      doorTest.eventSvc.setEventCallback(logTest);

      new AccessTest(doorTest.doorSvc, doorTest.accessSvc, doorTest.userSvc, logTest).test(deviceID);

      doorTest.eventSvc.stopMonitoring(deviceID); 
    } catch (Exception e) {
      System.out.printf("Cannot complete the door test for device %d: %s", deviceID, e); 
    } finally {
      doorTest.connectSvc.disconnect(deviceID);
      client.close();
    } 
  }
}