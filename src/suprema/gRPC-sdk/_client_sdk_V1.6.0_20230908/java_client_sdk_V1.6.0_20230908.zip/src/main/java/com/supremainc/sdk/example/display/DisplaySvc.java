package com.supremainc.sdk.example.display;

import com.supremainc.sdk.display.DisplayConfig;
import com.supremainc.sdk.display.DisplayGrpc;
import com.supremainc.sdk.display.GetConfigRequest;
import com.supremainc.sdk.display.GetConfigResponse;

public class DisplaySvc {
  private final DisplayGrpc.DisplayBlockingStub displayStub;

  public DisplaySvc(DisplayGrpc.DisplayBlockingStub stub) {
    displayStub = stub;
  }
  
  public DisplayConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = displayStub.getConfig(request);

    return response.getConfig();
  }

}