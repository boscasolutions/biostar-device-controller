package com.supremainc.sdk.example.card;

import java.util.List;

import com.supremainc.sdk.card.AddBlacklistRequest;
import com.supremainc.sdk.card.DeleteBlacklistRequest;
import com.supremainc.sdk.card.BlacklistItem;
import com.supremainc.sdk.card.CardData;
import com.supremainc.sdk.card.CardGrpc;
import com.supremainc.sdk.card.GetBlacklistRequest;
import com.supremainc.sdk.card.GetBlacklistResponse;
import com.supremainc.sdk.card.ScanRequest;
import com.supremainc.sdk.card.ScanResponse;
import com.supremainc.sdk.card.GetConfigRequest;
import com.supremainc.sdk.card.GetConfigResponse;
import com.supremainc.sdk.card.SetConfigRequest;
import com.supremainc.sdk.card.SetConfigResponse;
import com.supremainc.sdk.card.CardConfig;
import com.supremainc.sdk.card.GetQRConfigRequest;
import com.supremainc.sdk.card.GetQRConfigResponse;
import com.supremainc.sdk.card.SetQRConfigRequest;
import com.supremainc.sdk.card.SetQRConfigResponse;
import com.supremainc.sdk.card.QRConfig;

public class CardSvc {
  private final CardGrpc.CardBlockingStub cardStub;

  public CardSvc(CardGrpc.CardBlockingStub stub) {
    cardStub = stub;
  }

  public CardData scan(int deviceID) throws Exception {
    ScanRequest request = ScanRequest.newBuilder().setDeviceID(deviceID).build();
    ScanResponse response = cardStub.scan(request);

    return response.getCardData();
  } 

  public List<BlacklistItem> getBlacklist(int deviceID) throws Exception {
    GetBlacklistRequest request = GetBlacklistRequest.newBuilder().setDeviceID(deviceID).build();
    GetBlacklistResponse response = cardStub.getBlacklist(request);

    return response.getBlacklistList();
  }

  public void addBlacklist(int deviceID, List<BlacklistItem> cardInfos) throws Exception {
    AddBlacklistRequest request = AddBlacklistRequest.newBuilder().setDeviceID(deviceID).addAllCardInfos(cardInfos).build();
    cardStub.addBlacklist(request);
  }

  public void deleteBlacklist(int deviceID, List<BlacklistItem> cardInfos) throws Exception {
    DeleteBlacklistRequest request = DeleteBlacklistRequest.newBuilder().setDeviceID(deviceID).addAllCardInfos(cardInfos).build();
    cardStub.deleteBlacklist(request);
  }

  public CardConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = cardStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, CardConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = cardStub.setConfig(request);
  }

  public QRConfig getQRConfig(int deviceID) throws Exception {
    GetQRConfigRequest request = GetQRConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetQRConfigResponse response = cardStub.getQRConfig(request);

    return response.getConfig();
  }

  public void setQRConfig(int deviceID, QRConfig config) throws Exception {
    SetQRConfigRequest request = SetQRConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetQRConfigResponse response = cardStub.setQRConfig(request);
  }
}
