package com.supremainc.sdk.example.schedule.test;

import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;

import com.supremainc.sdk.schedule.ScheduleInfo;
import com.supremainc.sdk.schedule.HolidayGroup;
import com.supremainc.sdk.schedule.Holiday;
import com.supremainc.sdk.schedule.HolidaySchedule;
import com.supremainc.sdk.schedule.HolidayRecurrence;
import com.supremainc.sdk.schedule.TimePeriod;
import com.supremainc.sdk.schedule.DaySchedule;
import com.supremainc.sdk.schedule.WeeklySchedule;
import com.supremainc.sdk.schedule.DailySchedule;
import com.supremainc.sdk.example.schedule.ScheduleSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class SampleTest {
  private ScheduleSvc scheduleSvc;

  public SampleTest(ScheduleSvc svc) {
    scheduleSvc = svc;
  }

  private static final int SAMPLE_HOLIDAY_GROUP_ID = 1;
  private static final int WEEKLY_SCHEDULE_ID = 2; // 0 and 1 are reserved
  private static final int DAILY_SCHEDULE_ID = WEEKLY_SCHEDULE_ID + 1; 
  private static final int NUM_OF_DAY = 30;

  public void test(int deviceID) throws Exception {
    // Backup the schedules
    List<ScheduleInfo> origSchedules = scheduleSvc.getList(deviceID);
    List<HolidayGroup> origGroups = scheduleSvc.getHolidayList(deviceID);

    System.out.printf("Original Schedules: %s\n\n", origSchedules);
    System.out.printf("Original Holiday Groups: %s\n\n", origGroups);

    // Test sample schedules
    System.out.printf("\n===== Test Sample Schedules =====\n\n");

    scheduleSvc.deleteAll(deviceID);
    scheduleSvc.deleteAllHoliday(deviceID);

    HolidaySchedule holidaySchedule = makeHolidayGroup(deviceID);
    makeWeeklySchedule(deviceID, holidaySchedule);
    makeDailySchedule(deviceID);

    List<ScheduleInfo> newSchedules = scheduleSvc.getList(deviceID);
    System.out.printf(">>> Sample Schedules: %s\n\n", newSchedules);

    List<HolidayGroup> newGroups = scheduleSvc.getHolidayList(deviceID);
    System.out.printf(">>> Sample Holiday Groups: %s\n\n", newGroups);

    // Restore the schedules
    scheduleSvc.deleteAll(deviceID);
    scheduleSvc.deleteAllHoliday(deviceID);

    scheduleSvc.add(deviceID, origSchedules);
    scheduleSvc.addHoliday(deviceID, origGroups);
  }
  
  HolidaySchedule makeHolidayGroup(int deviceID) throws Exception {
    ArrayList<Holiday> holidayList = new ArrayList<Holiday>();
    holidayList.add(Holiday.newBuilder().setDate(0).setRecurrence(HolidayRecurrence.RECUR_YEARLY).build()); // Jan. 1
    holidayList.add(Holiday.newBuilder().setDate(358).setRecurrence(HolidayRecurrence.RECUR_YEARLY).build());; // Dec. 25 in non leap year, 359 in leap year
    HolidayGroup holidayGroup = HolidayGroup.newBuilder().setID(SAMPLE_HOLIDAY_GROUP_ID).setName("Sample Holiday Group").addAllHolidays(holidayList).build();

    ArrayList<TimePeriod> holidayPeriods = new ArrayList<TimePeriod>();
    holidayPeriods.add(TimePeriod.newBuilder().setStartTime(600).setEndTime(720).build()); // 10 am ~ 12 pm
    DaySchedule daySchedule = DaySchedule.newBuilder().addAllPeriods(holidayPeriods).build();
    HolidaySchedule holidaySchedule = HolidaySchedule.newBuilder().setGroupID(SAMPLE_HOLIDAY_GROUP_ID).setDaySchedule(daySchedule).build();

    ArrayList<HolidayGroup> holidayGroups = new ArrayList<HolidayGroup>();
    holidayGroups.add(holidayGroup);

    scheduleSvc.addHoliday(deviceID, holidayGroups);

    return holidaySchedule;
  }

  void makeWeeklySchedule(int deviceID, HolidaySchedule holidaySchedule) throws Exception {
    ArrayList<TimePeriod> weekdayPeriods = new ArrayList<TimePeriod>();
    weekdayPeriods.add(TimePeriod.newBuilder().setStartTime(540).setEndTime(720).build()); // 9 am ~ 12 pm
    weekdayPeriods.add(TimePeriod.newBuilder().setStartTime(780).setEndTime(1080).build()); // 1 pm ~ 6 pm
    DaySchedule weekdaySchedule = DaySchedule.newBuilder().addAllPeriods(weekdayPeriods).build();
    
    ArrayList<TimePeriod> weekendPeriods = new ArrayList<TimePeriod>();
    weekendPeriods.add(TimePeriod.newBuilder().setStartTime(570).setEndTime(770).build()); // 9:30 am ~ 12:30 pm
    DaySchedule weekendSchedule = DaySchedule.newBuilder().addAllPeriods(weekendPeriods).build();

    ArrayList<DaySchedule> daySchedules = new ArrayList<DaySchedule>();
    daySchedules.add(0, weekendSchedule); // Sunday
    daySchedules.add(1, weekdaySchedule); // Monday
    daySchedules.add(2, weekdaySchedule); // Tuesday
    daySchedules.add(3, weekdaySchedule); // Wednesday
    daySchedules.add(4, weekdaySchedule); // Thursday
    daySchedules.add(5, weekdaySchedule); // Friday
    daySchedules.add(6, weekendSchedule); // Saturday

    WeeklySchedule weeklySchedule = WeeklySchedule.newBuilder().addAllDaySchedules(daySchedules).build();

    ScheduleInfo scheduleInfo = ScheduleInfo.newBuilder().setID(WEEKLY_SCHEDULE_ID).setName("Sample Weekly Schedule").setWeekly(weeklySchedule).addHolidays(holidaySchedule).build();
    
    ArrayList<ScheduleInfo> scheduleInfos = new ArrayList<ScheduleInfo>();
    scheduleInfos.add(scheduleInfo);

    scheduleSvc.add(deviceID, scheduleInfos);
  }

  void makeDailySchedule(int deviceID) throws Exception {
    ArrayList<TimePeriod> dayPeriods = new ArrayList<TimePeriod>();
    dayPeriods.add(TimePeriod.newBuilder().setStartTime(540).setEndTime(720).build()); // 9 am ~ 12 pm
    dayPeriods.add(TimePeriod.newBuilder().setStartTime(780).setEndTime(1080).build()); // 1 pm ~ 6 pm

    ArrayList<DaySchedule> daySchedules = new ArrayList<DaySchedule>();
    for(int i = 0; i < NUM_OF_DAY; i++) {
      daySchedules.add(DaySchedule.newBuilder().addAllPeriods(dayPeriods).build());
    }

    DailySchedule dailySchedule = DailySchedule.newBuilder().setStartDate(Calendar.getInstance().get(Calendar.DAY_OF_YEAR) - 1).addAllDaySchedules(daySchedules).build(); // 30 days starting from today

    ScheduleInfo scheduleInfo = ScheduleInfo.newBuilder().setID(DAILY_SCHEDULE_ID).setName("Sample Daily Schedule").setDaily(dailySchedule).build();
    
    ArrayList<ScheduleInfo> scheduleInfos = new ArrayList<ScheduleInfo>();
    scheduleInfos.add(scheduleInfo);

    scheduleSvc.add(deviceID, scheduleInfos);
  }
}

