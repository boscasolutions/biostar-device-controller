package com.supremainc.sdk.example.user.test;

import java.util.List;
import java.util.ArrayList;
import java.time.Instant;

import com.supremainc.sdk.example.client.GatewayClient;
import com.supremainc.sdk.user.UserGrpc;
import com.supremainc.sdk.user.UserHdr;
import com.supremainc.sdk.user.UserInfo;
import com.supremainc.sdk.user.UserSetting;
import com.supremainc.sdk.example.user.UserSvc;
import com.supremainc.sdk.connect.ConnectGrpc;
import com.supremainc.sdk.connect.ConnectInfo;
import com.supremainc.sdk.example.connect.ConnectSvc;
import com.supremainc.sdk.event.EventGrpc;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.device.DeviceSvc;
import com.supremainc.sdk.device.DeviceGrpc;
import com.supremainc.sdk.device.DeviceCapability;
import com.supremainc.sdk.device.Type;
import com.supremainc.sdk.auth.AuthGrpc;
import com.supremainc.sdk.auth.AuthConfig;
import com.supremainc.sdk.auth.AuthMode;
import com.supremainc.sdk.example.auth.AuthSvc;
import com.supremainc.sdk.card.CardGrpc;
import com.supremainc.sdk.example.card.CardSvc;
import com.supremainc.sdk.finger.FingerGrpc;
import com.supremainc.sdk.example.finger.FingerSvc;
import com.supremainc.sdk.face.FaceGrpc;
import com.supremainc.sdk.example.face.FaceSvc;


public class UserTest {
  private static final String CA_FILE = "../cert/gateway/ca.crt";

  private static final String GATEWAY_ADDR = "192.168.8.98";
  private static final int GATEWAY_PORT = 4000;

  private static final String DEVICE_ADDR = "192.168.8.227";
  private static final int DEVICE_PORT = 51211;
  private static final boolean DEVICE_USE_SSL = false;  

  private static final String CODE_MAP_FILE = "./event_code.json";

  private GatewayClient gatewayClient;
  private UserSvc userSvc;
  private ConnectSvc connectSvc;
  private EventSvc eventSvc;
  private DeviceSvc deviceSvc;
  private AuthSvc authSvc;
  private CardSvc cardSvc;
  private FingerSvc fingerSvc;
  private FaceSvc faceSvc;

  public UserTest(GatewayClient client) {
    gatewayClient = client;

    connectSvc = new ConnectSvc(ConnectGrpc.newBlockingStub(client.getChannel())); 
    userSvc = new UserSvc(UserGrpc.newBlockingStub(client.getChannel())); 
    eventSvc = new EventSvc(EventGrpc.newBlockingStub(client.getChannel())); 
    deviceSvc = new DeviceSvc(DeviceGrpc.newBlockingStub(client.getChannel()));
    authSvc = new AuthSvc(AuthGrpc.newBlockingStub(client.getChannel()));
    cardSvc = new CardSvc(CardGrpc.newBlockingStub(client.getChannel()));
    fingerSvc = new FingerSvc(FingerGrpc.newBlockingStub(client.getChannel()));
    faceSvc = new FaceSvc(FaceGrpc.newBlockingStub(client.getChannel()));
  }

  public static void main(String[] args) throws Exception {
    GatewayClient client = new GatewayClient();

    try {
      client.connect(CA_FILE, GATEWAY_ADDR, GATEWAY_PORT);
    } catch (Exception e) {
      System.out.printf("Cannot connect to the server: %s", e); 
      System.exit(-1);
    }

    UserTest userTest = new UserTest(client);

    int deviceID = 0;

    try {
      ConnectInfo connInfo = ConnectInfo.newBuilder().setIPAddr(DEVICE_ADDR).setPort(DEVICE_PORT).setUseSSL(DEVICE_USE_SSL).build();

      deviceID = userTest.connectSvc.connect(connInfo);      
    } catch (Exception e) {
      System.out.printf("Cannot connect to the device: %s", e); 
      client.close();
      System.exit(-1);
    }

    DeviceCapability capability = null;

    try {
      capability = userTest.deviceSvc.getCapability(deviceID);

      System.out.printf("Device Capability: \n%s\n\n", capability); 
    } catch (Exception e) {
      System.out.printf("Cannot get the device info: %s", e); 
      client.close();
      System.exit(-1);
    }

    try {
      AuthTest authTest = new AuthTest(userTest.authSvc);
      AuthConfig origAuthConfig = authTest.prepareAuthConfig(deviceID);

      LogTest logTest = new LogTest(userTest.eventSvc);

      userTest.eventSvc.initCodeMap(CODE_MAP_FILE);
      userTest.eventSvc.startMonitoring(deviceID);
      userTest.eventSvc.setEventCallback(logTest);

      List<String> testUserIDs = userTest.enrollUser(deviceID, capability.getExtendedAuthSupported());
      String userID = testUserIDs.get(0);

      if (capability.getCardInputSupported()) {
        CardTest cardTest = new CardTest(userTest.cardSvc, userTest.userSvc);
        cardTest.test(deviceID, userID);
      } else {
        System.out.printf("!! The device %d does not support cards. Skip the card test.\n", deviceID);
      }

      if (capability.getFingerprintInputSupported()) {
        FingerTest fingerTest = new FingerTest(userTest.fingerSvc, userTest.userSvc);
        fingerTest.test(deviceID, userID);
      } else {
        System.out.printf("!! The device %d does not support fingerprints. Skip the fingerprint test.\n", deviceID);
      }    
      
      if (capability.getFaceInputSupported()) {
        FaceTest faceTest = new FaceTest(userTest.faceSvc, userTest.userSvc);
        faceTest.test(deviceID, userID);
      } else {
        System.out.printf("!! The device %d does not support faces. Skip the face test.\n", deviceID);
      }        

      authTest.test(deviceID, capability.getExtendedAuthSupported());

      userTest.eventSvc.stopMonitoring(deviceID); 

      logTest.printUserLog(deviceID, userID);

      userTest.userSvc.delete(deviceID, testUserIDs);

      userTest.authSvc.setConfig(deviceID, origAuthConfig);
    } catch (Exception e) {
      System.out.printf("Cannot complete the user test for device %d: %s", deviceID, e); 
    } finally {
      userTest.connectSvc.disconnect(deviceID);
      client.close();
    } 
  }

  public List<String> enrollUser(int deviceID, boolean extendedAuthSupported) throws Exception {
    List<UserHdr> userHdrs = userSvc.getList(deviceID);

    System.out.printf("\nExisting User List: \n%s\n\n", userHdrs); 

    String newUserID = String.format("%d", Instant.now().getEpochSecond());

    List<UserInfo> newUsers = new ArrayList<UserInfo>();
    
    UserHdr hdr = UserHdr.newBuilder().setID(newUserID).build();
    UserSetting setting;

    if (extendedAuthSupported) {
      setting = UserSetting.newBuilder()
                  .setCardAuthExtMode(AuthMode.AUTH_EXT_MODE_CARD_ONLY_VALUE)
                  .setFingerAuthExtMode(AuthMode.AUTH_EXT_MODE_FINGERPRINT_ONLY_VALUE)
                  .setFaceAuthExtMode(AuthMode.AUTH_EXT_MODE_FACE_ONLY_VALUE)
                  .build();
    } else {
      setting = UserSetting.newBuilder()
                  .setCardAuthMode(AuthMode.AUTH_MODE_CARD_ONLY_VALUE)
                  .setBiometricAuthMode(AuthMode.AUTH_MODE_BIOMETRIC_ONLY_VALUE)
                  .build();
    }

    newUsers.add(UserInfo.newBuilder().setHdr(hdr).setSetting(setting).build());

    userSvc.enroll(deviceID, newUsers);

    List<String> newUserIDs = new ArrayList<String>();
    newUserIDs.add(newUserID);

    newUsers = userSvc.getUser(deviceID, newUserIDs);

    System.out.printf("\nTest User: \n%s\n\n", newUsers.get(0));

    return newUserIDs;
  }

}

