package com.supremainc.sdk.example.cli;

import java.util.Scanner;

public class KeyInput {
  public static void pressEnter(String msg) {
    Scanner input = new Scanner(System.in);
    System.out.printf("%s", msg);
    input.nextLine();
  }
}