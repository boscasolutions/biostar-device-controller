package com.supremainc.sdk.example.user;

import java.util.List;

import com.supremainc.sdk.user.GetListRequest;
import com.supremainc.sdk.user.GetListResponse;
import com.supremainc.sdk.user.GetRequest;
import com.supremainc.sdk.user.GetResponse;
import com.supremainc.sdk.user.EnrollRequest;
import com.supremainc.sdk.user.EnrollResponse;
import com.supremainc.sdk.user.EnrollMultiRequest;
import com.supremainc.sdk.user.EnrollMultiResponse;
import com.supremainc.sdk.user.UpdateRequest;
import com.supremainc.sdk.user.UpdateResponse;
import com.supremainc.sdk.user.UpdateMultiRequest;
import com.supremainc.sdk.user.UpdateMultiResponse;
import com.supremainc.sdk.user.DeleteRequest;
import com.supremainc.sdk.user.DeleteResponse;
import com.supremainc.sdk.user.DeleteMultiRequest;
import com.supremainc.sdk.user.DeleteMultiResponse;
import com.supremainc.sdk.user.DeleteAllMultiRequest;
import com.supremainc.sdk.user.DeleteAllMultiResponse;
import com.supremainc.sdk.user.UserGrpc;
import com.supremainc.sdk.user.UserHdr;
import com.supremainc.sdk.user.UserInfo;
import com.supremainc.sdk.user.UserCard;
import com.supremainc.sdk.user.SetCardRequest;
import com.supremainc.sdk.user.SetCardResponse;
import com.supremainc.sdk.user.UserFinger;
import com.supremainc.sdk.user.SetFingerRequest;
import com.supremainc.sdk.user.SetFingerResponse;
import com.supremainc.sdk.user.UserFace;
import com.supremainc.sdk.user.SetFaceRequest;
import com.supremainc.sdk.user.SetFaceResponse;
import com.supremainc.sdk.user.UserAccessGroup;
import com.supremainc.sdk.user.SetAccessGroupRequest;
import com.supremainc.sdk.user.SetAccessGroupResponse;
import com.supremainc.sdk.user.GetAccessGroupRequest;
import com.supremainc.sdk.user.GetAccessGroupResponse;

public class UserSvc {
  private final UserGrpc.UserBlockingStub userStub;

  public UserSvc(UserGrpc.UserBlockingStub stub) {
    userStub = stub;
  }

  public List<UserHdr> getList(int deviceID) throws Exception {
    GetListRequest request = GetListRequest.newBuilder().setDeviceID(deviceID).build();
    GetListResponse response = userStub.getList(request);

    return response.getHdrsList();
  } 

  public List<UserInfo> getUser(int deviceID, List<String> userIDs) throws Exception {
    GetRequest request = GetRequest.newBuilder().setDeviceID(deviceID).addAllUserIDs(userIDs).build();
    GetResponse response = userStub.get(request);

    return response.getUsersList();
  }

  public void enroll(int deviceID, List<UserInfo> users) throws Exception {
    EnrollRequest request = EnrollRequest.newBuilder().setDeviceID(deviceID).addAllUsers(users).build();
    EnrollResponse response = userStub.enroll(request);
  }

  public void enrollMulti(List<Integer> deviceIDs, List<UserInfo> users) throws Exception {
    EnrollMultiRequest request = EnrollMultiRequest.newBuilder().addAllDeviceIDs(deviceIDs).addAllUsers(users).build();
    EnrollMultiResponse response = userStub.enrollMulti(request);
  }  

  public void update(int deviceID, List<UserInfo> users) throws Exception {
    UpdateRequest request = UpdateRequest.newBuilder().setDeviceID(deviceID).addAllUsers(users).build();
    UpdateResponse response = userStub.update(request);
  }

  public void updateMulti(List<Integer> deviceIDs, List<UserInfo> users) throws Exception {
    UpdateMultiRequest request = UpdateMultiRequest.newBuilder().addAllDeviceIDs(deviceIDs).addAllUsers(users).build();
    UpdateMultiResponse response = userStub.updateMulti(request);
  }  

  public void delete(int deviceID, List<String> userIDs) throws Exception {
    DeleteRequest request = DeleteRequest.newBuilder().setDeviceID(deviceID).addAllUserIDs(userIDs).build();
    DeleteResponse response = userStub.delete(request);
  }

  public void deleteMulti(List<Integer> deviceIDs, List<String> userIDs) throws Exception {
    DeleteMultiRequest request = DeleteMultiRequest.newBuilder().addAllDeviceIDs(deviceIDs).addAllUserIDs(userIDs).build();
    DeleteMultiResponse response = userStub.deleteMulti(request);
  }  

  public void deleteAllMulti(List<Integer> deviceIDs) throws Exception {
    DeleteAllMultiRequest request = DeleteAllMultiRequest.newBuilder().addAllDeviceIDs(deviceIDs).build();
    DeleteAllMultiResponse response = userStub.deleteAllMulti(request);
  }  

  public void setCard(int deviceID, List<UserCard> userCards) throws Exception {
    SetCardRequest request = SetCardRequest.newBuilder().setDeviceID(deviceID).addAllUserCards(userCards).build();
    SetCardResponse response = userStub.setCard(request);
  }

  public void setFinger(int deviceID, List<UserFinger> userFingers) throws Exception {
    SetFingerRequest request = SetFingerRequest.newBuilder().setDeviceID(deviceID).addAllUserFingers(userFingers).build();
    SetFingerResponse response = userStub.setFinger(request);
  }

  public void setFace(int deviceID, List<UserFace> userFaces) throws Exception {
    SetFaceRequest request = SetFaceRequest.newBuilder().setDeviceID(deviceID).addAllUserFaces(userFaces).build();
    SetFaceResponse response = userStub.setFace(request);
  }  

  public void setAccessGroup(int deviceID, List<UserAccessGroup> userAccessGroups) throws Exception {
    SetAccessGroupRequest request = SetAccessGroupRequest.newBuilder().setDeviceID(deviceID).addAllUserAccessGroups(userAccessGroups).build();
    SetAccessGroupResponse response = userStub.setAccessGroup(request);
  }    

  public List<UserAccessGroup> getAccessGroup(int deviceID, List<String> userIDs) throws Exception {
    GetAccessGroupRequest request = GetAccessGroupRequest.newBuilder().setDeviceID(deviceID).addAllUserIDs(userIDs).build();
    GetAccessGroupResponse response = userStub.getAccessGroup(request);

    return response.getUserAccessGroupsList();
  }    

}