package com.supremainc.sdk.example.user.test;

import java.util.List;
import java.util.ListIterator;
import java.time.Instant;

import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.event.EventCallback;
import com.supremainc.sdk.event.EventLog;
import com.supremainc.sdk.event.EventFilter;

class LogTest implements EventCallback {
  private EventSvc eventSvc;
  private int firstEventID;

  public LogTest(EventSvc svc) {
    eventSvc = svc;
    firstEventID = 0;
  }

  public void handle(EventLog event) {
    if(firstEventID == 0) {
      firstEventID = event.getID();
    }

    System.out.printf("\nRealtime Event:\n%s\n", event);
  }

  public void printUserLog(int deviceID, String userID) throws Exception {
    System.out.printf("\n===== Log Events of User %s =====\n\n", userID);

    EventFilter filter = EventFilter.newBuilder().setUserID(userID).build();

    List<EventLog> events = eventSvc.getLogWithFilter(deviceID, firstEventID, 0, filter);
    ListIterator<EventLog> eventIter = events.listIterator();

    while(eventIter.hasNext()) {
      EventLog event = eventIter.next();
      printEvent(event);
    }

    System.out.printf("\n===== Verify Success Events of User %s =====\n\n", userID);

    filter = EventFilter.newBuilder().setUserID(userID).setEventCode(0x1000).build(); // BS2_EVENT_VERIFY_SUCCESS

    events = eventSvc.getLogWithFilter(deviceID, firstEventID, 0, filter);
    eventIter = events.listIterator();

    while(eventIter.hasNext()) {
      EventLog event = eventIter.next();
      printEvent(event);
    }
  }

  public void printEvent(EventLog event) {
    System.out.printf("%s: Device %d, User %s, %s\n", Instant.ofEpochSecond(event.getTimestamp()), event.getDeviceID(), event.getUserID(), eventSvc.getEventString(event.getEventCode(), event.getSubCode()));
  }
}

