package com.supremainc.sdk.example.client;

import io.grpc.ManagedChannel;

import java.util.concurrent.TimeUnit;

public class GrpcClient {
  protected ManagedChannel channel;

  public ManagedChannel getChannel() {
    return channel;
  }

  public void close() throws InterruptedException {
    if(channel != null) {
      channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
      channel = null;
    }
  }
}

