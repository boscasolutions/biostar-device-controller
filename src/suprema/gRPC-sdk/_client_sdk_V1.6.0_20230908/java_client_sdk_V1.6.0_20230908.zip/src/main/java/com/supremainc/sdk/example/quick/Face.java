package com.supremainc.sdk.example.quick;

import java.io.FileOutputStream;
import java.util.Arrays;
import com.google.protobuf.ByteString;

import com.supremainc.sdk.example.face.FaceSvc;
import com.supremainc.sdk.face.FaceData;
import com.supremainc.sdk.face.FaceConfig;
import com.supremainc.sdk.face.FaceEnrollThreshold;

class FaceTest {
  private static final String FACE_IMAGE_FILE = "./face.bmp";

  private FaceSvc faceSvc;

  public FaceTest(FaceSvc svc) {
    faceSvc = svc;
  }

  public void test(int deviceID) throws Exception {
    FaceConfig faceConfig = faceSvc.getConfig(deviceID);

    System.out.printf("Face config: \n%s\n\n", faceConfig);

    System.out.println(">>> Scan a face...");

    FaceData faceData = faceSvc.scan(deviceID, faceConfig.getEnrollThreshold());

    for (int i = 0; i < faceData.getTemplatesCount(); i++) {
      System.out.printf("Template data[%d]: \n%s\n\n", i, faceData.getTemplates(i));
    }

    FileOutputStream bmpFile = new FileOutputStream(FACE_IMAGE_FILE);
    bmpFile.write(faceData.getImageData().toByteArray());
    bmpFile.close();
  }
}

