package com.supremainc.sdk.example.thermal.test;

import java.util.List;
import java.util.ListIterator;
import java.time.Instant;

import com.supremainc.sdk.example.thermal.ThermalSvc;
import com.supremainc.sdk.thermal.TemperatureLog;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.event.EventCallback;
import com.supremainc.sdk.event.EventLog;

class LogTest implements EventCallback {
  private ThermalSvc thermalSvc;
  private EventSvc eventSvc;
  private int firstEventID;

  public LogTest(ThermalSvc thermalSvc, EventSvc eventSvc) {
    this.thermalSvc = thermalSvc;
    this.eventSvc = eventSvc;
    firstEventID = 0;
  }

  public void handle(EventLog event) {
    if(firstEventID == 0) {
      firstEventID = event.getID();
    }

    System.out.printf("\nRealtime Event:\n%s\n", event);
  }

  public void test(int deviceID) throws Exception {
    System.out.printf("\n===== Log Events with Temperature =====\n\n");

    List<TemperatureLog> events = thermalSvc.getTemperatureLog(deviceID, firstEventID, 0);
    ListIterator<TemperatureLog> eventIter = events.listIterator();

    while(eventIter.hasNext()) {
      TemperatureLog event = eventIter.next();
      printEvent(event);
    }
  }

  public void printEvent(TemperatureLog event) {
    long userID = 0;
    
    try {
      userID = Long.parseLong(event.getUserID());
    }
    catch(NumberFormatException nfe) {
      // ignore invalid userID
    }

    if(userID == 0 || userID == 0xffffffff) { // no user ID
      System.out.printf("%s: Device %d, %s, Temperature %d\n", Instant.ofEpochSecond(event.getTimestamp()), event.getDeviceID(), eventSvc.getEventString(event.getEventCode(), event.getSubCode()), event.getTemperature());
    } else {
      System.out.printf("%s: Device %d, User %d, %s, Temperature %d\n", Instant.ofEpochSecond(event.getTimestamp()), event.getDeviceID(), userID, eventSvc.getEventString(event.getEventCode(), event.getSubCode()), event.getTemperature());
    }
  }
}


