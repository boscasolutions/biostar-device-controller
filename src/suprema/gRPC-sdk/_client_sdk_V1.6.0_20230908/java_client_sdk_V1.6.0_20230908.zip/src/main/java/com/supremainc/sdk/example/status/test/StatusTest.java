package com.supremainc.sdk.example.status.test;

import com.supremainc.sdk.example.client.GatewayClient;
import com.supremainc.sdk.status.StatusGrpc;
import com.supremainc.sdk.status.StatusConfig;
import com.supremainc.sdk.example.status.StatusSvc;
import com.supremainc.sdk.connect.ConnectGrpc;
import com.supremainc.sdk.connect.ConnectInfo;
import com.supremainc.sdk.example.connect.ConnectSvc;
import com.supremainc.sdk.device.DeviceGrpc;
import com.supremainc.sdk.device.CapabilityInfo;
import com.supremainc.sdk.device.DeviceCapability;
import com.supremainc.sdk.device.Type;
import com.supremainc.sdk.example.device.DeviceSvc;

public class StatusTest {
  private static final String CA_FILE = "../cert/gateway/ca.crt";

  private static final String GATEWAY_ADDR = "192.168.8.98";
  private static final int GATEWAY_PORT = 4000;

  private static final String DEVICE_ADDR = "192.168.8.205";
  private static final int DEVICE_PORT = 51211;
  private static final boolean DEVICE_USE_SSL = false;  

  private static final String CODE_MAP_FILE = "./event_code.json";

  private GatewayClient gatewayClient;
  private StatusSvc statusSvc;
  private ConnectSvc connectSvc;
  private DeviceSvc deviceSvc;

  public StatusTest(GatewayClient client) {
    gatewayClient = client;

    connectSvc = new ConnectSvc(ConnectGrpc.newBlockingStub(client.getChannel())); 
    statusSvc = new StatusSvc(StatusGrpc.newBlockingStub(client.getChannel())); 
    deviceSvc = new DeviceSvc(DeviceGrpc.newBlockingStub(client.getChannel())); 
  }

  public static void main(String[] args) throws Exception {
    GatewayClient client = new GatewayClient();

    try {
      client.connect(CA_FILE, GATEWAY_ADDR, GATEWAY_PORT);
    } catch (Exception e) {
      System.out.printf("Cannot connect to the server: %s", e); 
      System.exit(-1);
    }

    StatusTest statusTest = new StatusTest(client);

    int deviceID = 0;

    try {
      ConnectInfo connInfo = ConnectInfo.newBuilder().setIPAddr(DEVICE_ADDR).setPort(DEVICE_PORT).setUseSSL(DEVICE_USE_SSL).build();

      deviceID = statusTest.connectSvc.connect(connInfo);      
    } catch (Exception e) {
      System.out.printf("Cannot connect to the device: %s", e); 
      client.close();
      System.exit(-1);
    }

    try {
      DeviceCapability capability = statusTest.deviceSvc.getCapability(deviceID);

      if (capability.getDisplaySupported()) {
        System.out.printf("Status configuration is effective only for headless devices: %s\n", capability.getDisplaySupported());
        statusTest.connectSvc.disconnect(deviceID);
        client.close();
        System.exit(-1);  
      }

    } catch (Exception e) {
      System.out.printf("Cannot get the device info: %s", e); 
      statusTest.connectSvc.disconnect(deviceID);
      client.close();
      System.exit(-1);
    }

    try {
      new ConfigTest(statusTest.statusSvc).test(deviceID);
    } catch (Exception e) {
      System.out.printf("Cannot complete the status test for device %d: %s", deviceID, e); 
      e.printStackTrace(System.out);
    } finally {
      statusTest.connectSvc.disconnect(deviceID);
      client.close();
    }
  }

  public static boolean isHeadless(CapabilityInfo capInfo) {
    switch (capInfo.getType()) {
      case BIOENTRY_P2:
      case BIOENTRY_R2:
      case BIOENTRY_W2:
      case XPASS2:
      case XPASS2_KEYPAD:
      case XPASS_D2:
      case XPASS_D2_KEYPAD:
      case XPASS_S2:
        return true;
      
      default:
        return false;
    }
  }
}

