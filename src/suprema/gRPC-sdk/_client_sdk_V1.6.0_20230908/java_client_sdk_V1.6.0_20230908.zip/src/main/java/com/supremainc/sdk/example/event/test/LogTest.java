package com.supremainc.sdk.example.event.test;

import java.util.List;
import java.util.ListIterator;
import java.time.Instant;

import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.event.EventCallback;
import com.supremainc.sdk.event.EventLog;
import com.supremainc.sdk.event.EventFilter;
import com.supremainc.sdk.example.cli.KeyInput;

class LogTest implements EventCallback {
  private EventSvc eventSvc;
  private int firstEventID;

  private static final String CODE_MAP_FILE = "./event_code.json";
  private static final int MAX_NUM_OF_EVENT = 32;

  public LogTest(EventSvc eventSvc) {
    this.eventSvc = eventSvc;
    firstEventID = 0;
  }

  public void handle(EventLog event) {
    if(firstEventID == 0) {
      firstEventID = event.getID();
    }

    System.out.printf("\nRealtime Event:\n%s\n", event);
  }

  public void test(int deviceID) throws Exception {
    eventSvc.initCodeMap(CODE_MAP_FILE);
    eventSvc.startMonitoring(deviceID);
    eventSvc.setEventCallback(this);

    System.out.printf("\n===== Event Test =====\n\n");

    KeyInput.pressEnter(">> Try to authenticate credentials to check real-time monitoring. And, press ENTER to read the generated event logs.\n");    

    if(firstEventID == 0) {
      System.out.printf("\n>> There is no new event. Just read %d event logs from the start.\n", MAX_NUM_OF_EVENT);
    } else {
      System.out.printf("\n>> Read new events starting from %d\n", firstEventID);		
    }    

    List<EventLog> events = eventSvc.getLog(deviceID, firstEventID, MAX_NUM_OF_EVENT);
    ListIterator<EventLog> eventIter = events.listIterator();

    while(eventIter.hasNext()) {
      EventLog event = eventIter.next();
      printEvent(event);
    }

    if(events.size() > 0 && firstEventID != 0) {
      EventFilter filter = EventFilter.newBuilder().setEventCode(events.get(0).getEventCode()).build();
      System.out.printf("\n>> Filter with event code %d\n", filter.getEventCode());		

      events = eventSvc.getLogWithFilter(deviceID, firstEventID, MAX_NUM_OF_EVENT, filter);
      eventIter = events.listIterator();

      while(eventIter.hasNext()) {
        EventLog event = eventIter.next();
        printEvent(event);
      }
    }
    
    eventSvc.stopMonitoring(deviceID);
  }

  public void printEvent(EventLog event) {
    System.out.printf("%s: Device %d, User %s, %s\n", Instant.ofEpochSecond(event.getTimestamp()), event.getDeviceID(), event.getUserID(), eventSvc.getEventString(event.getEventCode(), event.getSubCode()));
  }
}

