package com.supremainc.sdk.example.door;

import java.util.List;

import com.supremainc.sdk.door.GetListRequest;
import com.supremainc.sdk.door.GetListResponse;
import com.supremainc.sdk.door.GetStatusRequest;
import com.supremainc.sdk.door.GetStatusResponse;
import com.supremainc.sdk.door.AddRequest;
import com.supremainc.sdk.door.DeleteAllRequest;
import com.supremainc.sdk.door.LockRequest;
import com.supremainc.sdk.door.UnlockRequest;
import com.supremainc.sdk.door.ReleaseRequest;
import com.supremainc.sdk.door.SetAlarmRequest;
import com.supremainc.sdk.door.DoorGrpc;
import com.supremainc.sdk.door.DoorInfo;
import com.supremainc.sdk.door.Status;
import com.supremainc.sdk.door.AlarmFlag;
import com.supremainc.sdk.door.DoorFlag;
import com.supremainc.sdk.door.Status;

public class DoorSvc {
  private final DoorGrpc.DoorBlockingStub doorStub;

  public DoorSvc(DoorGrpc.DoorBlockingStub stub) {
    doorStub = stub;
  }

  public List<DoorInfo> getList(int deviceID) throws Exception {
    GetListRequest request = GetListRequest.newBuilder().setDeviceID(deviceID).build();
    GetListResponse response = doorStub.getList(request);

    return response.getDoorsList();
  } 

  public List<Status> getStatus(int deviceID) throws Exception {
    GetStatusRequest request = GetStatusRequest.newBuilder().setDeviceID(deviceID).build();
    GetStatusResponse response = doorStub.getStatus(request);

    return response.getStatusList();
  }  

  public void add(int deviceID, List<DoorInfo> doors) throws Exception {
    AddRequest request = AddRequest.newBuilder().setDeviceID(deviceID).addAllDoors(doors).build();
    doorStub.add(request);
  }

  public void deleteAll(int deviceID) throws Exception {
    DeleteAllRequest request = DeleteAllRequest.newBuilder().setDeviceID(deviceID).build();
    doorStub.deleteAll(request);
  }

  public void lock(int deviceID, List<Integer> doorIDs, DoorFlag doorFlag) throws Exception {
    LockRequest request = LockRequest.newBuilder().setDeviceID(deviceID).addAllDoorIDs(doorIDs).setDoorFlag(doorFlag.getNumber()).build();
    doorStub.lock(request);
  }  

  public void unlock(int deviceID, List<Integer> doorIDs, DoorFlag doorFlag) throws Exception {
    UnlockRequest request = UnlockRequest.newBuilder().setDeviceID(deviceID).addAllDoorIDs(doorIDs).setDoorFlag(doorFlag.getNumber()).build();
    doorStub.unlock(request);
  }  

  public void release(int deviceID, List<Integer> doorIDs, DoorFlag doorFlag) throws Exception {
    ReleaseRequest request = ReleaseRequest.newBuilder().setDeviceID(deviceID).addAllDoorIDs(doorIDs).setDoorFlag(doorFlag.getNumber()).build();
    doorStub.release(request);
  }  

  public void setAlarm(int deviceID, List<Integer> doorIDs, AlarmFlag alarmFlag) throws Exception {
    SetAlarmRequest request = SetAlarmRequest.newBuilder().setDeviceID(deviceID).addAllDoorIDs(doorIDs).setAlarmFlag(alarmFlag.getNumber()).build();
    doorStub.setAlarm(request);
  }  
}