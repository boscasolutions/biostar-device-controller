package com.supremainc.sdk.example.rtsp.test;

import com.supremainc.sdk.rtsp.RTSPConfig;
import com.supremainc.sdk.example.rtsp.RtspSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class ConfigTest {
  private RtspSvc rtspSvc;

  public ConfigTest(RtspSvc svc) {
    rtspSvc = svc;
  }

  public void test(int deviceID, RTSPConfig config) throws Exception {
    System.out.printf("\n===== Test for RTSPConfig =====\n\n");

    // Backup the original configuration
    RTSPConfig origConfig = config.toBuilder().build();

    RTSPConfig newConfig = config.toBuilder().setServerURL("rtsp.server.com").setServerPort(554).setUserID("RTSP User ID").setUserPW("2378129307").build();

    rtspSvc.setConfig(deviceID, newConfig.toBuilder().setEnabled(true).build());

    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");   
    
    // Restore the original configuration   
    rtspSvc.setConfig(deviceID, origConfig);
  }
}

