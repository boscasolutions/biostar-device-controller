package com.supremainc.sdk.example.system;

import com.supremainc.sdk.system.SystemConfig;
import com.supremainc.sdk.system.SystemGrpc;
import com.supremainc.sdk.system.GetConfigRequest;
import com.supremainc.sdk.system.GetConfigResponse;
import com.supremainc.sdk.system.SetConfigRequest;
import com.supremainc.sdk.system.SetConfigResponse;

public class SystemSvc {
  private final SystemGrpc.SystemBlockingStub systemStub;

  public SystemSvc(SystemGrpc.SystemBlockingStub stub) {
    systemStub = stub;
  }

  public SystemConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = systemStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, SystemConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = systemStub.setConfig(request);
  }
}