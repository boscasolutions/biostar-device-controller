package com.supremainc.sdk.example.thermal.test;

import com.supremainc.sdk.thermal.ThermalConfig;
import com.supremainc.sdk.thermal.CheckMode;
import com.supremainc.sdk.thermal.CheckOrder;
import com.supremainc.sdk.example.thermal.ThermalSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class ConfigTest {
  private ThermalSvc thermalSvc;

  public ConfigTest(ThermalSvc svc) {
    thermalSvc = svc;
  }

  public void test(int deviceID, ThermalConfig config) throws Exception {
    System.out.printf("\n===== Test for ThermalConfig =====\n\n");

    // Backup the original configuration
    ThermalConfig origConfig = config.toBuilder().build();

    // Set options for the test
    ThermalConfig newConfig = config.toBuilder().setAuditTemperature(true).setCheckMode(CheckMode.HARD).build();

    // (1) Set check order to AFTER_AUTH
    thermalSvc.setConfig(deviceID, newConfig.toBuilder().setCheckOrder(CheckOrder.AFTER_AUTH).build());

    System.out.printf("(1) The Check Order is set to AFTER_AUTH. The device will measure the temperature only after successful authentication. Try to authenticate faces.\n\n");
    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");

    // (2) Set check order to BEFORE_AUTH
    thermalSvc.setConfig(deviceID, newConfig.toBuilder().setCheckOrder(CheckOrder.BEFORE_AUTH).build());

    System.out.printf("(2) The Check Order is set to BEFORE_AUTH. The device will try to authenticate a user only when the user's temperature is within the threshold. Try to authenticate faces.\n\n");
    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");    

    // (3) Set check order to WITHOUT_AUTH
    thermalSvc.setConfig(deviceID, newConfig.toBuilder().setCheckOrder(CheckOrder.WITHOUT_AUTH).build());

    System.out.printf("(3) The Check Order is set to WITHOUT_AUTH. Any user whose temperature is within the threshold will be allowed to access. Try to authenticate faces.\n\n");
    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");    

    // (4) Set check order to AFTER_AUTH with too low threshold
    thermalSvc.setConfig(deviceID, newConfig.toBuilder().setCheckOrder(CheckOrder.AFTER_AUTH).setTemperatureThresholdHigh(3500).setTemperatureThresholdLow(3000).build());

    System.out.printf("(4) To reproduce the case of high temperature, the Check Order is set to AFTER_AUTH with the threshold of 35 degree Celsius. Most temperature check will fail, now. Try to authenticate faces.\n\n");
    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");   
    
    // Restore the original configuration   
    thermalSvc.setConfig(deviceID, origConfig);
  }
}

