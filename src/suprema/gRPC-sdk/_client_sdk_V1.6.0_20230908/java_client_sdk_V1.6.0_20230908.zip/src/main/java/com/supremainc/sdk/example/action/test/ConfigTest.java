package com.supremainc.sdk.example.action.test;

import java.util.ListIterator;
import java.util.ArrayList;

import com.supremainc.sdk.action.TriggerActionConfig;
import com.supremainc.sdk.action.Trigger;
import com.supremainc.sdk.action.TriggerActionConfig.TriggerAction;
import com.supremainc.sdk.action.TriggerType;
import com.supremainc.sdk.action.EventTrigger;
import com.supremainc.sdk.action.Signal;
import com.supremainc.sdk.action.RelayAction;
import com.supremainc.sdk.action.Action;
import com.supremainc.sdk.action.ActionType;
import com.supremainc.sdk.example.action.ActionSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class ConfigTest {
  private ActionSvc actionSvc;

  private static final int BS2_EVENT_VERIFY_FAIL = 0x1100;
  private static final int BS2_EVENT_IDENTIFY_FAIL = 0x1400;

  private static final int BS2_SUB_EVENT_CREDENTIAL_CARD = 0x02;
  private static final int BS2_SUB_EVENT_CREDENTIAL_FINGER = 0x04;
  
  private static final int FAIL_SIGNAL_COUNT = 3;
  private static final int ON_DURATION_MS = 500;
  private static final int OFF_DURATION_MS = 500;
  private static final int RELAY_INDEX = 0;

  public ConfigTest(ActionSvc svc) {
    actionSvc = svc;
  }

  public void test(int deviceID) throws Exception {
    // Backup the original configuration
    TriggerActionConfig origConfig = actionSvc.getConfig(deviceID);
    System.out.printf("Original Config: %s\n\n", origConfig);

    testEventTrigger(deviceID);

    // Restore the original configuration
    actionSvc.setConfig(deviceID, origConfig);
  }

  public void testEventTrigger(int deviceID) throws Exception {
    System.out.printf("\n===== Trigger & Action Test =====\n\n");

    // make event triggers
    EventTrigger cardFailEventTrigger = EventTrigger.newBuilder().setEventCode(BS2_EVENT_VERIFY_FAIL | BS2_SUB_EVENT_CREDENTIAL_CARD).build();
    Trigger cardFailTrigger = Trigger.newBuilder().setDeviceID(deviceID).setType(TriggerType.TRIGGER_EVENT).setEvent(cardFailEventTrigger).build();

    EventTrigger fingerFailEventTrigger = EventTrigger.newBuilder().setEventCode(BS2_EVENT_IDENTIFY_FAIL | BS2_SUB_EVENT_CREDENTIAL_FINGER).build();
    Trigger fingerFailTrigger = Trigger.newBuilder().setDeviceID(deviceID).setType(TriggerType.TRIGGER_EVENT).setEvent(fingerFailEventTrigger).build();

    // make a relay action
    Signal failSignal = Signal.newBuilder().setCount(FAIL_SIGNAL_COUNT).setOnDuration(ON_DURATION_MS).setOffDuration(OFF_DURATION_MS).build();
    RelayAction failRelayAction = RelayAction.newBuilder().setRelayIndex(RELAY_INDEX).setSignal(failSignal).build();
    Action failAction = Action.newBuilder().setDeviceID(deviceID).setType(ActionType.ACTION_RELAY).setRelay(failRelayAction).build();

    ArrayList<TriggerAction> triggerActions = new ArrayList<TriggerAction>();
    triggerActions.add(TriggerAction.newBuilder().setTrigger(cardFailTrigger).setAction(failAction).build());
    triggerActions.add(TriggerAction.newBuilder().setTrigger(fingerFailTrigger).setAction(failAction).build());

    TriggerActionConfig config = TriggerActionConfig.newBuilder().addAllTriggerActions(triggerActions).build();
    actionSvc.setConfig(deviceID, config);
    
    TriggerActionConfig newConfig = actionSvc.getConfig(deviceID);
    System.out.printf("Test Config: %s\n\n", newConfig);

    System.out.printf(">> Try to authenticate a unregistered card or finger. It should trigger a relay signal.\n");
    KeyInput.pressEnter(">> Press ENTER to finish the test.\n");
  }
}