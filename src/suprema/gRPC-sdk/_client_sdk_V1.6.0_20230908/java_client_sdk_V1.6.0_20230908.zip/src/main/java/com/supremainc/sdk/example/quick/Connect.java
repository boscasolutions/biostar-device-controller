package com.supremainc.sdk.example.quick;

import java.util.List;

import com.supremainc.sdk.connect.DeviceInfo;
import com.supremainc.sdk.connect.ConnectInfo;

import com.supremainc.sdk.example.connect.ConnectSvc;
import com.supremainc.sdk.example.connect_master.ConnectMasterSvc;

class ConnectTest {
  private ConnectSvc connectSvc;
  private ConnectMasterSvc connectMasterSvc;

  public ConnectTest(ConnectSvc svc, ConnectMasterSvc masterSvc) {
    connectSvc = svc;
    connectMasterSvc = masterSvc;
  }

  public int test(String deviceAddr, int devicePort, boolean useSSL) throws Exception {
    List<DeviceInfo> devInfo = connectSvc.getDeviceList();

    System.out.printf("Device list before connection: \n%s\n\n", devInfo);

    ConnectInfo connInfo = ConnectInfo.newBuilder().setIPAddr(deviceAddr).setPort(devicePort).setUseSSL(useSSL).build();

    int deviceID = connectSvc.connect(connInfo);

    devInfo = connectSvc.getDeviceList();

    System.out.printf("Device list after connection: \n%s\n\n", devInfo);

    return deviceID;
  }

  public int testMaster(String gatewayID, String deviceAddr, int devicePort, boolean useSSL) throws Exception {
    List<DeviceInfo> devInfo = connectMasterSvc.getDeviceList(gatewayID);

    System.out.printf("Device list before connection: \n%s\n\n", devInfo);

    ConnectInfo connInfo = ConnectInfo.newBuilder().setIPAddr(deviceAddr).setPort(devicePort).setUseSSL(useSSL).build();

    int deviceID = connectMasterSvc.connect(gatewayID, connInfo);

    devInfo = connectMasterSvc.getDeviceList(gatewayID);

    System.out.printf("Device list after connection: \n%s\n\n", devInfo);

    return deviceID;
  }  
}
