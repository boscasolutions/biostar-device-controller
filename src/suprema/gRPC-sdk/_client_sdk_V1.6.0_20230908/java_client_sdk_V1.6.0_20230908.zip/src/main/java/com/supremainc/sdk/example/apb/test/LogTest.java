package com.supremainc.sdk.example.apb.test;

import java.util.List;
import java.time.Instant;

import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.event.EventCallback;
import com.supremainc.sdk.event.EventLog;

class LogTest implements EventCallback {
  private EventSvc eventSvc;

  private static final int FIRST_APB_EVENT = 0x6000; // BS2_EVENT_ZONE_APB_VIOLATION
  private static final int LAST_APB_EVENT = 0x6200; // BS2_EVENT_ZONE_APB_ALARM_CLEAR

  public LogTest(EventSvc svc) {
    eventSvc = svc;
  }

  public void handle(EventLog eventLog) {
    if(eventLog.getEventCode() >= FIRST_APB_EVENT && eventLog.getEventCode() <= LAST_APB_EVENT) {
      System.out.printf("%s: APB Zone %d, User %s, %s\n", Instant.ofEpochSecond(eventLog.getTimestamp()), eventLog.getEntityID(), eventLog.getUserID(), eventSvc.getEventString(eventLog.getEventCode(), eventLog.getSubCode()));
    } else {
      System.out.printf("%s: Device %d, User %s, %s\n", Instant.ofEpochSecond(eventLog.getTimestamp()), eventLog.getDeviceID(), eventLog.getUserID(), eventSvc.getEventString(eventLog.getEventCode(), eventLog.getSubCode()));
    }
  }
}

