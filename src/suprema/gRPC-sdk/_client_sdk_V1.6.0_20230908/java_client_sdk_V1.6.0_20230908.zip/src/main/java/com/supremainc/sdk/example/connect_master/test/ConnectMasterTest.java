package com.supremainc.sdk.example.connect_master.test;

import java.util.Iterator;

import io.grpc.Context;
import io.grpc.Context.CancellableContext;

import com.supremainc.sdk.connect_master.ConnectMasterGrpc;
import com.supremainc.sdk.connect.Status;
import com.supremainc.sdk.connect.StatusChange;
import com.supremainc.sdk.example.master.MasterClient;
import com.supremainc.sdk.example.connect_master.ConnectMasterSvc;
import com.supremainc.sdk.example.connect_master.test.cli.MainMenu;
import com.supremainc.sdk.example.err.ErrSvc;

public class ConnectMasterTest {
  private static final String MASTER_CA_FILE = "cert/master/ca.crt";
  private static final String MASTER_ADDR = "192.168.0.2";
  private static final int MASTER_PORT = 4010;
  private static final String TENANT_CERT_FILE = "cert/master/tenant1.crt";
  private static final String TENANT_KEY_FILE = "cert/master/tenant1_key.pem";
  private static final String ADMIN_CERT_FILE = "cert/master/admin.crt";
  private static final String ADMIN_KEY_FILE = "cert/master/admin_key.pem";

  private static final String TENANT_ID = "tenant1";
  private static final String GATEWAY_ID = "gateway1";

  private MasterClient masterClient;
  private ConnectMasterSvc connectMasterSvc;

  CancellableContext monitoringCtx;

  private MainMenu mainMenu;

  public ConnectMasterTest(MasterClient client, String gatewayID) {
    masterClient = client;

    connectMasterSvc = new ConnectMasterSvc(ConnectMasterGrpc.newBlockingStub(client.getChannel()).withCallCredentials(client.getCredentials())); 
    mainMenu = new MainMenu(connectMasterSvc, gatewayID);

    monitoringCtx = null;
  }

  public void showMainMenu() {
    mainMenu.show();
  }

  public void startMonitoring() {
    new Thread(new StatusMonitoring()).start();
  }

  public void stopMonitoring() {
    if(monitoringCtx != null) {
      monitoringCtx.cancel(null);
    }
  }

  class StatusMonitoring implements Runnable {
    public void run() {
      monitoringCtx = Context.current().withCancellation();
      Context prevCtx = monitoringCtx.attach();
  
      try {
        Iterator<StatusChange> statusStream = connectMasterSvc.subscribe();
  
        while(statusStream.hasNext()) {
          StatusChange change = statusStream.next();

          if(change.getStatus() != Status.TCP_NOT_ALLOWED && change.getStatus() != Status.TLS_NOT_ALLOWED) {
            System.out.printf("\n[STATUS] Device status change: \n%s\n", change);
          }
        }
      } catch(Exception e) {
        io.grpc.Status errStatus = io.grpc.Status.fromThrowable(e);
        if(errStatus.getCode() == io.grpc.Status.Code.CANCELLED) {
          System.out.printf("Monitoring is cancelled\n");
        } else {
          System.out.printf("Monitoring error: %s\n", e);
        }
      } finally {
        monitoringCtx.detach(prevCtx);
      }
    }
  }  

  public static void main(String[] args) throws Exception {
    for(String opt: args) {
      if(opt.equals("-i")) {
        MasterClient client = new MasterClient();

        client.connectAdmin(MASTER_CA_FILE, ADMIN_CERT_FILE, ADMIN_KEY_FILE, MASTER_ADDR, MASTER_PORT);
        client.initTenant(TENANT_ID, GATEWAY_ID);
  
        client.close();     
        System.exit(0);   
      }
    }

    MasterClient client = new MasterClient();

    try {
      client.connectTenant(MASTER_CA_FILE, TENANT_CERT_FILE, TENANT_KEY_FILE, MASTER_ADDR, MASTER_PORT);
    } catch (Exception e) {
      System.out.printf("Cannot connect to the master gateway: %s", e); 
      System.exit(-1);
    }    

    try {
      ConnectMasterTest connTest = new ConnectMasterTest(client, GATEWAY_ID);

      connTest.startMonitoring();

      connTest.showMainMenu();

      connTest.stopMonitoring();

      client.close();
    } catch (Exception e) {
      System.out.printf("Cannot complete the test: %s", e); 
    }
  }
}

