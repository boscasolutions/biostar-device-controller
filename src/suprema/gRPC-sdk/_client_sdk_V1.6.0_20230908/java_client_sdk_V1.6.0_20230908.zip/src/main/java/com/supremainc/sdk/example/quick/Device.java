package com.supremainc.sdk.example.quick;

import com.supremainc.sdk.device.FactoryInfo;
import com.supremainc.sdk.device.CapabilityInfo;
import com.supremainc.sdk.example.device.DeviceSvc;

class DeviceTest {
  private DeviceSvc deviceSvc;

  public DeviceTest(DeviceSvc svc) {
    deviceSvc = svc;
  }

  public CapabilityInfo test(int deviceID) throws Exception {
    FactoryInfo factoryInfo = deviceSvc.getInfo(deviceID);

    System.out.printf("Device info: \n%s\n\n", factoryInfo);    
  
    CapabilityInfo capabilityInfo = deviceSvc.getCapabilityInfo(deviceID);
  
    System.out.printf("Capability info: \n%s\n\n", capabilityInfo); 

    return capabilityInfo;
  }
}
