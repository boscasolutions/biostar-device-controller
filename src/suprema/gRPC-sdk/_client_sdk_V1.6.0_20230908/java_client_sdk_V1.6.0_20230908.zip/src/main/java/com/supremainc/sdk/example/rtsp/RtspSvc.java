package com.supremainc.sdk.example.rtsp;

import java.util.List;

import com.supremainc.sdk.rtsp.RTSPConfig;
import com.supremainc.sdk.rtsp.RTSPGrpc;
import com.supremainc.sdk.rtsp.GetConfigRequest;
import com.supremainc.sdk.rtsp.GetConfigResponse;
import com.supremainc.sdk.rtsp.SetConfigRequest;
import com.supremainc.sdk.rtsp.SetConfigResponse;

public class RtspSvc {
  private final RTSPGrpc.RTSPBlockingStub rtspStub;

  public RtspSvc(RTSPGrpc.RTSPBlockingStub stub) {
    rtspStub = stub;
  }

  public RTSPConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = rtspStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, RTSPConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = rtspStub.setConfig(request);
  }
}