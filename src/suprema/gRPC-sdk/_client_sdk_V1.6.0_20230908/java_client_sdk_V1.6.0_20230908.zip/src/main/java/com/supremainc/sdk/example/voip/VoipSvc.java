package com.supremainc.sdk.example.voip;

import java.util.List;

import com.supremainc.sdk.voip.VOIPConfig;
import com.supremainc.sdk.voip.VOIPGrpc;
import com.supremainc.sdk.voip.GetConfigRequest;
import com.supremainc.sdk.voip.GetConfigResponse;
import com.supremainc.sdk.voip.SetConfigRequest;
import com.supremainc.sdk.voip.SetConfigResponse;

public class VoipSvc {
  private final VOIPGrpc.VOIPBlockingStub voipStub;

  public VoipSvc(VOIPGrpc.VOIPBlockingStub stub) {
    voipStub = stub;
  }

  public VOIPConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = voipStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, VOIPConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = voipStub.setConfig(request);
  }
}