package com.supremainc.sdk.example.event;

import com.supremainc.sdk.event.EventLog;

public interface EventCallback{
  void handle(EventLog event);
}