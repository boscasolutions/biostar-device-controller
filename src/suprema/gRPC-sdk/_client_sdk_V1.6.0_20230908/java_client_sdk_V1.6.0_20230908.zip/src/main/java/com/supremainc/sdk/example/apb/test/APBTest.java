package com.supremainc.sdk.example.apb.test;

import java.util.List;
import java.util.ArrayList;

import com.supremainc.sdk.apb_zone.ZoneInfo;
import com.supremainc.sdk.apb_zone.Type;
import com.supremainc.sdk.apb_zone.Member;
import com.supremainc.sdk.apb_zone.ReaderType;
import com.supremainc.sdk.rs485.SlaveDeviceInfo;
import com.supremainc.sdk.action.Action;
import com.supremainc.sdk.action.ActionType;
import com.supremainc.sdk.action.RelayAction;
import com.supremainc.sdk.action.Signal;
import com.supremainc.sdk.example.apb.APBZoneSvc;
import com.supremainc.sdk.example.rs485.RS485Svc;
import com.supremainc.sdk.example.cli.KeyInput;

class APBTest {
  private static final int TEST_ZONE_ID = 1;

  private APBZoneSvc zoneSvc;

  public APBTest(APBZoneSvc zoneSvc) {
    this.zoneSvc = zoneSvc;
  }

  public void test(int deviceID, List<SlaveDeviceInfo> slaves) throws Exception {
    List<ZoneInfo> origZones = zoneSvc.get(deviceID);

    System.out.printf("Original APB Zones: %s\n", origZones);
    zoneSvc.deleteAll(deviceID);

    ZoneInfo testZone = makeZone(deviceID, slaves);
    ArrayList<ZoneInfo> zones = new ArrayList<ZoneInfo>();
    zones.add(testZone);
    zoneSvc.add(deviceID, zones);

    System.out.printf("\n===== Anti Passback Zone Test =====\n\n");
    System.out.printf("Test Zone: %s\n\n", testZone);

    System.out.printf(">> Authenticate a regsistered credential on the entry device(%d) and/or the exit device(%d) to test if the APB zone works correctly.\n", deviceID, slaves.get(0).getDeviceID());
    KeyInput.pressEnter(">> Press ENTER for the next test.\n");

    KeyInput.pressEnter(">> Press ENTER after generating an APB violation.\n");

    zoneSvc.clearAll(deviceID, TEST_ZONE_ID);

    System.out.printf(">> The APB records are cleared. Try to authenticate the last credential which caused the APB violation. It should succeed since the APB records are cleared.\n");
    KeyInput.pressEnter(">> Press ENTER to finish the test.\n");

    zoneSvc.deleteAll(deviceID);

    if(origZones.size() > 0) {
      zoneSvc.add(deviceID, origZones);
    }
  }

  ZoneInfo makeZone(int deviceID, List<SlaveDeviceInfo> slaves) {
    // Make a zone with the master device and the 1st slave device
    ArrayList<Member> members = new ArrayList<Member>();
    members.add(Member.newBuilder().setDeviceID(deviceID).setReaderType(ReaderType.ENTRY).build());
    members.add(Member.newBuilder().setDeviceID(slaves.get(0).getDeviceID()).setReaderType(ReaderType.EXIT).build());

    Signal relaySignal = Signal.newBuilder().setCount(3).setOnDuration(500).setOffDuration(500).build(); 
    Action action = Action.newBuilder() // Activate the 1st relay of the master device when an alarm is detected
                      .setDeviceID(deviceID)
                      .setType(ActionType.ACTION_RELAY)
                      .setRelay(RelayAction.newBuilder().setRelayIndex(0).setSignal(relaySignal).build())
                      .build();

    ArrayList<Action> actions = new ArrayList<Action>();
    actions.add(action);

    ZoneInfo zone = ZoneInfo.newBuilder()
                                    .setZoneID(TEST_ZONE_ID)
                                    .setName("Test APB Zone")
                                    .setType(Type.HARD) // hard APB
                                    .setResetDuration(0) // indefinite
                                    .addAllMembers(members)
                                    .addAllActions(actions)
                                    .build();

    return zone;
  }
}
