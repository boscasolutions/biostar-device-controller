package com.supremainc.sdk.example.tna.test;

import java.util.List;
import java.util.ListIterator;
import java.time.Instant;

import com.supremainc.sdk.example.tna.TNASvc;
import com.supremainc.sdk.tna.TNALog;
import com.supremainc.sdk.tna.TNAConfig;
import com.supremainc.sdk.tna.Key;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.event.EventCallback;
import com.supremainc.sdk.event.EventLog;

class LogTest implements EventCallback {
  private TNASvc tnaSvc;
  private EventSvc eventSvc;
  private int firstEventID;

  public LogTest(TNASvc tnaSvc, EventSvc eventSvc) {
    this.tnaSvc = tnaSvc;
    this.eventSvc = eventSvc;
    firstEventID = 0;
  }

  public void handle(EventLog event) {
    if(firstEventID == 0) {
      firstEventID = event.getID();
    }

    System.out.printf("\nRealtime Event:\n%s\n", event);
  }

  public void test(int deviceID) throws Exception {
    System.out.printf("\n===== T&A Log Events =====\n\n");

    List<TNALog> events = tnaSvc.getTNALog(deviceID, firstEventID, 0);
    ListIterator<TNALog> eventIter = events.listIterator();

    TNAConfig config = tnaSvc.getConfig(deviceID);

    while(eventIter.hasNext()) {
      TNALog event = eventIter.next();
      printEvent(event, config);
    }
  }

  public void printEvent(TNALog event, TNAConfig config) {
    System.out.printf("%s: Device %d, User %s, %s, %s\n", Instant.ofEpochSecond(event.getTimestamp()), event.getDeviceID(), event.getUserID(), eventSvc.getEventString(event.getEventCode(), event.getSubCode()), getTNALabel(event.getTNAKey(), config));
  }

  public String getTNALabel(Key key, TNAConfig config) {
    if(config.getLabelsCount() > key.getNumber() - 1) {
      return String.format("%s(%s)", config.getLabels(key.getNumber() - 1), key);
    } else {
      return String.format("%s", key);
    }
  }
}

