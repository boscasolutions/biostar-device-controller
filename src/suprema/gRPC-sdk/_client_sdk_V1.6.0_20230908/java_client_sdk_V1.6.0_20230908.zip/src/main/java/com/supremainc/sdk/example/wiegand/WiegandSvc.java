package com.supremainc.sdk.example.wiegand;

import java.util.List;

import com.supremainc.sdk.wiegand.WiegandConfig;
import com.supremainc.sdk.wiegand.WiegandGrpc;
import com.supremainc.sdk.wiegand.GetConfigRequest;
import com.supremainc.sdk.wiegand.GetConfigResponse;
import com.supremainc.sdk.wiegand.SetConfigRequest;
import com.supremainc.sdk.wiegand.SetConfigResponse;

public class WiegandSvc {
  private final WiegandGrpc.WiegandBlockingStub wiegandStub;

  public WiegandSvc(WiegandGrpc.WiegandBlockingStub stub) {
    wiegandStub = stub;
  }

  public WiegandConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = wiegandStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, WiegandConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = wiegandStub.setConfig(request);
  }
}