package com.supremainc.sdk.example.auth;

import com.supremainc.sdk.auth.AuthConfig;
import com.supremainc.sdk.auth.AuthGrpc;
import com.supremainc.sdk.auth.GetConfigRequest;
import com.supremainc.sdk.auth.GetConfigResponse;
import com.supremainc.sdk.auth.SetConfigRequest;
import com.supremainc.sdk.auth.SetConfigResponse;

public class AuthSvc {
  private final AuthGrpc.AuthBlockingStub authStub;

  public AuthSvc(AuthGrpc.AuthBlockingStub stub) {
    authStub = stub;
  }

  public AuthConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = authStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, AuthConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = authStub.setConfig(request);
  }
}