package com.supremainc.sdk.example.status;

import java.util.List;

import com.supremainc.sdk.status.StatusConfig;
import com.supremainc.sdk.status.StatusGrpc;
import com.supremainc.sdk.status.GetConfigRequest;
import com.supremainc.sdk.status.GetConfigResponse;
import com.supremainc.sdk.status.SetConfigRequest;
import com.supremainc.sdk.status.SetConfigResponse;

public class StatusSvc {
  private final StatusGrpc.StatusBlockingStub statusStub;

  public StatusSvc(StatusGrpc.StatusBlockingStub stub) {
    statusStub = stub;
  }

  public StatusConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = statusStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, StatusConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = statusStub.setConfig(request);
  }
}