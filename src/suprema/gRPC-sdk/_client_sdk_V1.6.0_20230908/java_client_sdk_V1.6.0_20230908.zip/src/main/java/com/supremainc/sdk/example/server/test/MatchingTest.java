package com.supremainc.sdk.example.server.test;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import io.grpc.Status;
import io.grpc.Context;
import io.grpc.Context.CancellableContext;

import com.supremainc.sdk.server.ServerRequest;
import com.supremainc.sdk.server.RequestType;
import com.supremainc.sdk.server.ServerErrorCode;
import com.supremainc.sdk.auth.AuthConfig;
import com.supremainc.sdk.user.UserInfo;
import com.supremainc.sdk.user.UserHdr;
import com.supremainc.sdk.card.CSNCardData;
import com.supremainc.sdk.finger.FingerData;
import com.supremainc.sdk.example.server.ServerSvc;
import com.supremainc.sdk.example.auth.AuthSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class MatchingTest {
  private ServerSvc serverSvc;
  private AuthSvc authSvc;

  public MatchingTest(ServerSvc serverSvc, AuthSvc authSvc) {
    this.serverSvc = serverSvc;
    this.authSvc = authSvc;
  }

  public void test(int deviceID) throws Exception {
    // Backup the original configuration
    AuthConfig origConfig = authSvc.getConfig(deviceID);
    System.out.printf("Original Auth Config: %s\n\n", origConfig);

    // Enable server matching for the test
    AuthConfig testConfig = origConfig.toBuilder().setUseServerMatching(true).build();
    authSvc.setConfig(deviceID, testConfig);

    AuthConfig newConfig = authSvc.getConfig(deviceID);
    System.out.printf("Test Auth Config: %s\n\n", newConfig);

    testVerify();
    testIdentify();

    // Restore the original configuration
    authSvc.setConfig(deviceID, origConfig);
  }

  void testVerify() throws Exception {
    VerifyTest verifyTest = new VerifyTest(serverSvc);
    verifyTest.setReturnError(true);

    Thread matchingThread = new Thread(verifyTest);
    matchingThread.start();

    System.out.printf("\n===== Server Matching: Verify Test =====\n\n");
    System.out.printf(">> Try to authenticate a card. It should fail since the device gateway will return an error code to the request.\n");
    KeyInput.pressEnter(">> Press ENTER for the next test.\n");

    verifyTest.setReturnError(false);
    System.out.printf(">> Try to authenticate a card. The gateway will return SUCCESS with user information this time. The result will vary according to the authentication modes of the devices.\n");	
    KeyInput.pressEnter(">> Press ENTER for the next test.\n");	

    verifyTest.cancelSubscribe();

    matchingThread.join();
  }

  void testIdentify() throws Exception {
    IdentifyTest identifyTest = new IdentifyTest(serverSvc);
    identifyTest.setReturnError(true);

    Thread matchingThread = new Thread(identifyTest);
    matchingThread.start();

    System.out.printf("\n===== Server Matching: Identify Test =====\n\n");
    System.out.printf(">> Try to authenticate a fingerprint. It should fail since the device gateway will return an error code to the request.\n");
    KeyInput.pressEnter(">> Press ENTER for the next test.\n");

    identifyTest.setReturnError(false);
    System.out.printf(">> Try to authenticate a fingerprint. The gateway will return SUCCESS with user information this time. The result will vary according to the authentication modes of the devices.\n");	
    KeyInput.pressEnter(">> Press ENTER for the next test.\n");	

    identifyTest.cancelSubscribe();
    matchingThread.join();
  }
}

class VerifyTest implements Runnable {
  private static final int QUEUE_SIZE = 16;
  private static final String TEST_USER_ID = "1234";

  private final ServerSvc serverSvc;
  private boolean returnError;

  private CancellableContext subscriptionCtx;
  private Context restoreCtx;

  public VerifyTest(ServerSvc serverSvc) {
    this.serverSvc = serverSvc;

    subscriptionCtx = null;
    restoreCtx = null;    
  }

  public void setReturnError(boolean returnError) {
    this.returnError = returnError;
  }

  public void cancelSubscribe() {
    if(subscriptionCtx != null) {
      subscriptionCtx.cancel(null);
    }
  }

  public void run() {
    try {
      subscriptionCtx = Context.current().withCancellation();
      restoreCtx = subscriptionCtx.attach();

      Iterator<ServerRequest> requestStream = serverSvc.subscribe(QUEUE_SIZE);
      
      while(requestStream.hasNext()) {
        ServerRequest req = requestStream.next();

        if(req.getReqType() != RequestType.VERIFY_REQUEST) {
          System.out.printf("!! Request type is not VERIFY_REQUEST. Just ignore it.\n");
          continue;          
        }

        if(returnError) {
          System.out.printf("## Gateway returns VERIFY_FAIL.\n");
          serverSvc.handleVerify(req, ServerErrorCode.VERIFY_FAIL, null);
        } else {
          System.out.printf("## Gateway returns SUCCESS with user information.\n");
          
          ArrayList<CSNCardData> cards = new ArrayList<CSNCardData>();
          cards.add(CSNCardData.newBuilder().setData(req.getVerifyReq().getCardData()).build());

          UserInfo userInfo = UserInfo.newBuilder()
                                .setHdr(UserHdr.newBuilder().setID(TEST_USER_ID).setNumOfCard(1).build())
                                .addAllCards(cards)
                                .build();

          serverSvc.handleVerify(req, ServerErrorCode.SUCCESS, userInfo);
        }
      }
    } catch(Exception e) {
      Status errStatus = Status.fromThrowable(e);
      if(errStatus.getCode() == Status.Code.CANCELLED) {
        System.out.printf("Subscription is cancelled\n");
      } else {
        System.out.printf("Subscription error: %s\n", e);
        e.printStackTrace(System.out);
      }
    } finally {
      try {
        if(subscriptionCtx != null && restoreCtx != null) {
          subscriptionCtx.detach(restoreCtx);
        }

        serverSvc.unsubscribe();        
      } catch(Exception e) {
      }
    }
  }
}


class IdentifyTest implements Runnable {
  private static final int QUEUE_SIZE = 16;
  private static final String TEST_USER_ID = "1234";

  private final ServerSvc serverSvc;
  private boolean returnError;

  private CancellableContext subscriptionCtx;
  private Context restoreCtx;  

  public IdentifyTest(ServerSvc serverSvc) {
    this.serverSvc = serverSvc;

    subscriptionCtx = null;
    restoreCtx = null;       
  }

  public void setReturnError(boolean returnError) {
    this.returnError = returnError;
  }

  public void cancelSubscribe() {
    if(subscriptionCtx != null) {
      subscriptionCtx.cancel(null);
    }
  }  

  public void run() {
    try {
      subscriptionCtx = Context.current().withCancellation();
      restoreCtx = subscriptionCtx.attach();

      Iterator<ServerRequest> requestStream = serverSvc.subscribe(QUEUE_SIZE);
      
      while(requestStream.hasNext()) {
        ServerRequest req = requestStream.next();

        if(req.getReqType() != RequestType.IDENTIFY_REQUEST) {
          System.out.printf("!! Request type is not IDENTIFY_REQUEST. Just ignore it.\n");
          continue;          
        }

        if(returnError) {
          System.out.printf("## Gateway returns IDENTIFY_FAIL.\n");
          serverSvc.handleIdentify(req, ServerErrorCode.IDENTIFY_FAIL, null);
        } else {
          System.out.printf("## Gateway returns SUCCESS with user information.\n");
          
          ArrayList<FingerData> fingers = new ArrayList<FingerData>();
          fingers.add(FingerData.newBuilder().addTemplates(req.getIdentifyReq().getTemplateData()).addTemplates(req.getIdentifyReq().getTemplateData()).build());

          UserInfo userInfo = UserInfo.newBuilder()
                                .setHdr(UserHdr.newBuilder().setID(TEST_USER_ID).setNumOfFinger(1).build())
                                .addAllFingers(fingers)
                                .build();

          serverSvc.handleIdentify(req, ServerErrorCode.SUCCESS, userInfo);
        }
      }
    } catch(Exception e) {
      Status errStatus = Status.fromThrowable(e);
      if(errStatus.getCode() == Status.Code.CANCELLED) {
        System.out.printf("Subscription is cancelled\n");
      } else {
        System.out.printf("Subscription error: %s\n", e);
        e.printStackTrace(System.out);
      }
    } finally {
      try {
        if(subscriptionCtx != null && restoreCtx != null) {
          subscriptionCtx.detach(restoreCtx);
        }

        serverSvc.unsubscribe();        
      } catch(Exception e) {
      }
    }
  }
}


