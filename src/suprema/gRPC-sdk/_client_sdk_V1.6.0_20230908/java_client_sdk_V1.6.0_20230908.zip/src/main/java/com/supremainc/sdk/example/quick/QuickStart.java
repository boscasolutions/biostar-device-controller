package com.supremainc.sdk.example.quick;

import java.util.List;

import io.grpc.CallCredentials;

import com.supremainc.sdk.card.CardGrpc;
import com.supremainc.sdk.connect.ConnectGrpc;
import com.supremainc.sdk.connect_master.ConnectMasterGrpc;
import com.supremainc.sdk.device.DeviceGrpc;
import com.supremainc.sdk.device.CapabilityInfo;
import com.supremainc.sdk.display.DisplayGrpc;
import com.supremainc.sdk.event.EventGrpc;
import com.supremainc.sdk.example.card.CardSvc;
import com.supremainc.sdk.example.client.GrpcClient;
import com.supremainc.sdk.example.client.GatewayClient;
import com.supremainc.sdk.example.master.MasterClient;
import com.supremainc.sdk.example.connect.ConnectSvc;
import com.supremainc.sdk.example.connect_master.ConnectMasterSvc;
import com.supremainc.sdk.example.device.DeviceSvc;
import com.supremainc.sdk.example.display.DisplaySvc;
import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.finger.FingerSvc;
import com.supremainc.sdk.example.face.FaceSvc;
import com.supremainc.sdk.example.user.UserSvc;
import com.supremainc.sdk.finger.FingerGrpc;
import com.supremainc.sdk.face.FaceGrpc;
import com.supremainc.sdk.user.UserGrpc;

public class QuickStart {
  private static final String GATEWAY_CA_FILE = "../cert/gateway/192.168.28.111/ca.crt";
  private static final String GATEWAY_ADDR = "192.168.28.111";
  private static final int GATEWAY_PORT = 4000;

  private static final String MASTER_CA_FILE = "../cert/master/master_ca.crt";
  private static final String MASTER_ADDR = "192.168.28.21";
  private static final int MASTER_PORT = 4010;
  private static final String TENANT_CERT_FILE = "../cert/master/tenant_tenant1.crt";
  private static final String TENANT_KEY_FILE = "../cert/master/tenant_tenant1_key.pem";
  private static final String ADMIN_CERT_FILE = "../cert/master/admin.crt";
  private static final String ADMIN_KEY_FILE = "../cert/master/admin_key.pem";

  private static final String TENANT_ID = "tenant1";
  private static final String GATEWAY_ID = "gateway1";

  private static final String DEVICE_ADDR = "192.168.28.172";
  private static final int DEVICE_PORT = 51211;
  private static final boolean DEVICE_USE_SSL = false;

  private GrpcClient grpcClient;
  private ConnectSvc connectSvc;
  private ConnectMasterSvc connectMasterSvc;
  private DeviceSvc deviceSvc;
  private DisplaySvc displaySvc;
  private UserSvc userSvc;
  private FingerSvc fingerSvc;
  private FaceSvc faceSvc;
  private CardSvc cardSvc;
  private EventSvc eventSvc;

  public QuickStart(GrpcClient client) {
    grpcClient = client;

    connectSvc = new ConnectSvc(ConnectGrpc.newBlockingStub(client.getChannel())); 
    connectMasterSvc = null;
    deviceSvc = new DeviceSvc(DeviceGrpc.newBlockingStub(client.getChannel()));   
    displaySvc = new DisplaySvc(DisplayGrpc.newBlockingStub(client.getChannel()));   
    userSvc = new UserSvc(UserGrpc.newBlockingStub(client.getChannel()));  
    fingerSvc = new FingerSvc(FingerGrpc.newBlockingStub(client.getChannel()));  
    faceSvc = new FaceSvc(FaceGrpc.newBlockingStub(client.getChannel()));  
    cardSvc = new CardSvc(CardGrpc.newBlockingStub(client.getChannel()));
    eventSvc = new EventSvc(EventGrpc.newBlockingStub(client.getChannel()));
  }

  public QuickStart(GrpcClient client, CallCredentials credentials) {
    grpcClient = client;

    connectSvc = null;
    connectMasterSvc = new ConnectMasterSvc(ConnectMasterGrpc.newBlockingStub(client.getChannel()).withCallCredentials(credentials)); 
    deviceSvc = new DeviceSvc(DeviceGrpc.newBlockingStub(client.getChannel()).withCallCredentials(credentials));   
    displaySvc = new DisplaySvc(DisplayGrpc.newBlockingStub(client.getChannel()).withCallCredentials(credentials));   
    userSvc = new UserSvc(UserGrpc.newBlockingStub(client.getChannel()).withCallCredentials(credentials));  
    fingerSvc = new FingerSvc(FingerGrpc.newBlockingStub(client.getChannel()).withCallCredentials(credentials));  
    faceSvc = new FaceSvc(FaceGrpc.newBlockingStub(client.getChannel()).withCallCredentials(credentials));  
    cardSvc = new CardSvc(CardGrpc.newBlockingStub(client.getChannel()).withCallCredentials(credentials));
    eventSvc = new EventSvc(EventGrpc.newBlockingStub(client.getChannel()).withCallCredentials(credentials));
  }  
  
  // To enable gRPC debugging
  // $ env JAVA_OPTS=-Djava.util.logging.config.file=logging.properties ./build/install/java/bin/quickStart
  
  public static void main(String[] args) throws Exception {
    boolean masterMode = false;
    
    for(String opt: args) {
      if (opt.equals("-mi")) {
        MasterClient masterClient = new MasterClient();

        masterClient.connectAdmin(MASTER_CA_FILE, ADMIN_CERT_FILE, ADMIN_KEY_FILE, MASTER_ADDR, MASTER_PORT);
        masterClient.initTenant(TENANT_ID, GATEWAY_ID);
  
        masterClient.close();     
        System.exit(0);   
      }

      if(opt.equals("-m")) {
        masterMode = true;
        break;
      }
    }
    
    QuickStart quickStart = null;
    int deviceID = 0;

    if (masterMode) { // connect to the master gateway
      try {
        MasterClient masterClient = new MasterClient();

        masterClient.connectTenant(MASTER_CA_FILE, TENANT_CERT_FILE, TENANT_KEY_FILE, MASTER_ADDR, MASTER_PORT);
        quickStart = new QuickStart(masterClient, masterClient.getCredentials());

        deviceID = new ConnectTest(null, quickStart.connectMasterSvc).testMaster(GATEWAY_ID, DEVICE_ADDR, DEVICE_PORT, DEVICE_USE_SSL);       
      } catch (Exception e) {
        System.out.printf("Cannot connect to the master gateway: %s", e); 
        System.exit(-1);
      } 
    } else { // connect to the device gateway
      try {
        GatewayClient gatewayClient = new GatewayClient();
  
        gatewayClient.connect(GATEWAY_CA_FILE, GATEWAY_ADDR, GATEWAY_PORT);
        quickStart = new QuickStart(gatewayClient);
  
        deviceID = new ConnectTest(quickStart.connectSvc, null).test(DEVICE_ADDR, DEVICE_PORT, DEVICE_USE_SSL);
      } catch (Exception e) {
        System.out.printf("Cannot connect to the device gateway: %s", e); 
        System.exit(-1);
      }
    }

    try {
      CapabilityInfo capabilityInfo = new DeviceTest(quickStart.deviceSvc).test(deviceID);

      if (capabilityInfo.getFaceSupported()) {
        new FaceTest(quickStart.faceSvc).test(deviceID);
      }

      if (capabilityInfo.getFingerSupported()) {
        new FingerTest(quickStart.fingerSvc).test(deviceID);
      }

      if (capabilityInfo.getCardSupported()) {
        new CardTest(quickStart.cardSvc).test(deviceID, capabilityInfo);
      }

      new UserTest(quickStart.userSvc, quickStart.fingerSvc, quickStart.faceSvc).test(deviceID, capabilityInfo);
      new EventTest(quickStart.eventSvc).test(deviceID);
    } catch (Exception e) {
      System.out.printf("Cannot complete the test: %s", e); 
    } finally {
      if (masterMode) {
        quickStart.connectMasterSvc.disconnect(deviceID);      
      } else {
        quickStart.connectSvc.disconnect(deviceID);      
      }

      quickStart.grpcClient.close();
    }
  }
}

