package com.supremainc.sdk.example.user.test;

import java.util.List;
import java.util.ArrayList;

import com.supremainc.sdk.card.CardData;
import com.supremainc.sdk.example.card.CardSvc;
import com.supremainc.sdk.user.UserCard;
import com.supremainc.sdk.example.user.UserSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class CardTest {
  private CardSvc cardSvc;
  private UserSvc userSvc;

  public CardTest(CardSvc cardSvc, UserSvc userSvc) {
    this.cardSvc = cardSvc;
    this.userSvc = userSvc;
  }

  public void test(int deviceID, String userID) throws Exception {
    System.out.printf("\n===== Card Test =====\n\n");

    System.out.printf(">> Place a unregistered card on the device...\n");

    CardData cardData = cardSvc.scan(deviceID);

    if(cardData.getCSNCardData() == null) {
      System.out.printf("!! The card is a smart card. For this test, you have to use a CSN card. Skip the card test.\n");
      return;
    }

    List<UserCard> userCards = new ArrayList<UserCard>();
    userCards.add(UserCard.newBuilder().setUserID(userID).addCards(cardData.getCSNCardData()).build());

    userSvc.setCard(deviceID, userCards);

    KeyInput.pressEnter(">> Try to authenticate the enrolled card. And, press ENTER to end the test.\n");
  }
}

