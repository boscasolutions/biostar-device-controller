package com.supremainc.sdk.example.access;

import java.util.List;

import com.supremainc.sdk.access.GetListRequest;
import com.supremainc.sdk.access.GetListResponse;
import com.supremainc.sdk.access.AddRequest;
import com.supremainc.sdk.access.DeleteAllRequest;
import com.supremainc.sdk.access.GetLevelListRequest;
import com.supremainc.sdk.access.GetLevelListResponse;
import com.supremainc.sdk.access.AddLevelRequest;
import com.supremainc.sdk.access.DeleteAllLevelRequest;
import com.supremainc.sdk.access.AccessGrpc;
import com.supremainc.sdk.access.AccessGroup;
import com.supremainc.sdk.access.AccessLevel;

public class AccessSvc {
  private final AccessGrpc.AccessBlockingStub accessStub;

  public AccessSvc(AccessGrpc.AccessBlockingStub stub) {
    accessStub = stub;
  }

  public List<AccessGroup> getList(int deviceID) throws Exception {
    GetListRequest request = GetListRequest.newBuilder().setDeviceID(deviceID).build();
    GetListResponse response = accessStub.getList(request);

    return response.getGroupsList();
  } 

  public void add(int deviceID, List<AccessGroup> groups) throws Exception {
    AddRequest request = AddRequest.newBuilder().setDeviceID(deviceID).addAllGroups(groups).build();
    accessStub.add(request);
  }

  public void deleteAll(int deviceID) throws Exception {
    DeleteAllRequest request = DeleteAllRequest.newBuilder().setDeviceID(deviceID).build();
    accessStub.deleteAll(request);
  }

  public List<AccessLevel> getLevelList(int deviceID) throws Exception {
    GetLevelListRequest request = GetLevelListRequest.newBuilder().setDeviceID(deviceID).build();
    GetLevelListResponse response = accessStub.getLevelList(request);

    return response.getLevelsList();
  } 

  public void addLevel(int deviceID, List<AccessLevel> levels) throws Exception {
    AddLevelRequest request = AddLevelRequest.newBuilder().setDeviceID(deviceID).addAllLevels(levels).build();
    accessStub.addLevel(request);
  }

  public void deleteAllLevel(int deviceID) throws Exception {
    DeleteAllLevelRequest request = DeleteAllLevelRequest.newBuilder().setDeviceID(deviceID).build();
    accessStub.deleteAllLevel(request);
  }
}