package com.supremainc.sdk.example.door.test;

import java.util.List;
import java.time.Instant;

import com.supremainc.sdk.example.event.EventSvc;
import com.supremainc.sdk.example.event.EventCallback;
import com.supremainc.sdk.event.EventLog;

class LogTest implements EventCallback {
  private EventSvc eventSvc;
  private int firstEventID;

  private static final int FIRST_DOOR_EVENT = 0x5000; // BS2_EVENT_DOOR_UNLOCKED
  private static final int LAST_DOOR_EVENT = 0x5E00; // BS2_EVENT_DOOR_UNLOCK

  private static final int MAX_NUM_OF_LOG = 16; //

  public LogTest(EventSvc svc) {
    eventSvc = svc;
    firstEventID = 0;
  }

  public void handle(EventLog eventLog) {
    if(firstEventID == 0) {
      firstEventID = eventLog.getID();
    }

    if(eventLog.getEventCode() >= FIRST_DOOR_EVENT && eventLog.getEventCode() <= LAST_DOOR_EVENT) {
      System.out.printf("%s: Door %d, %s\n", Instant.ofEpochSecond(eventLog.getTimestamp()), eventLog.getEntityID(), eventSvc.getEventString(eventLog.getEventCode(), eventLog.getSubCode()));
    } else {
      System.out.printf("%s: Device %d, User %s, %s\n", Instant.ofEpochSecond(eventLog.getTimestamp()), eventLog.getDeviceID(), eventLog.getUserID(), eventSvc.getEventString(eventLog.getEventCode(), eventLog.getSubCode()));
    }
  }

  public String getUserID(int deviceID) throws Exception {
    List<EventLog> events = eventSvc.getLog(deviceID, firstEventID, MAX_NUM_OF_LOG);

    String userID = null;

    for(int i = 0; i < events.size(); i++) {
      if(events.get(i).getEventCode() == 0x1900) { // BS2_EVENT_ACCESS_DENIED
        userID = events.get(i).getUserID();
        break;
      }
    }

    return userID;
  }
}

