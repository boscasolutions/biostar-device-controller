package com.supremainc.sdk.example.connect_master;

import java.util.List;
import java.util.Iterator;

import com.supremainc.sdk.connect_master.ConnectMasterGrpc;
import com.supremainc.sdk.connect.DeviceInfo;
import com.supremainc.sdk.connect_master.GetDeviceListRequest;
import com.supremainc.sdk.connect_master.GetDeviceListResponse;
import com.supremainc.sdk.connect.SearchDeviceInfo;
import com.supremainc.sdk.connect_master.SearchDeviceRequest;
import com.supremainc.sdk.connect_master.SearchDeviceResponse;
import com.supremainc.sdk.connect.ConnectInfo;
import com.supremainc.sdk.connect_master.ConnectRequest;
import com.supremainc.sdk.connect_master.ConnectResponse;
import com.supremainc.sdk.connect_master.DisconnectRequest;
import com.supremainc.sdk.connect_master.DisconnectAllRequest;
import com.supremainc.sdk.connect.StatusChange;
import com.supremainc.sdk.connect_master.SubscribeStatusRequest;
import com.supremainc.sdk.connect.AsyncConnectInfo;
import com.supremainc.sdk.connect_master.AddAsyncConnectionRequest;
import com.supremainc.sdk.connect_master.DeleteAsyncConnectionRequest;
import com.supremainc.sdk.connect.AcceptFilter;
import com.supremainc.sdk.connect_master.GetAcceptFilterRequest;
import com.supremainc.sdk.connect_master.GetAcceptFilterResponse;
import com.supremainc.sdk.connect_master.SetAcceptFilterRequest;
import com.supremainc.sdk.connect.PendingDeviceInfo;
import com.supremainc.sdk.connect_master.GetPendingListRequest;
import com.supremainc.sdk.connect_master.GetPendingListResponse;
import com.supremainc.sdk.connect_master.EnableSSLMultiRequest;
import com.supremainc.sdk.connect_master.DisableSSLMultiRequest;
import com.supremainc.sdk.connect_master.SetConnectionModeMultiRequest;
import com.supremainc.sdk.connect_master.SetConnectionModeRequest;
import com.supremainc.sdk.connect.ConnectionMode;

public class ConnectMasterSvc {
  private final ConnectMasterGrpc.ConnectMasterBlockingStub connectMasterStub;
  private final int SEARCH_TIMEOUT_MS = 5000;

  private final int MONITORING_QUEUE_SIZE = 16;

  public ConnectMasterSvc(ConnectMasterGrpc.ConnectMasterBlockingStub stub) {
    connectMasterStub = stub;
  }

  public List<DeviceInfo> getDeviceList(String gatewayID) throws Exception {
    GetDeviceListRequest request = GetDeviceListRequest.newBuilder().setGatewayID(gatewayID).build();
    GetDeviceListResponse response;
    
    response = connectMasterStub.getDeviceList(request);
    return response.getDeviceInfosList();
  } 

  public List<SearchDeviceInfo> searchDevice(String gatewayID) throws Exception {
    SearchDeviceRequest request = SearchDeviceRequest.newBuilder().setGatewayID(gatewayID).setTimeout(SEARCH_TIMEOUT_MS).build();
    SearchDeviceResponse response;
    
    response = connectMasterStub.searchDevice(request);
    return response.getDeviceInfosList();
  }   

  public int connect(String gatewayID, ConnectInfo connInfo) throws Exception {
    ConnectRequest request = ConnectRequest.newBuilder().setGatewayID(gatewayID).setConnectInfo(connInfo).build();

    ConnectResponse response = connectMasterStub.connect(request);

    return response.getDeviceID();
  }

  public void disconnect(int deviceID) throws Exception {
    DisconnectRequest request = DisconnectRequest.newBuilder().addDeviceIDs(deviceID).build();
    connectMasterStub.disconnect(request);
  }

  public void disconnectMulti(List<Integer> deviceIDs) throws Exception {
    DisconnectRequest request = DisconnectRequest.newBuilder().addAllDeviceIDs(deviceIDs).build();
    connectMasterStub.disconnect(request);
  }  

  public void disconnectAll(String gatewayID) throws Exception {
    DisconnectAllRequest request = DisconnectAllRequest.newBuilder().setGatewayID(gatewayID).build();
    connectMasterStub.disconnectAll(request);
  }

  public void addAsyncConnection(String gatewayID, List<AsyncConnectInfo> connectInfos) throws Exception {
    AddAsyncConnectionRequest request = AddAsyncConnectionRequest.newBuilder().setGatewayID(gatewayID).addAllConnectInfos(connectInfos).build();
    connectMasterStub.addAsyncConnection(request);
  } 

  public void deleteAsyncConnection(String gatewayID, List<Integer> deviceIDs) throws Exception {
    DeleteAsyncConnectionRequest request = DeleteAsyncConnectionRequest.newBuilder().setGatewayID(gatewayID).addAllDeviceIDs(deviceIDs).build();
    connectMasterStub.deleteAsyncConnection(request);
  } 

  public AcceptFilter getAcceptFilter(String gatewayID) throws Exception {
    GetAcceptFilterRequest request = GetAcceptFilterRequest.newBuilder().setGatewayID(gatewayID).build();
    GetAcceptFilterResponse response = connectMasterStub.getAcceptFilter(request);

    return response.getFilter();
  }

  public void setAcceptFilter(String gatewayID, AcceptFilter filter) throws Exception {
    SetAcceptFilterRequest request = SetAcceptFilterRequest.newBuilder().setGatewayID(gatewayID).setFilter(filter).build();
    connectMasterStub.setAcceptFilter(request);
  }

  public List<PendingDeviceInfo> getPendingList(String gatewayID) throws Exception {
    GetPendingListRequest request = GetPendingListRequest.newBuilder().setGatewayID(gatewayID).build();
    GetPendingListResponse response = connectMasterStub.getPendingList(request);
    return response.getDeviceInfosList();
  } 

  public void enableSSL(List<Integer> deviceIDs) throws Exception {
    EnableSSLMultiRequest request = EnableSSLMultiRequest.newBuilder().addAllDeviceIDs(deviceIDs).build();
    connectMasterStub.enableSSLMulti(request);
  }

  public void disableSSL(List<Integer> deviceIDs) throws Exception {
    DisableSSLMultiRequest request = DisableSSLMultiRequest.newBuilder().addAllDeviceIDs(deviceIDs).build();
    connectMasterStub.disableSSLMulti(request);
  }

  public void setConnectionMode(List<Integer> deviceIDs, ConnectionMode mode) throws Exception {
    SetConnectionModeMultiRequest request = SetConnectionModeMultiRequest.newBuilder().addAllDeviceIDs(deviceIDs).setConnectionMode(mode).build();
    connectMasterStub.setConnectionModeMulti(request);
  }


  public Iterator<StatusChange> subscribe() throws Exception {
    SubscribeStatusRequest request = SubscribeStatusRequest.newBuilder().setQueueSize(MONITORING_QUEUE_SIZE).build();
    Iterator<StatusChange> statusStream = connectMasterStub.subscribeStatus(request);

    return statusStream;
  }
}
