package com.supremainc.sdk.example.voip.test;

import com.supremainc.sdk.voip.VOIPConfig;
import com.supremainc.sdk.example.voip.VoipSvc;
import com.supremainc.sdk.example.cli.KeyInput;

class ConfigTest {
  private VoipSvc voipSvc;

  public ConfigTest(VoipSvc svc) {
    voipSvc = svc;
  }

  public void test(int deviceID, VOIPConfig config) throws Exception {
    System.out.printf("\n===== Test for VOIPConfig =====\n\n");

    // Backup the original configuration
    VOIPConfig origConfig = config.toBuilder().build();

    VOIPConfig newConfig = config.toBuilder().setServerURL("voip.server.com").setServerPort(554).setUserID("VOIP User ID").setUserPW("2378129307").build();

    voipSvc.setConfig(deviceID, newConfig.toBuilder().setEnabled(true).build());

    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");   
    
    // Restore the original configuration   
    voipSvc.setConfig(deviceID, origConfig);
  }
}

