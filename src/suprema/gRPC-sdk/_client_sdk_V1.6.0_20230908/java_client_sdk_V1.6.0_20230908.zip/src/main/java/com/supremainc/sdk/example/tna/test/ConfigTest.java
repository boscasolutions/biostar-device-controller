package com.supremainc.sdk.example.tna.test;

import java.util.Arrays;

import com.supremainc.sdk.tna.TNAConfig;
import com.supremainc.sdk.tna.Mode;
import com.supremainc.sdk.tna.Key;
import com.supremainc.sdk.example.tna.TNASvc;
import com.supremainc.sdk.example.cli.KeyInput;

class ConfigTest {
  private TNASvc tnaSvc;

  public ConfigTest(TNASvc svc) {
    tnaSvc = svc;
  }

  public TNAConfig test(int deviceID) throws Exception {
    // Backup the original configuration
    TNAConfig origConfig = tnaSvc.getConfig(deviceID);
    System.out.printf("Original Config: %s\n\n", origConfig);

    System.out.printf("\n===== Test for TNAConfig =====\n\n");

    // (1) BY_USER
    String[] labels = {"In", "Out", "Scheduled In", "Fixed Out"};
    TNAConfig newConfig = TNAConfig.newBuilder().setMode(Mode.BY_USER).addAllLabels(Arrays.asList(labels)).build();
    tnaSvc.setConfig(deviceID, newConfig);

    System.out.printf("(1) The T&A mode is set to BY_USER(optional). You can select a T&A key before authentication. Try to authenticate after selecting a T&A key.\n\n");
    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");
    
    // (2) IsRequired
    tnaSvc.setConfig(deviceID, newConfig.toBuilder().setIsRequired(true).build());
    
    System.out.printf("(2) The T&A mode is set to BY_USER(mandatory). Try to authenticate without selecting a T&A key.\n\n");
    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");

    // (3) LAST_CHOICE
    tnaSvc.setConfig(deviceID, newConfig.toBuilder().setMode(Mode.LAST_CHOICE).build());
    
    System.out.printf("(3) The T&A mode is set to LAST_CHOICE. The T&A key selected by the previous user will be used. Try to authenticate multiple users.\n\n");
    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");

    // (4) BY_SCHEDULE
    Integer[] scheduleIDs = { 0, 0, 1 }; // Always for KEY_3(Scheduled_In)
    tnaSvc.setConfig(deviceID, newConfig.toBuilder().setMode(Mode.BY_SCHEDULE).addAllSchedules(Arrays.asList(scheduleIDs)).build());

    System.out.printf("(4) The T&A mode is set to BY_SCHEDULE. The T&A key will be determined automatically by schedule. Try to authenticate without selecting a T&A key.\n\n");
    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");

    // (5) FIXED
    tnaSvc.setConfig(deviceID, newConfig.toBuilder().setMode(Mode.FIXED).setKey(Key.KEY_4).build());

    System.out.printf("(5) The T&A mode is set to FIXED(KEY_4). Try to authenticate without selecting a T&A key.\n\n");
    KeyInput.pressEnter(">> Press ENTER if you finish testing this mode.\n");    

    return origConfig;
  }
}

