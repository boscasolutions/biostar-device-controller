package com.supremainc.sdk.example.client;

import io.grpc.netty.NettyChannelBuilder;
import io.grpc.netty.GrpcSslContexts;

import java.io.File;

public class GatewayClient extends GrpcClient {
  public void connect(String certFile, String gatewayAddr, int gatewayPort) throws Exception {
    channel = NettyChannelBuilder.forAddress(gatewayAddr, gatewayPort)
    .sslContext(GrpcSslContexts.forClient().trustManager(new File(certFile)).build())
    .build();
  }
}

