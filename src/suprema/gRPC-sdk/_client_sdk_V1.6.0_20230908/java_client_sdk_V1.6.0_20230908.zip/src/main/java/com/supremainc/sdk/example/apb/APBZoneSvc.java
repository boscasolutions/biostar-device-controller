package com.supremainc.sdk.example.apb;

import java.util.List;

import com.supremainc.sdk.apb_zone.GetRequest;
import com.supremainc.sdk.apb_zone.GetResponse;
import com.supremainc.sdk.apb_zone.GetStatusRequest;
import com.supremainc.sdk.apb_zone.GetStatusResponse;
import com.supremainc.sdk.apb_zone.AddRequest;
import com.supremainc.sdk.apb_zone.DeleteAllRequest;
import com.supremainc.sdk.apb_zone.ClearAllRequest;
import com.supremainc.sdk.apb_zone.APBZoneGrpc;
import com.supremainc.sdk.apb_zone.ZoneInfo;
import com.supremainc.sdk.zone.ZoneStatus;

public class APBZoneSvc {
  private final APBZoneGrpc.APBZoneBlockingStub apbZoneStub;

  public APBZoneSvc(APBZoneGrpc.APBZoneBlockingStub stub) {
    apbZoneStub = stub;
  }

  public List<ZoneInfo> get(int deviceID) throws Exception {
    GetRequest request = GetRequest.newBuilder().setDeviceID(deviceID).build();
    GetResponse response = apbZoneStub.get(request);

    return response.getZonesList();
  } 

  public List<ZoneStatus> getStatus(int deviceID) throws Exception {
    GetStatusRequest request = GetStatusRequest.newBuilder().setDeviceID(deviceID).build();
    GetStatusResponse response = apbZoneStub.getStatus(request);

    return response.getStatusList();
  }  

  public void add(int deviceID, List<ZoneInfo> zones) throws Exception {
    AddRequest request = AddRequest.newBuilder().setDeviceID(deviceID).addAllZones(zones).build();
    apbZoneStub.add(request);
  }

  public void deleteAll(int deviceID) throws Exception {
    DeleteAllRequest request = DeleteAllRequest.newBuilder().setDeviceID(deviceID).build();
    apbZoneStub.deleteAll(request);
  }

  public void clearAll(int deviceID, int zoneID) throws Exception {
    ClearAllRequest request = ClearAllRequest.newBuilder().setDeviceID(deviceID).setZoneID(zoneID).build();
    apbZoneStub.clearAll(request);
  }
}