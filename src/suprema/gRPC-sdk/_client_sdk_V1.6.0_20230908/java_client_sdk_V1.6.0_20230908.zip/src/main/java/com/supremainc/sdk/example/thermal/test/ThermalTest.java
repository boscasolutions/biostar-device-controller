package com.supremainc.sdk.example.thermal.test;

import com.supremainc.sdk.example.client.GatewayClient;
import com.supremainc.sdk.thermal.ThermalGrpc;
import com.supremainc.sdk.thermal.ThermalConfig;
import com.supremainc.sdk.example.thermal.ThermalSvc;
import com.supremainc.sdk.connect.ConnectGrpc;
import com.supremainc.sdk.connect.ConnectInfo;
import com.supremainc.sdk.example.connect.ConnectSvc;
import com.supremainc.sdk.event.EventGrpc;
import com.supremainc.sdk.example.event.EventSvc;

public class ThermalTest {
  private static final String CA_FILE = "../cert/gateway/ca.crt";

  private static final String GATEWAY_ADDR = "192.168.8.98";
  private static final int GATEWAY_PORT = 4000;

  private static final String DEVICE_ADDR = "192.168.8.205";
  private static final int DEVICE_PORT = 51211;
  private static final boolean DEVICE_USE_SSL = false;  

  private static final String CODE_MAP_FILE = "./event_code.json";

  private GatewayClient gatewayClient;
  private ThermalSvc thermalSvc;
  private ConnectSvc connectSvc;
  private EventSvc eventSvc;

  public ThermalTest(GatewayClient client) {
    gatewayClient = client;

    connectSvc = new ConnectSvc(ConnectGrpc.newBlockingStub(client.getChannel())); 
    thermalSvc = new ThermalSvc(ThermalGrpc.newBlockingStub(client.getChannel())); 
    eventSvc = new EventSvc(EventGrpc.newBlockingStub(client.getChannel())); 
  }

  public static void main(String[] args) throws Exception {
    GatewayClient client = new GatewayClient();

    try {
      client.connect(CA_FILE, GATEWAY_ADDR, GATEWAY_PORT);
    } catch (Exception e) {
      System.out.printf("Cannot connect to the gateway: %s", e); 
      System.exit(-1);
    }

    ThermalTest thermalTest = new ThermalTest(client);

    int deviceID = 0;

    try {
      ConnectInfo connInfo = ConnectInfo.newBuilder().setIPAddr(DEVICE_ADDR).setPort(DEVICE_PORT).setUseSSL(DEVICE_USE_SSL).build();

      deviceID = thermalTest.connectSvc.connect(connInfo);      
    } catch (Exception e) {
      System.out.printf("Cannot connect to the device: %s", e); 
      client.close();
      System.exit(-1);
    }

    ThermalConfig config = null;

    try {
      config = thermalTest.thermalSvc.getConfig(deviceID);

      System.out.printf("Thermal Config: \n%s\n\n", config); 
    } catch (Exception e) {
      System.out.printf("Thermal service is not supported by the device %d: %s", deviceID, e); 
      thermalTest.connectSvc.disconnect(deviceID);
      client.close();
      System.exit(-1);
    }

    try {
      LogTest logTest = new LogTest(thermalTest.thermalSvc, thermalTest.eventSvc);
      ConfigTest configTest = new ConfigTest(thermalTest.thermalSvc);

      thermalTest.eventSvc.initCodeMap(CODE_MAP_FILE);
      thermalTest.eventSvc.startMonitoring(deviceID);
      thermalTest.eventSvc.setEventCallback(logTest);

      configTest.test(deviceID, config);
      logTest.test(deviceID);

      thermalTest.eventSvc.stopMonitoring(deviceID);
    } catch (Exception e) {
      System.out.printf("Cannot complete the thermal test for device %d: %s", deviceID, e); 
    } finally {
      thermalTest.connectSvc.disconnect(deviceID);
      client.close();
    }
  }
}

