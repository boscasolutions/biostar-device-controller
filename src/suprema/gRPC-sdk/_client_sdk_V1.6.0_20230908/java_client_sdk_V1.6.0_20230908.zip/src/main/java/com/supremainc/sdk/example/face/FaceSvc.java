package com.supremainc.sdk.example.face;

import com.supremainc.sdk.face.FaceConfig;
import com.supremainc.sdk.face.FaceGrpc;
import com.supremainc.sdk.face.FaceData;
import com.supremainc.sdk.face.GetConfigRequest;
import com.supremainc.sdk.face.GetConfigResponse;
import com.supremainc.sdk.face.SetConfigRequest;
import com.supremainc.sdk.face.SetConfigResponse;
import com.supremainc.sdk.face.ScanRequest;
import com.supremainc.sdk.face.ScanResponse;
import com.supremainc.sdk.face.FaceEnrollThreshold;

public class FaceSvc {
  private final FaceGrpc.FaceBlockingStub faceStub;

  public FaceSvc(FaceGrpc.FaceBlockingStub stub) {
    faceStub = stub;
  }

  public FaceData scan(int deviceID, FaceEnrollThreshold enrollThreshold) throws Exception {
    ScanRequest request = ScanRequest.newBuilder().setDeviceID(deviceID).setEnrollThreshold(enrollThreshold).build();
    ScanResponse response = faceStub.scan(request);

    return response.getFaceData();
  } 
  
  public FaceConfig getConfig(int deviceID) throws Exception {
    GetConfigRequest request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build();
    GetConfigResponse response = faceStub.getConfig(request);

    return response.getConfig();
  }

  public void setConfig(int deviceID, FaceConfig config) throws Exception {
    SetConfigRequest request = SetConfigRequest.newBuilder().setDeviceID(deviceID).setConfig(config).build();
    SetConfigResponse response = faceStub.setConfig(request);
  }
}