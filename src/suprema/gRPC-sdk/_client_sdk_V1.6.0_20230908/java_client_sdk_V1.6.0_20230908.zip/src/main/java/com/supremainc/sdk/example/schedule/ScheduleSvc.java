package com.supremainc.sdk.example.schedule;

import java.util.List;

import com.supremainc.sdk.schedule.GetListRequest;
import com.supremainc.sdk.schedule.GetListResponse;
import com.supremainc.sdk.schedule.AddRequest;
import com.supremainc.sdk.schedule.DeleteRequest;
import com.supremainc.sdk.schedule.DeleteAllRequest;
import com.supremainc.sdk.schedule.GetHolidayListRequest;
import com.supremainc.sdk.schedule.GetHolidayListResponse;
import com.supremainc.sdk.schedule.AddHolidayRequest;
import com.supremainc.sdk.schedule.DeleteAllHolidayRequest;

import com.supremainc.sdk.schedule.ScheduleGrpc;
import com.supremainc.sdk.schedule.ScheduleInfo;
import com.supremainc.sdk.schedule.HolidayGroup;


public class ScheduleSvc {
  private final ScheduleGrpc.ScheduleBlockingStub scheduleStub;

  public ScheduleSvc(ScheduleGrpc.ScheduleBlockingStub stub) {
    scheduleStub = stub;
  }

  public List<ScheduleInfo> getList(int deviceID) throws Exception {
    GetListRequest request = GetListRequest.newBuilder().setDeviceID(deviceID).build();
    GetListResponse response = scheduleStub.getList(request);

    return response.getSchedulesList();
  } 

  public void add(int deviceID, List<ScheduleInfo> schedules) throws Exception {
    AddRequest request = AddRequest.newBuilder().setDeviceID(deviceID).addAllSchedules(schedules).build();
    scheduleStub.add(request);
  }

  public void delete(int deviceID, List<Integer> scheduleIDs) throws Exception {
    DeleteRequest request = DeleteRequest.newBuilder().setDeviceID(deviceID).addAllScheduleIDs(scheduleIDs).build();
    scheduleStub.delete(request);
  }

  public void deleteAll(int deviceID) throws Exception {
    DeleteAllRequest request = DeleteAllRequest.newBuilder().setDeviceID(deviceID).build();
    scheduleStub.deleteAll(request);
  }

  public List<HolidayGroup> getHolidayList(int deviceID) throws Exception {
    GetHolidayListRequest request = GetHolidayListRequest.newBuilder().setDeviceID(deviceID).build();
    GetHolidayListResponse response = scheduleStub.getHolidayList(request);

    return response.getGroupsList();
  } 

  public void addHoliday(int deviceID, List<HolidayGroup> groups) throws Exception {
    AddHolidayRequest request = AddHolidayRequest.newBuilder().setDeviceID(deviceID).addAllGroups(groups).build();
    scheduleStub.addHoliday(request);
  }

  public void deleteAllHoliday(int deviceID) throws Exception {
    DeleteAllHolidayRequest request = DeleteAllHolidayRequest.newBuilder().setDeviceID(deviceID).build();
    scheduleStub.deleteAllHoliday(request);
  }
}


  