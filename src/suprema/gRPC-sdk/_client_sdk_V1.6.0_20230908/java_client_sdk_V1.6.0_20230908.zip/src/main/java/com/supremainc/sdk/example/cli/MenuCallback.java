package com.supremainc.sdk.example.cli;

public interface MenuCallback {
  public void run();
}