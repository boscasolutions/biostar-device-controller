package com.supremainc.sdk.example.status.test;

import java.util.ListIterator;
import java.util.ArrayList;

import com.supremainc.sdk.status.StatusConfig;
import com.supremainc.sdk.status.LEDStatus;
import com.supremainc.sdk.status.BuzzerStatus;
import com.supremainc.sdk.status.DeviceStatus;
import com.supremainc.sdk.example.status.StatusSvc;
import com.supremainc.sdk.action.LEDSignal;
import com.supremainc.sdk.action.BuzzerSignal;
import com.supremainc.sdk.device.LEDColor;
import com.supremainc.sdk.device.BuzzerTone;
import com.supremainc.sdk.example.cli.KeyInput;

class ConfigTest {
  private StatusSvc statusSvc;

  public ConfigTest(StatusSvc svc) {
    statusSvc = svc;
  }

  public void test(int deviceID) throws Exception {
    // Backup the original configuration
    StatusConfig origConfig = statusSvc.getConfig(deviceID);
    System.out.printf("Original Config: %s\n\n", origConfig);

    StatusConfig testConfig = origConfig.toBuilder().build();
    testLED(deviceID, testConfig);
    testBuzzer(deviceID, testConfig);

    // Restore the original configuration
    statusSvc.setConfig(deviceID, origConfig);
  }

  public void testLED(int deviceID, StatusConfig config) throws Exception {
    System.out.printf("\n===== LED Status Test =====\n\n");

    // Change the LED color of the normal status to yellow
    ArrayList<LEDStatus> ledStateList = new ArrayList<LEDStatus>(config.getLEDStateList());
    ListIterator<LEDStatus> iterator = ledStateList.listIterator();
    while(iterator.hasNext()) {
      LEDStatus status = iterator.next();

      if(status.getDeviceStatus() == DeviceStatus.DEVICE_STATUS_NORMAL) {
        ArrayList<LEDSignal> ledSignals = new ArrayList<LEDSignal>();
        ledSignals.add(LEDSignal.newBuilder().setColor(LEDColor.LED_COLOR_YELLOW).setDuration(2000).setDelay(0).build());

        LEDStatus newStatus = LEDStatus.newBuilder().setDeviceStatus(DeviceStatus.DEVICE_STATUS_NORMAL).setCount(0).addAllSignals(ledSignals).build();
        iterator.set(newStatus);

        config = config.toBuilder().addAllLEDState(ledStateList).build();
        break;
      }
    }

    statusSvc.setConfig(deviceID, config);
    
    StatusConfig newConfig = statusSvc.getConfig(deviceID);
    System.out.printf("New Config: %s\n\n", newConfig);

    System.out.printf(">> The LED color of the normal status is changed to yellow.\n");
    KeyInput.pressEnter(">> Press ENTER for the next test.\n");
  }

  public void testBuzzer(int deviceID, StatusConfig config) throws Exception {
    System.out.printf("\n===== Buzzer Status Test =====\n\n");

    // Change the buzzer signal for FAIL
    ArrayList<BuzzerStatus> buzzerStateList = new ArrayList<BuzzerStatus>(config.getBuzzerStateList());
    ListIterator<BuzzerStatus> iterator = buzzerStateList.listIterator();
    while(iterator.hasNext()) {
      BuzzerStatus status = iterator.next();

      if(status.getDeviceStatus() == DeviceStatus.DEVICE_STATUS_FAIL) {
        ArrayList<BuzzerSignal> buzzerSignals = new ArrayList<BuzzerSignal>(); // 2 x 500ms beeps
        buzzerSignals.add(BuzzerSignal.newBuilder().setTone(BuzzerTone.BUZZER_TONE_HIGH).setDuration(500).setDelay(2).build());
        buzzerSignals.add(BuzzerSignal.newBuilder().setTone(BuzzerTone.BUZZER_TONE_HIGH).setDuration(500).setDelay(2).build());

        BuzzerStatus newStatus = BuzzerStatus.newBuilder().setDeviceStatus(DeviceStatus.DEVICE_STATUS_FAIL).setCount(1).addAllSignals(buzzerSignals).build();
        iterator.set(newStatus);

        config = config.toBuilder().addAllBuzzerState(buzzerStateList).build();
        break;
      }
    }

    statusSvc.setConfig(deviceID, config);
    
    StatusConfig newConfig = statusSvc.getConfig(deviceID);
    System.out.printf("New Config: %s\n\n", newConfig);

    System.out.printf(">> The buzzer for the FAIL status is changed to two 500ms beeps. Try to authenticate unregistered credentials for the test.\n");
    KeyInput.pressEnter(">> Press ENTER for the next test.\n");
  }

}