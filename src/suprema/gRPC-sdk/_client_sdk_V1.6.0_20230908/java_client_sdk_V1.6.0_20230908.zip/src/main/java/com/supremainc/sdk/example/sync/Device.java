package com.supremainc.sdk.example.sync;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import io.grpc.Context;
import io.grpc.Context.CancellableContext;

import com.supremainc.sdk.connect.AsyncConnectInfo;
import com.supremainc.sdk.connect.DeviceInfo;
import com.supremainc.sdk.connect.Status;
import com.supremainc.sdk.connect.StatusChange;
import com.supremainc.sdk.example.connect.ConnectSvc;

interface ConnectionCallback{
  void handleConnected(int deviceID) throws Exception;
}      

class DeviceMgr {
  private ConnectSvc connectSvc;
  private TestConfig testConfig;
  private List<Integer> connectedIDs;

  private CancellableContext monitoringCtx;
  private Context prevCtx;
  private Iterator<StatusChange> statusStream;
  private ConnectionCallback connCallback;

  public DeviceMgr(ConnectSvc svc, TestConfig config) {
    connectSvc = svc;
    testConfig = config;

    connectedIDs = new ArrayList<Integer>();
  }

  public void connectToDevices() throws Exception {
    List<AsyncConnectInfo> connInfos = testConfig.getAsyncConnectInfo();

    connectSvc.addAsyncConnection(connInfos);
  }

  public void deleteConnection() throws Exception {
    if(connectedIDs.size() > 0) {
      connectSvc.deleteAsyncConnection(connectedIDs);
    }

    if(monitoringCtx != null) {
      monitoringCtx.cancel(null);
      monitoringCtx.detach(prevCtx);
    }
  }  

  public List<Integer> getConnectedDevices(boolean refreshList) throws Exception {
    if(refreshList) {
      List<DeviceInfo> devInfos = connectSvc.getDeviceList();
      connectedIDs.clear();

      for(DeviceInfo dev:devInfos) {
        if(dev.getStatus() == Status.TCP_CONNECTED || dev.getStatus() == Status.TLS_CONNECTED) {
          connectedIDs.add(dev.getDeviceID());
        }
      }
    }

    return new ArrayList(connectedIDs);
  }

  class ConnectionHandler implements Runnable {
    public void run() {
      try {
        while(statusStream.hasNext()) {
          StatusChange change = statusStream.next();

          if(change.getStatus() == Status.TCP_CONNECTED || change.getStatus() == Status.TLS_CONNECTED) {
            connectedIDs.add(change.getDeviceID());

            if(connCallback != null) {
              connCallback.handleConnected(change.getDeviceID());
            }
          } else if(change.getStatus() == Status.DISCONNECTED) {
            connectedIDs.remove(new Integer(change.getDeviceID()));
          }

          if(change.getStatus() != Status.TCP_NOT_ALLOWED && change.getStatus() != Status.TLS_NOT_ALLOWED) {
            System.out.printf("\n[STATUS] Device status change: \n%s\n", change);
          }
        }
      } catch(Exception e) {
        io.grpc.Status errStatus = io.grpc.Status.fromThrowable(e);
        if(errStatus.getCode() == io.grpc.Status.Code.CANCELLED) {
          System.out.printf("Subscription is cancelled\n");
        } else {
          System.out.printf("Cannot receive device status: %s\n", e);
        }
      } 
    }
  }

  public void handleConnection(ConnectionCallback callback) throws Exception {
    monitoringCtx = Context.current().withCancellation();
    prevCtx = monitoringCtx.attach();

    connCallback = callback;
    statusStream = connectSvc.subscribe();
    
    new Thread(new ConnectionHandler()).start();
  }
}