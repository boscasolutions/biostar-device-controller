package com.supremainc.sdk.example.rtsp.test;

import com.supremainc.sdk.example.client.GatewayClient;
import com.supremainc.sdk.rtsp.RTSPGrpc;
import com.supremainc.sdk.rtsp.RTSPConfig;
import com.supremainc.sdk.example.rtsp.RtspSvc;
import com.supremainc.sdk.connect.ConnectGrpc;
import com.supremainc.sdk.connect.ConnectInfo;
import com.supremainc.sdk.example.connect.ConnectSvc;

public class RtspTest {
  private static final String CA_FILE = "../cert/gateway/ca.crt";

  private static final String GATEWAY_ADDR = "192.168.8.98";
  private static final int GATEWAY_PORT = 4000;

  private static final String DEVICE_ADDR = "192.168.8.227";
  private static final int DEVICE_PORT = 51211;
  private static final boolean DEVICE_USE_SSL = false;  

  private GatewayClient gatewayClient;
  private RtspSvc rtspSvc;
  private ConnectSvc connectSvc;

  public RtspTest(GatewayClient client) {
    gatewayClient = client;

    connectSvc = new ConnectSvc(ConnectGrpc.newBlockingStub(client.getChannel())); 
    rtspSvc = new RtspSvc(RTSPGrpc.newBlockingStub(client.getChannel())); 
  }

  public static void main(String[] args) throws Exception {
    GatewayClient client = new GatewayClient();

    try {
      client.connect(CA_FILE, GATEWAY_ADDR, GATEWAY_PORT);
    } catch (Exception e) {
      System.out.printf("Cannot connect to the gateway: %s", e); 
      System.exit(-1);
    }

    RtspTest rtspTest = new RtspTest(client);

    int deviceID = 0;

    try {
      ConnectInfo connInfo = ConnectInfo.newBuilder().setIPAddr(DEVICE_ADDR).setPort(DEVICE_PORT).setUseSSL(DEVICE_USE_SSL).build();

      deviceID = rtspTest.connectSvc.connect(connInfo);      
    } catch (Exception e) {
      System.out.printf("Cannot connect to the device: %s", e); 
      client.close();
      System.exit(-1);
    }

    RTSPConfig config = null;

    try {
      config = rtspTest.rtspSvc.getConfig(deviceID);

      System.out.printf("Rtsp Config: \n%s\n\n", config); 
    } catch (Exception e) {
      System.out.printf("Rtsp service is not supported by the device %d: %s", deviceID, e); 
      rtspTest.connectSvc.disconnect(deviceID);
      client.close();
      System.exit(-1);
    } finally {
      rtspTest.connectSvc.disconnect(deviceID);
      client.close();
    }
  }
}

