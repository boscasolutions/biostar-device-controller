package com.supremainc.sdk.example.event;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.supremainc.sdk.event.DisableMonitoringRequest;
import com.supremainc.sdk.event.EnableMonitoringRequest;
import com.supremainc.sdk.event.DisableMonitoringMultiRequest;
import com.supremainc.sdk.event.EnableMonitoringMultiRequest;
import com.supremainc.sdk.event.EventGrpc;
import com.supremainc.sdk.event.EventLog;
import com.supremainc.sdk.event.EventFilter;
import com.supremainc.sdk.event.GetImageLogRequest;
import com.supremainc.sdk.event.GetImageLogResponse;
import com.supremainc.sdk.event.GetLogRequest;
import com.supremainc.sdk.event.GetLogResponse;
import com.supremainc.sdk.event.GetLogWithFilterRequest;
import com.supremainc.sdk.event.GetLogWithFilterResponse;
import com.supremainc.sdk.event.ImageLog;
import com.supremainc.sdk.event.SubscribeRealtimeLogRequest;

import io.grpc.Context;
import io.grpc.Status;
import io.grpc.Context.CancellableContext;


import com.google.gson.Gson;

public class EventSvc {
  private final EventGrpc.EventBlockingStub eventStub;
  private CancellableContext monitoringCtx;
  private EventCallback eventCallback;
  private EventCodeMap codeMap;

  public EventSvc(EventGrpc.EventBlockingStub stub) {
    eventStub = stub;
    monitoringCtx = null;
    eventCallback = null;
  }

  public void setCancellableContext(CancellableContext ctx) {
    monitoringCtx = ctx;
  }

  public void setEventCallback(EventCallback callback) {
    eventCallback = callback;
  }

  public EventCallback getEventCallback() {
    return eventCallback;
  }

  public EventGrpc.EventBlockingStub getStub() {
    return eventStub;
  }

  public List<EventLog> getLog(int deviceID, int startEventID, int maxNumOfLog) throws Exception {
    GetLogRequest request = GetLogRequest.newBuilder().setDeviceID(deviceID).setStartEventID(startEventID).setMaxNumOfLog(maxNumOfLog).build();
    GetLogResponse response;

    response = eventStub.getLog(request);
    return response.getEventsList();
  } 

  public List<EventLog> getLogWithFilter(int deviceID, int startEventID, int maxNumOfLog, EventFilter filter) throws Exception {
    GetLogWithFilterRequest request = GetLogWithFilterRequest.newBuilder().setDeviceID(deviceID).setStartEventID(startEventID).setMaxNumOfLog(maxNumOfLog).addFilters(filter).build();
    GetLogWithFilterResponse response = eventStub.getLogWithFilter(request);

    return response.getEventsList();
  } 


  public List<ImageLog> getImageLog(int deviceID, int startEventID, int maxNumOfLog) throws Exception {
    GetImageLogRequest request = GetImageLogRequest.newBuilder().setDeviceID(deviceID).setStartEventID(startEventID).setMaxNumOfLog(maxNumOfLog).build();
    GetImageLogResponse response;

    response = eventStub.getImageLog(request);
    return response.getImageEventsList();
  } 

  public void startMonitoring(int deviceID) throws Exception {
    EnableMonitoringRequest enableRequest = EnableMonitoringRequest.newBuilder().setDeviceID(deviceID).build();
    eventStub.enableMonitoring(enableRequest);

    new Thread(new EventMonitoring(this, deviceID)).start();
  }

  public void stopMonitoring(int deviceID) throws Exception {
    DisableMonitoringRequest disableRequest = DisableMonitoringRequest.newBuilder().setDeviceID(deviceID).build();
    eventStub.disableMonitoring(disableRequest);

    if(monitoringCtx != null) {
      monitoringCtx.cancel(null);
    }
  }

  public void startMonitoring() throws Exception {
    new Thread(new EventMonitoring(this)).start();
  }

  public void stopMonitoring() throws Exception {
    if(monitoringCtx != null) {
      monitoringCtx.cancel(null);
    }
  }  

  public void enableMonitoring(int deviceID) throws Exception {
    EnableMonitoringRequest enableRequest = EnableMonitoringRequest.newBuilder().setDeviceID(deviceID).build();
    eventStub.enableMonitoring(enableRequest);
  }

  public void disableMonitoring(int deviceID) throws Exception {
    DisableMonitoringRequest disableRequest = DisableMonitoringRequest.newBuilder().setDeviceID(deviceID).build();
    eventStub.disableMonitoring(disableRequest);
  }  

  public void initCodeMap(String filename) throws Exception {
    String jsonData = new String(Files.readAllBytes(Paths.get(filename)));

    Gson gson = new Gson();
    codeMap = gson.fromJson(jsonData, EventCodeMap.class);
  }

  public String getEventString(int eventCode, int subCode) {
    if(codeMap == null) {
      return String.format("No code map(%#x)", eventCode | subCode);
    }

    for(int i = 0; i < codeMap.getEntryLength(); i++) {
      if(eventCode == codeMap.getEntry(i).getEventCode() && subCode == codeMap.getEntry(i).getSubCode()) {
        return codeMap.getEntry(i).getDesc();
      }
    }

    return String.format("Unknown code(%#x)", eventCode | subCode);
  }
}


class EventMonitoring implements Runnable {
  private static final int MONITORING_QUEUE_SIZE = 8;

  private final EventSvc eventSvc;
  private final int deviceID;

  public EventMonitoring(EventSvc svc, int devID) {
    eventSvc = svc;
    deviceID = devID;
  }

  public EventMonitoring(EventSvc svc) {
    eventSvc = svc;
    deviceID = 0;
  }


  public void run() {
    CancellableContext monitoringCtx = Context.current().withCancellation();
    Context prevCtx = monitoringCtx.attach();

    eventSvc.setCancellableContext(monitoringCtx);

    try {
      SubscribeRealtimeLogRequest subscribeRequest;
      
      if(deviceID != 0) {
        subscribeRequest = SubscribeRealtimeLogRequest.newBuilder().setQueueSize(MONITORING_QUEUE_SIZE).addDeviceIDs(deviceID).build();
      } else {
        subscribeRequest = SubscribeRealtimeLogRequest.newBuilder().setQueueSize(MONITORING_QUEUE_SIZE).build();
      }
      Iterator<EventLog> eventStream = eventSvc.getStub().subscribeRealtimeLog(subscribeRequest);

      System.out.println("Start receiving real-time events");

      while(eventStream.hasNext()) {
        EventLog eventLog = eventStream.next();

        if(eventSvc.getEventCallback() != null) {
          eventSvc.getEventCallback().handle(eventLog);
        } else {
          System.out.printf("Event: %s\n", eventLog);
        }
      }
    } catch(Exception e) {
      Status errStatus = Status.fromThrowable(e);
      if(errStatus.getCode() == Status.Code.CANCELLED) {
        System.out.printf("Monitoring is cancelled\n");
      } else {
        System.out.printf("Monitoring error: %s\n", e);
      }
    } finally {
      monitoringCtx.detach(prevCtx);
    }
  }
}


