#include <iostream>
#include <fstream>
#include "ServerSvc.h"

using gsdk::server::SubscribeRequest;

using gsdk::server::UnsubscribeRequest;
using gsdk::server::UnsubscribeResponse;

using gsdk::server::HandleVerifyRequest;
using gsdk::server::HandleVerifyResponse;

using gsdk::server::HandleIdentifyRequest;
using gsdk::server::HandleIdentifyResponse;


namespace example {
  std::unique_ptr<ClientReader<ServerRequest>> ServerSvc::Subscribe(ClientContext* context, int queueSize) {
    SubscribeRequest request;
    request.set_queuesize(queueSize);

    return stub_->Subscribe(context, request);
  }

  Status ServerSvc::Unsubscribe() {
    UnsubscribeRequest request;
    UnsubscribeResponse response;
    ClientContext context;

    Status status = stub_->Unsubscribe(&context, request, &response);
    if(!status.ok()) {
      std::cerr << "Cannot unsubscribe: " << status.error_message() << std::endl;
    }

    return status;
  }

  Status ServerSvc::HandleVerify(ServerRequest& req, ServerErrorCode errCode, UserInfo* userInfo) {
    HandleVerifyRequest request;
    request.set_deviceid(req.deviceid());
    request.set_seqno(req.seqno());
    request.set_errcode(errCode);
    if(userInfo) {
      *request.mutable_user() = *userInfo;
    }

    HandleVerifyResponse response;
    ClientContext context;

    Status status = stub_->HandleVerify(&context, request, &response);
    if(!status.ok()) {
      std::cerr << "Cannot handle verify: " << status.error_message() << std::endl;
    }

    return status;
  }

  Status ServerSvc::HandleIdentify(ServerRequest& req, ServerErrorCode errCode, UserInfo* userInfo) {
    HandleIdentifyRequest request;
    request.set_deviceid(req.deviceid());
    request.set_seqno(req.seqno());
    request.set_errcode(errCode);
    if(userInfo) {
      *request.mutable_user() = *userInfo;
    }

    HandleIdentifyResponse response;
    ClientContext context;

    Status status = stub_->HandleIdentify(&context, request, &response);
    if(!status.ok()) {
      std::cerr << "Cannot handle identify: " << status.error_message() << std::endl;
    }

    return status;
  }
} 