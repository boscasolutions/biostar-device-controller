#ifndef __SERVERT_SVC__H__
#define __SERVERT_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>

#include "server.grpc.pb.h"
#include "user.grpc.pb.h"

using grpc::Channel;
using grpc::Status;
using grpc::ClientReader;
using grpc::ClientContext;

using gsdk::user::UserInfo;

using gsdk::server::Server;
using gsdk::server::ServerRequest;
using gsdk::server::ServerErrorCode;

namespace example {
  class ServerSvc {
  public:
    ServerSvc(std::shared_ptr<Channel> channel)
        : stub_(Server::NewStub(channel)) {}

    std::unique_ptr<ClientReader<ServerRequest>> Subscribe(ClientContext* context, int queueSize);
    Status Unsubscribe();

    Status HandleVerify(ServerRequest& req, ServerErrorCode errCode, UserInfo* userInfo);
    Status HandleIdentify(ServerRequest& req, ServerErrorCode errCode, UserInfo* userInfo);

  private:
    std::unique_ptr<Server::Stub> stub_;
  };
}

#endif
