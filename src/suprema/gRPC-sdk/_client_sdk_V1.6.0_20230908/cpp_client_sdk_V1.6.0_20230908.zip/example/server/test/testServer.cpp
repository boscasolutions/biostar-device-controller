#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <thread>
#include "ServerSvc.h"
#include "AuthSvc.h"
#include "Menu.h"
#include "card.grpc.pb.h"
#include "finger.grpc.pb.h"

using grpc::ClientContext;

using example::ServerSvc;
using example::AuthSvc;
using example::Menu;

using gsdk::server::RequestType;
using gsdk::user::UserHdr;
using gsdk::card::CSNCardData;
using gsdk::finger::FingerData;

const int QUEUE_SIZE = 16;
const std::string TEST_USER_ID = "1234";

static bool s_ReturnError = false;

void testVerify(ServerSvc& serverSvc);
void handleVerify(ServerSvc& serverSvc, std::unique_ptr<ClientReader<ServerRequest>> reqReader);

void testIdentify(ServerSvc& serverSvc);
void handleIdentify(ServerSvc& serverSvc, std::unique_ptr<ClientReader<ServerRequest>> reqReader);

void testServer(ServerSvc& serverSvc, AuthSvc& authSvc, uint32_t deviceID) {
  // Backup the original configuration
  AuthConfig origConfig;
  Status status = authSvc.GetConfig(deviceID, &origConfig);
  if (!status.ok()) {
	  return;
  }

  std::cout << std::endl << "Original Auth Config: " << std::endl << origConfig.ShortDebugString() << std::endl << std::endl;

  // Enable server matching for the test
  AuthConfig testConfig;
  testConfig.CopyFrom(origConfig);
  testConfig.set_useservermatching(true);

  authSvc.SetConfig(deviceID, testConfig);

  AuthConfig newConfig;
  authSvc.GetConfig(deviceID, &newConfig);

  std::cout << std::endl << "Test Auth Config: " << std::endl << newConfig.ShortDebugString() << std::endl << std::endl;

  testVerify(serverSvc);
  testIdentify(serverSvc);

  // Restore the original configuration
  authSvc.SetConfig(deviceID, origConfig);
}


void testVerify(ServerSvc& serverSvc) {
	ClientContext context;
	auto reqReader(serverSvc.Subscribe(&context, QUEUE_SIZE));

  s_ReturnError = true;
	auto serverThread(std::thread(handleVerify, std::ref(serverSvc), std::move(reqReader)));

  std::cout << std::endl << "===== Server Matching: Verify Test =====" << std::endl << std::endl;
  std::cout << ">> Try to authenticate a card. It should fail since the device gateway will return an error code to the request." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");

  s_ReturnError = false;
  std::cout << ">> Try to authenticate a card. The gateway will return SUCCESS with user information this time. The result will vary according to the authentication modes of the devices." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");

  context.TryCancel();
	serverThread.join();
  serverSvc.Unsubscribe();  
}


void handleVerify(ServerSvc& serverSvc, std::unique_ptr<ClientReader<ServerRequest>> reqReader) {
	ServerRequest req;

	while (reqReader->Read(&req)) {
    if(req.reqtype() != RequestType::VERIFY_REQUEST) {
      std::cout << "!! Request type is not VERIFY_REQUEST. Just ignore it." << std::endl;
      continue;
    }

    if(s_ReturnError) {
      std::cout << "## Gateway returns VERIFY_FAIL." << std::endl;
      serverSvc.HandleVerify(req, ServerErrorCode::VERIFY_FAIL, NULL);
    } else {
      UserHdr hdr;
      hdr.set_id(TEST_USER_ID);
      hdr.set_numofcard(1);

      CSNCardData card;
      *card.mutable_data() = req.verifyreq().carddata();

      UserInfo userInfo;
      *userInfo.mutable_hdr() = hdr;
      *userInfo.add_cards() = card;

      serverSvc.HandleVerify(req, ServerErrorCode::SUCCESS, &userInfo);
    }
  }

	std::cout << "Server thread is stopped" << std::endl;
	reqReader->Finish();
}


void testIdentify(ServerSvc& serverSvc) {
	ClientContext context;
	auto reqReader(serverSvc.Subscribe(&context, QUEUE_SIZE));

  s_ReturnError = true;
	auto serverThread(std::thread(handleIdentify, std::ref(serverSvc), std::move(reqReader)));

  std::cout << std::endl << "===== Server Matching: Identify Test =====" << std::endl << std::endl;
  std::cout << ">> Try to authenticate a finger. It should fail since the device gateway will return an error code to the request." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");

  s_ReturnError = false;
  std::cout << ">> Try to authenticate a finger. The gateway will return SUCCESS with user information this time. The result will vary according to the authentication modes of the devices." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");

  context.TryCancel();
	serverThread.join();
  serverSvc.Unsubscribe();
}


void handleIdentify(ServerSvc& serverSvc, std::unique_ptr<ClientReader<ServerRequest>> reqReader) {
	ServerRequest req;

	while (reqReader->Read(&req)) {
    if(req.reqtype() != RequestType::IDENTIFY_REQUEST) {
      std::cout << "!! Request type is not IDENTIFY_REQUEST. Just ignore it." << std::endl;
      continue;
    }

    if(s_ReturnError) {
      std::cout << "## Gateway returns IDENTIFY_FAIL." << std::endl;
      serverSvc.HandleIdentify(req, ServerErrorCode::IDENTIFY_FAIL, NULL);
    } else {
      UserHdr hdr;
      hdr.set_id(TEST_USER_ID);
      hdr.set_numoffinger(1);

      FingerData finger;
      *finger.add_templates() = req.identifyreq().templatedata();
      *finger.add_templates() = req.identifyreq().templatedata();

      UserInfo userInfo;
      *userInfo.mutable_hdr() = hdr;
      *userInfo.add_fingers() = finger;

      serverSvc.HandleIdentify(req, ServerErrorCode::SUCCESS, &userInfo);
    }
  }

	std::cout << "Server thread is stopped" << std::endl;
	reqReader->Finish();
}

