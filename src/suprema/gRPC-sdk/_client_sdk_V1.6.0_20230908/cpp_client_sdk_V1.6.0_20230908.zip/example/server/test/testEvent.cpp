#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <thread>
#include "EventSvc.h"
#include "Menu.h"

using grpc::ClientContext;
using example::EventSvc;

std::shared_ptr<ClientContext> s_MonitoringContext;
std::thread s_MonitoringThread;

const int EVENT_QUEUE_SIZE = 16;

void handleEvent(EventSvc& svc, std::unique_ptr<ClientReader<EventLog>> eventReader);

void startMonitoring(EventSvc& svc, uint32_t deviceID) {
  Status status = svc.EnableMonitoring(deviceID);

  if (!status.ok()) {
	  return;
  }

	s_MonitoringContext = std::make_shared<ClientContext>();
	auto eventReader(svc.Subscribe(s_MonitoringContext.get(), EVENT_QUEUE_SIZE));

	s_MonitoringThread = std::thread(handleEvent, std::ref(svc), std::move(eventReader));
}

void stopMonitoring(EventSvc& svc, uint32_t deviceID) {
  s_MonitoringContext->TryCancel();
	s_MonitoringThread.join();
  svc.DisableMonitoring(deviceID);  
}

void handleEvent(EventSvc& svc, std::unique_ptr<ClientReader<EventLog>> eventReader) {
	EventLog realtimeEvent;

	while (eventReader->Read(&realtimeEvent)) {
  	time_t eventTime = (time_t)realtimeEvent.timestamp();
    std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Device " << realtimeEvent.deviceid() << ", User " << realtimeEvent.userid() << ", " << svc.GetEventString(realtimeEvent.eventcode(), realtimeEvent.subcode()) << std::endl;
	}

	std::cout << "Monitoring thread is stopped" << std::endl;

	eventReader->Finish();
}

