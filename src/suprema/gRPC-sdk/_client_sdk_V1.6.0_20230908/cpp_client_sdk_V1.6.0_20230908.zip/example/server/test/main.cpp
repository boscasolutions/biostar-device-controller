#include <string>
#include <string.h>
#include <stdint.h>
#include <iostream>
#include <grpcpp/grpcpp.h>
#include <stdlib.h>
#include "GatewayClient.h"
#include "ConnectSvc.h"
#include "ServerSvc.h"
#include "EventSvc.h"
#include "AuthSvc.h"

using grpc::Channel;
using grpc::Status;

using example::GatewayClient;
using example::ConnectSvc;
using example::ServerSvc;
using example::EventSvc;
using example::AuthSvc;

using google::protobuf::RepeatedPtrField;

const std::string GATEWAY_CA_FILE = "../cert/gateway/ca.crt";
const std::string GATEWAY_ADDR = "192.168.0.2";
const int GATEWAY_PORT = 4000;

const std::string DEVICE_IP = "192.168.0.110";
const int DEVICE_PORT = 51211;
const bool USE_SSL = false;

const std::string CODE_MAP_FILE = "./event_code.json";

void startMonitoring(EventSvc& svc, uint32_t deviceID);
void stopMonitoring(EventSvc& svc, uint32_t deviceID);

void testServer(ServerSvc& serverSvc, AuthSvc& authSvc, uint32_t deviceID);

int main(int argc, char** argv) {
  uint32_t deviceID = 0;

  auto gatewayClient = std::make_shared<GatewayClient>();
  if(!gatewayClient->Connect(GATEWAY_ADDR, GATEWAY_PORT, GATEWAY_CA_FILE)) {
    std::cerr << "Cannot connect to the gateway" << std::endl;
    exit(1);
  }

  ConnectSvc connectSvc(gatewayClient->GetChannel());

  ConnectInfo connInfo;
  connInfo.set_ipaddr(DEVICE_IP);
  connInfo.set_port(DEVICE_PORT);
  connInfo.set_usessl(USE_SSL);

  Status status = connectSvc.Connect(connInfo, &deviceID);
  if(!status.ok()) {
    std::cerr << "Cannot connect to the device " << deviceID << std::endl;
    exit(1);
  }  

  std::vector<uint32_t> deviceIDs;
  deviceIDs.push_back(deviceID);
  
  EventSvc eventSvc(gatewayClient->GetChannel());
  eventSvc.InitCodeMap(CODE_MAP_FILE);
  startMonitoring(eventSvc, deviceID);  

  ServerSvc serverSvc(gatewayClient->GetChannel());
  AuthSvc authSvc(gatewayClient->GetChannel());
  testServer(serverSvc, authSvc, deviceID);

  stopMonitoring(eventSvc, deviceID);
  connectSvc.Disconnect(deviceIDs);

  return 0;
}