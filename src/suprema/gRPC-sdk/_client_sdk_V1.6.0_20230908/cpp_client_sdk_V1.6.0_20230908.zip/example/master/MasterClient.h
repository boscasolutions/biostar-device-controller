#ifndef __MASTER_CLIENT__H__
#define __MASTER_CLIENT__H__

#include <string>
#include "GrpcClient.h"

namespace example {
  class MasterClient : public GrpcClient {
  public:
    MasterClient();
    ~MasterClient() {}

    std::string GetToken() {
      return token_;
    }

    bool ConnectTenant(std::string ipAddr, int port, std::string caFile, std::string tenantCertFile, std::string tenantKeyFile);
    bool ConnectAdmin(std::string ipAddr, int port, std::string caFile, std::string adminCertFile, std::string adminKeyFile);

  private:
    std::string token_;
  };
}

#endif