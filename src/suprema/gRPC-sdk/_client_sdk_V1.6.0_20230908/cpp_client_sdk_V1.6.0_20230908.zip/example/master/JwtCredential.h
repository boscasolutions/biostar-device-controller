#ifndef __JWT_CREDENTIAL__H__
#define __JWT_CREDENTIAL__H__

#include <string>
#include <grpcpp/grpcpp.h>
#include "MasterClient.h"

using grpc::Status;

namespace example {
  class JwtCredential : public grpc::MetadataCredentialsPlugin {
  public:
    JwtCredential(MasterClient* client);
    ~JwtCredential() {}

    grpc::Status GetMetadata(grpc::string_ref service_url, grpc::string_ref method_name,
          const grpc::AuthContext& channel_auth_context,
          std::multimap<grpc::string, grpc::string>* metadata);

  private:
    MasterClient* masterClient_;
  };
}

#endif