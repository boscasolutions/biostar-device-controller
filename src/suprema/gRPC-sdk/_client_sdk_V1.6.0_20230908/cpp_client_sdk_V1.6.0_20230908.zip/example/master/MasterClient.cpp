#include <sstream>
#include <fstream>
#include <iostream>
#include <grpcpp/grpcpp.h>
#include "login.grpc.pb.h"
#include "MasterClient.h"
#include "JwtCredential.h"

using grpc::ClientContext;
using gsdk::login::Login;
using gsdk::login::LoginRequest;
using gsdk::login::LoginResponse;
using gsdk::login::LoginAdminRequest;
using gsdk::login::LoginAdminResponse;

namespace example {
  const std::string ADMIN_TENANT_ID = "administrator";

  MasterClient::MasterClient() {
    token_ = "";
  }

  bool MasterClient::ConnectTenant(std::string ipAddr, int port, std::string caFile, std::string certFile, std::string keyFile) {
    std::ifstream caCertFile(caFile), tenantCertFile(certFile), tenantKeyFile(keyFile);
    std::stringstream caCertBuf, tenantCertBuf, tenantKeyBuf;
    caCertBuf << caCertFile.rdbuf();
    tenantCertBuf << tenantCertFile.rdbuf();
    tenantKeyBuf << tenantKeyFile.rdbuf();
    
    grpc::SslCredentialsOptions sslOpts;
    sslOpts.pem_root_certs = caCertBuf.str();
    sslOpts.pem_cert_chain = tenantCertBuf.str();
    sslOpts.pem_private_key = tenantKeyBuf.str();

    auto channelCreds = grpc::SslCredentials(sslOpts);
    auto callCreds = grpc::MetadataCredentialsFromPlugin(std::unique_ptr<grpc::MetadataCredentialsPlugin>(new JwtCredential(this)));
    auto composedCreds = grpc::CompositeChannelCredentials(channelCreds, callCreds);

    std::stringstream masterAddr;
    masterAddr << ipAddr << ":" << port;

    channel_ = grpc::CreateChannel(masterAddr.str(),  composedCreds);

    if(channel_ == NULL) {
      return false;
    }

    auto loginStub = Login::NewStub(channel_);

		LoginRequest request;
		request.set_tenantcert(tenantCertBuf.str());
		LoginResponse response;
		ClientContext context;

		Status status = loginStub->Login(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot login: " << status.error_message() << std::endl;
			return false;
		}

    token_ = response.jwttoken();

    return true;
  }

  bool MasterClient::ConnectAdmin(std::string ipAddr, int port, std::string caFile, std::string certFile, std::string keyFile) {
    std::ifstream caCertFile(caFile), adminCertFile(certFile), adminKeyFile(keyFile);
    std::stringstream caCertBuf, adminCertBuf, adminKeyBuf;
    caCertBuf << caCertFile.rdbuf();
    adminCertBuf << adminCertFile.rdbuf();
    adminKeyBuf << adminKeyFile.rdbuf();
    
    grpc::SslCredentialsOptions sslOpts;
    sslOpts.pem_root_certs = caCertBuf.str();
    sslOpts.pem_cert_chain = adminCertBuf.str();
    sslOpts.pem_private_key = adminKeyBuf.str();

    auto channelCreds = grpc::SslCredentials(sslOpts);
    auto callCreds = grpc::MetadataCredentialsFromPlugin(std::unique_ptr<grpc::MetadataCredentialsPlugin>(new JwtCredential(this)));
    auto composedCreds = grpc::CompositeChannelCredentials(channelCreds, callCreds);

    std::stringstream masterAddr;
    masterAddr << ipAddr << ":" << port;

    channel_ = grpc::CreateChannel(masterAddr.str(),  composedCreds);

    if(channel_ == NULL) {
      return false;
    }

    auto loginStub = Login::NewStub(channel_);

		LoginAdminRequest request;
		request.set_admintenantcert(adminCertBuf.str());
    request.set_tenantid(ADMIN_TENANT_ID);
		LoginAdminResponse response;
		ClientContext context;

		Status status = loginStub->LoginAdmin(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot login as an administrator: " << status.error_message() << std::endl;
			return false;
		}

    token_ = response.jwttoken();

    return true;
  }  
}