#include <grpcpp/grpcpp.h>
#include "JwtCredential.h"

namespace example {
  const std::string JWT_TOKEN_KEY = "token";

  JwtCredential::JwtCredential(MasterClient* client) {
    masterClient_ = client;
  }

  grpc::Status JwtCredential::GetMetadata(grpc::string_ref service_url, grpc::string_ref method_name,
      const grpc::AuthContext& channel_auth_context,
      std::multimap<grpc::string, grpc::string>* metadata) {
    metadata->insert(std::make_pair(JWT_TOKEN_KEY, masterClient_->GetToken()));
    return grpc::Status::OK;
  }
}