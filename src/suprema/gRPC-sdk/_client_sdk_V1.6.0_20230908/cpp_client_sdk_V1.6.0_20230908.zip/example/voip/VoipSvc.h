#ifndef __VOIP_SVC__H__
#define __VOIP_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "voip.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::voip::VOIP;
using gsdk::voip::VOIPConfig;

using google::protobuf::RepeatedPtrField;

namespace example {
	class VoipSvc {
	public:
		VoipSvc(std::shared_ptr<Channel> channel)
			: stub_(VOIP::NewStub(channel)) {}

		Status GetConfig(uint32_t deviceID, VOIPConfig* config);
		Status SetConfig(uint32_t deviceID, VOIPConfig& config);

	private:
		std::unique_ptr<VOIP::Stub> stub_;
	};
}

#endif
