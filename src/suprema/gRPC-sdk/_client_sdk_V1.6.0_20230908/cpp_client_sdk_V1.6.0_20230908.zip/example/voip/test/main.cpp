#include <string>
#include <string.h>
#include <stdint.h>
#include <iostream>
#include <grpcpp/grpcpp.h>
#include <stdlib.h>
#include "GatewayClient.h"
#include "ConnectSvc.h"
#include "VoipSvc.h"

using grpc::Channel;
using grpc::Status;

using example::GatewayClient;
using example::ConnectSvc;
using example::VoipSvc;

using google::protobuf::RepeatedPtrField;

const std::string GATEWAY_CA_FILE = "../cert/gateway/ca.crt";
const std::string GATEWAY_ADDR = "192.168.8.98";
const int GATEWAY_PORT = 4000;

const std::string DEVICE_IP = "192.168.8.227";
const int DEVICE_PORT = 51211;
const bool USE_SSL = false;

extern void testConfig(VoipSvc& svc, uint32_t deviceID, VOIPConfig& config);

int main(int argc, char** argv) {
  uint32_t deviceID = 0;

  auto gatewayClient = std::make_shared<GatewayClient>();
  if(!gatewayClient->Connect(GATEWAY_ADDR, GATEWAY_PORT, GATEWAY_CA_FILE)) {
    std::cerr << "Cannot connect to the gateway" << std::endl;
    exit(1);
  }

  ConnectSvc connectSvc(gatewayClient->GetChannel());

  ConnectInfo connInfo;
  connInfo.set_ipaddr(DEVICE_IP);
  connInfo.set_port(DEVICE_PORT);
  connInfo.set_usessl(USE_SSL);

  Status status = connectSvc.Connect(connInfo, &deviceID);
  if(!status.ok()) {
    std::cerr << "Cannot connect to the device " << deviceID << std::endl;
    exit(1);
  }  

  std::vector<uint32_t> deviceIDs;
  deviceIDs.push_back(deviceID);

  VoipSvc voipSvc(gatewayClient->GetChannel());
  VOIPConfig voipConfig;
  status = voipSvc.GetConfig(deviceID, &voipConfig);  
  if(!status.ok()) {
    std::cerr << "Voip service is not supported by the device " << deviceID << std::endl;
    connectSvc.Disconnect(deviceIDs);
    exit(1);
  }  

  std::cout << std::endl << "Voip Config: " << std::endl << voipConfig.ShortDebugString() << std::endl << std::endl;

  testConfig(voipSvc, deviceID, voipConfig);

  connectSvc.Disconnect(deviceIDs);

  return 0;
}