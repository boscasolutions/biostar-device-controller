#include <iostream>
#include "VoipSvc.h"

using grpc::ClientContext;

using gsdk::voip::GetConfigRequest;
using gsdk::voip::GetConfigResponse;

using gsdk::voip::SetConfigRequest;
using gsdk::voip::SetConfigResponse;

namespace example {

	Status VoipSvc::GetConfig(uint32_t deviceID, VOIPConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the voip config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}	

	Status VoipSvc::SetConfig(uint32_t deviceID, VOIPConfig& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
    *request.mutable_config() = config;

		SetConfigResponse response;

		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the voip config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}	  
}