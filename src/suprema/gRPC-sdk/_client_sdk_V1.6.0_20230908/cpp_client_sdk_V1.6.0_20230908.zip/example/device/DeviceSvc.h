#ifndef __DEVICE_SVC__H__
#define __DEVICE_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>

#include "device.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::device::Device;
using gsdk::device::FactoryInfo;
using gsdk::device::CapabilityInfo;
using gsdk::device::DeviceCapability;

namespace example {
	class DeviceSvc {
	public:
		DeviceSvc(std::shared_ptr<Channel> channel)
			: stub_(Device::NewStub(channel)) {}

		Status GetInfo(uint32_t deviceID, FactoryInfo* info);
		Status GetCapabilityInfo(uint32_t deviceID, CapabilityInfo* capInfo);
		Status GetCapability(uint32_t deviceID, DeviceCapability *capability);

	private:
		std::unique_ptr<Device::Stub> stub_;
	};
}

#endif
