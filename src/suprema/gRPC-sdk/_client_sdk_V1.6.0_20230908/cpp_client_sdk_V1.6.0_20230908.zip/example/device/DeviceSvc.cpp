#include <iostream>
#include "DeviceSvc.h"

using grpc::ClientContext;

using gsdk::device::GetInfoRequest;
using gsdk::device::GetInfoResponse;

using gsdk::device::GetCapabilityInfoRequest;
using gsdk::device::GetCapabilityInfoResponse;
using gsdk::device::GetCapabilityRequest;
using gsdk::device::GetCapabilityResponse;

namespace example {
	Status DeviceSvc::GetInfo(uint32_t deviceID, FactoryInfo* info) {
		GetInfoRequest request;
		request.set_deviceid(deviceID);

		GetInfoResponse response;

		ClientContext context;

		Status status = stub_->GetInfo(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the device information: " << status.error_message() << std::endl;
			return status;
		}

		*info = response.info();

		return status;
	}

	Status DeviceSvc::GetCapabilityInfo(uint32_t deviceID, CapabilityInfo* info) {
		GetCapabilityInfoRequest request;
		request.set_deviceid(deviceID);

		GetCapabilityInfoResponse response;

		ClientContext context;

		Status status = stub_->GetCapabilityInfo(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the capability information: " << status.error_message() << std::endl;
			return status;
		}

		*info = response.capinfo();

		return status;
	}
	
	Status DeviceSvc::GetCapability(uint32_t deviceID, DeviceCapability *capability) {
		GetCapabilityRequest request;
		request.set_deviceid(deviceID);

		GetCapabilityResponse response;

		ClientContext context;

		Status status = stub_->GetCapability(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the device capability: " << status.error_message() << std::endl;
			return status;
		}

		*capability = response.devicecapability();

		return status;
	}
}