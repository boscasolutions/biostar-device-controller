#include <iostream>
#include <string>
#include "Menu.h"

namespace example {
  void Menu::Show(std::string title) {
    while(true) {
      std::cout << std::endl << "===== " << title << " =====" << std::endl << std::endl;

      for(int i = 0; i < items_.size(); i++) {
        std::cout << "(" << items_[i]->key << ") " << items_[i]->text << std::endl;
      }

      std::cout << std::endl << ">>>>> Select a menu: ";
      std::string inputStr;
      std::getline(std::cin, inputStr);

      bool exitMenu = false;

      for(int i = 0; i < items_.size(); i++) {
        if(inputStr == items_[i]->key) {
          if(items_[i]->callback) {
			      items_[i]->callback(items_[i]->arg);
          }

          if(items_[i]->exit) {
			      exitMenu = true;
          }

          break;
        }
      }

      if(exitMenu) {
        break;
      }
    }
  }

  void Menu::GetUserInput(std::vector<std::shared_ptr<InputItem>>& inputItems, std::vector<std::string>& values) {
		for(int i = 0; i < inputItems.size(); i++) {
      std::cout << ">> " << inputItems[i]->text << ": ";
      std::string inputVal;
      std::getline(std::cin, inputVal);

      if(inputVal != "") {
        values.push_back(inputVal);
      } else {
        values.push_back(inputItems[i]->defaultVal);
      }
    }
  }

  void Menu::GetDeviceID(std::vector<uint32_t>& deviceIDs) {
    while(true) {
      std::cout << ">> Enter the device ID (Press just ENTER if no more device): ";
      std::string idStr;
      std::getline(std::cin, idStr);

      if(idStr == "") {
        break;
      }

      try {
		    uint32_t deviceID = std::stoi(idStr);
        deviceIDs.push_back(deviceID);
      } catch (std::invalid_argument const &e) {
        std::cerr << "Invalid device ID: " << idStr << std::endl;
        return;
      }
    }
  }

  void Menu::PressEnter(std::string msg) {
    std::string inputVal;
    std::cout << msg;
    std::getline(std::cin, inputVal);
  }

}
