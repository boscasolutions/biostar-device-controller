#ifndef __CLI_MENU__H__
#define __CLI_MENU__H__

#include <memory>
#include <string>
#include <vector>
#include <stdint.h>
#include <google/protobuf/repeated_field.h>

using google::protobuf::RepeatedPtrField;

namespace example {
  typedef void (*MenuCallback)(void* arg);

  struct MenuItem {
    std::string key;
    std::string text;
    MenuCallback callback;
		void* arg;
    bool exit;    
  };

  struct InputItem {
    std::string text;
    std::string defaultVal;
  };

  class Menu {
  public:
    Menu(std::vector<std::shared_ptr<MenuItem>> menuItems)
      : items_(menuItems) {}
    ~Menu(){}

    void Show(std::string title);

    static void GetUserInput(std::vector<std::shared_ptr<InputItem>>& inputItems, std::vector<std::string>& values);

    static void GetDeviceID(std::vector<uint32_t>& deviceIDs);

    static void PressEnter(std::string msg);

    template<class T> static void PrintList(std::string title, RepeatedPtrField<T> items);
  private:    
    std::vector<std::shared_ptr<MenuItem>> items_;
  };

  template<class T> void Menu::PrintList(std::string title, RepeatedPtrField<T> items) {
    std::cout << std::endl << title << std::endl;
    for(int i = 0; i < items.size(); i++) {
      std::cout << items[i].ShortDebugString() << std::endl;
    }
    std::cout << std::endl;
  }  
}

#endif
