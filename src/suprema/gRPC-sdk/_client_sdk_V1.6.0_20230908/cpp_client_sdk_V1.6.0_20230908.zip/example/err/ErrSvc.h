#ifndef __ERR_SVC__H__
#define __ERR_SVC__H__

#include <grpcpp/grpcpp.h>

#include "err.grpc.pb.h"

using grpc::Status;
using gsdk::err::MultiErrorResponse;

namespace example {
  class ErrSvc {
  public:
    static bool GetMultiError(Status& status, MultiErrorResponse* multiError);
  };
}

#endif