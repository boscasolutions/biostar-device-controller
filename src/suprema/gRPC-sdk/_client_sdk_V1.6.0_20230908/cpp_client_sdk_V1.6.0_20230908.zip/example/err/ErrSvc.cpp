#include "ErrSvc.h"
#include "grpc/status/status.pb.h"

using google::protobuf::Any;
using RpcStatus = google::rpc::Status;

namespace example {
  bool ErrSvc::GetMultiError(Status& status, MultiErrorResponse* multiError) {
    RpcStatus rpcStatus;
    bool ok = rpcStatus.ParseFromString(status.error_details());
    if(ok) {
      for(auto& any : rpcStatus.details()) {
        if(any.UnpackTo(multiError)) {
          return true;
        }
      }
    }

    return false;
  }
}