#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "ActionSvc.h"
#include "Menu.h"
#include "action.grpc.pb.h"

using example::ActionSvc;
using example::Menu;

using gsdk::action::EventTrigger;
using gsdk::action::Trigger;
using gsdk::action::TriggerType;
using gsdk::action::Signal;
using gsdk::action::RelayAction;
using gsdk::action::Action;
using gsdk::action::ActionType;
using gsdk::action::TriggerActionConfig_TriggerAction;

const int BS2_EVENT_VERIFY_FAIL = 0x1100;
const int BS2_EVENT_IDENTIFY_FAIL = 0x1400;

const int BS2_SUB_EVENT_CREDENTIAL_CARD = 0x02;
const int BS2_SUB_EVENT_CREDENTIAL_FINGER = 0x04;

void testEventTrigger(ActionSvc& svc, uint32_t deviceID);

void testConfig(ActionSvc& svc, uint32_t deviceID) {
  // Backup the original configuration
  TriggerActionConfig origConfig;
  Status status = svc.GetConfig(deviceID, &origConfig);
  if (!status.ok()) {
	  return;
  }
  std::cout << std::endl << "Original Config: " << std::endl << origConfig.ShortDebugString() << std::endl << std::endl;

  testEventTrigger(svc, deviceID);

  // Restore the original configuration
  svc.SetConfig(deviceID, origConfig);
}


void testEventTrigger(ActionSvc& svc, uint32_t deviceID) {
  std::cout << std::endl << "===== Trigger & Action Test =====" << std::endl << std::endl;

  EventTrigger cardFailEventTrigger;
  cardFailEventTrigger.set_eventcode(BS2_EVENT_VERIFY_FAIL | BS2_SUB_EVENT_CREDENTIAL_CARD);

  Trigger cardFailTrigger;
  cardFailTrigger.set_deviceid(deviceID);
  cardFailTrigger.set_type(TriggerType::TRIGGER_EVENT);
  *cardFailTrigger.mutable_event() = cardFailEventTrigger;

  EventTrigger fingerFailEventTrigger;
  fingerFailEventTrigger.set_eventcode(BS2_EVENT_IDENTIFY_FAIL | BS2_SUB_EVENT_CREDENTIAL_FINGER);

  Trigger fingerFailTrigger;
  fingerFailTrigger.set_deviceid(deviceID);
  fingerFailTrigger.set_type(TriggerType::TRIGGER_EVENT);
  *fingerFailTrigger.mutable_event() = fingerFailEventTrigger;

  Signal failSignal;
  failSignal.set_count(3);
  failSignal.set_onduration(500);
  failSignal.set_offduration(500);

  RelayAction failRelayAction;
  failRelayAction.set_relayindex(0);
  *failRelayAction.mutable_signal() = failSignal;

  Action failAction;
  failAction.set_deviceid(deviceID);
  failAction.set_type(ActionType::ACTION_RELAY);
  *failAction.mutable_relay() = failRelayAction;

  TriggerActionConfig_TriggerAction cardTriggerAction;
  *cardTriggerAction.mutable_trigger() = cardFailTrigger;
  *cardTriggerAction.mutable_action() = failAction;

  TriggerActionConfig_TriggerAction fingerTriggerAction;
  *fingerTriggerAction.mutable_trigger() = fingerFailTrigger;
  *fingerTriggerAction.mutable_action() = failAction;

  TriggerActionConfig config;
  *config.add_triggeractions() = cardTriggerAction;
  *config.add_triggeractions() = fingerTriggerAction;

  svc.SetConfig(deviceID, config);

  TriggerActionConfig newConfig;
  svc.GetConfig(deviceID, &newConfig);
  std::cout << std::endl << "Test Config: " << std::endl << newConfig.ShortDebugString() << std::endl << std::endl;

  std::cout << ">> Try to authenticate a unregistered card or finger. It should trigger a relay signal." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER to finish the test.\n");  
}

