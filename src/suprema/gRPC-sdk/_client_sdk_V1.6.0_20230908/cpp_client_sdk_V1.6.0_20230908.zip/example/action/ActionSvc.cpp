#include <iostream>
#include "ActionSvc.h"

using grpc::ClientContext;

using gsdk::action::GetConfigRequest;
using gsdk::action::GetConfigResponse;

using gsdk::action::SetConfigRequest;
using gsdk::action::SetConfigResponse;

namespace example {

	Status ActionSvc::GetConfig(uint32_t deviceID, TriggerActionConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the action config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}	

	Status ActionSvc::SetConfig(uint32_t deviceID, TriggerActionConfig& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
    *request.mutable_config() = config;

		SetConfigResponse response;

		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the action config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}	  
}