#ifndef __ACTION_SVC__H__
#define __ACTION_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>

#include "action.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::action::TriggerAction;
using gsdk::action::TriggerActionConfig;

namespace example {
	class ActionSvc {
	public:
		ActionSvc(std::shared_ptr<Channel> channel)
			: stub_(TriggerAction::NewStub(channel)) {}

		Status GetConfig(uint32_t deviceID, TriggerActionConfig* config);
		Status SetConfig(uint32_t deviceID, TriggerActionConfig& config);

	private:
		std::unique_ptr<TriggerAction::Stub> stub_;
	};
}

#endif
