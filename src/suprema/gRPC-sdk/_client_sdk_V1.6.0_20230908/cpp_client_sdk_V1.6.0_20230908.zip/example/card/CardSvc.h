#ifndef __CARD_SVC__H__
#define __CARD_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "card.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::card::Card;
using gsdk::card::CardData;
using gsdk::card::BlacklistItem;
using gsdk::card::CardConfig;
using gsdk::card::QRConfig;

using google::protobuf::RepeatedPtrField;

namespace example {
	class CardSvc {
	public:
		CardSvc(std::shared_ptr<Channel> channel)
			: stub_(Card::NewStub(channel)) {}

		Status Scan(uint32_t deviceID, CardData* cardData);

    Status GetBlacklist(uint32_t deviceID, RepeatedPtrField<BlacklistItem>* blacklist);
    Status AddBlacklist(uint32_t deviceID, RepeatedPtrField<BlacklistItem>* cardInfos);
    Status DeleteBlacklist(uint32_t deviceID, RepeatedPtrField<BlacklistItem>* cardInfos);
	
	Status GetConfig(uint32_t deviceID, CardConfig* config);
	Status SetConfig(uint32_t deviceID, CardConfig& config);
	
	Status GetQRConfig(uint32_t deviceID, QRConfig* config);
	Status SetQRConfig(uint32_t deviceID, QRConfig& config);

	private:
		std::unique_ptr<Card::Stub> stub_;
	};
}

#endif
