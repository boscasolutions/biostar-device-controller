#include "CardSvc.h"

using grpc::ClientContext;

using gsdk::card::ScanRequest;
using gsdk::card::ScanResponse;

using gsdk::card::GetBlacklistRequest;
using gsdk::card::GetBlacklistResponse;

using gsdk::card::AddBlacklistRequest;
using gsdk::card::AddBlacklistResponse;

using gsdk::card::DeleteBlacklistRequest;
using gsdk::card::DeleteBlacklistResponse;

using gsdk::card::GetConfigRequest;
using gsdk::card::GetConfigResponse;

using gsdk::card::SetConfigRequest;
using gsdk::card::SetConfigResponse;

using gsdk::card::GetQRConfigRequest;
using gsdk::card::GetQRConfigResponse;

using gsdk::card::SetQRConfigRequest;
using gsdk::card::SetQRConfigResponse;

namespace example {
	Status CardSvc::Scan(uint32_t deviceID, CardData* cardData) {
		ScanRequest request;
		request.set_deviceid(deviceID);

		ScanResponse response;

		ClientContext context;

		Status status = stub_->Scan(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot scan a card: " << status.error_message() << std::endl;
			return status;
		}

    *cardData = response.carddata();

		return status;
	}

  Status CardSvc::GetBlacklist(uint32_t deviceID, RepeatedPtrField<BlacklistItem>* blacklist) {
    GetBlacklistRequest request;
    request.set_deviceid(deviceID);

    GetBlacklistResponse response;

    ClientContext context;

    Status status = stub_->GetBlacklist(&context, request, &response);

    if (!status.ok()) {
      std::cerr << "Cannot get the blacklist: " << status.error_message() << std::endl;
      return status;
    }

    *blacklist = response.blacklist();

    return status;    
  }

  Status CardSvc::AddBlacklist(uint32_t deviceID, RepeatedPtrField<BlacklistItem>* cardInfos) {
    AddBlacklistRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_cardinfos() = *cardInfos;

    AddBlacklistResponse response;

    ClientContext context;

    Status status = stub_->AddBlacklist(&context, request, &response);

    if (!status.ok()) {
      std::cerr << "Cannot add the cards to the blacklist: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }

  Status CardSvc::DeleteBlacklist(uint32_t deviceID, RepeatedPtrField<BlacklistItem>* cardInfos) {
    DeleteBlacklistRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_cardinfos() = *cardInfos;

    DeleteBlacklistResponse response;

    ClientContext context;

    Status status = stub_->DeleteBlacklist(&context, request, &response);

    if (!status.ok()) {
      std::cerr << "Cannot delete the cards from the blacklist: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }

	Status CardSvc::GetConfig(uint32_t deviceID, CardConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the Card config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}

	Status CardSvc::SetConfig(uint32_t deviceID, CardConfig& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
    *request.mutable_config() = config;

		SetConfigResponse response;
		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the Card config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}

	Status CardSvc::GetQRConfig(uint32_t deviceID, QRConfig* config) {
		GetQRConfigRequest request;
		request.set_deviceid(deviceID);

		GetQRConfigResponse response;

		ClientContext context;

		Status status = stub_->GetQRConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the QR config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}

	Status CardSvc::SetQRConfig(uint32_t deviceID, QRConfig& config) {
		SetQRConfigRequest request;
		request.set_deviceid(deviceID);
    *request.mutable_config() = config;

		SetQRConfigResponse response;
		ClientContext context;

		Status status = stub_->SetQRConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the QR config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}
}