#include <iostream>
#include "StatusSvc.h"

using grpc::ClientContext;

using gsdk::status::GetConfigRequest;
using gsdk::status::GetConfigResponse;

using gsdk::status::SetConfigRequest;
using gsdk::status::SetConfigResponse;

namespace example {

	Status StatusSvc::GetConfig(uint32_t deviceID, StatusConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;
		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);
		if (!status.ok()) {
			std::cerr << "Cannot get the status config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}	

	Status StatusSvc::SetConfig(uint32_t deviceID, StatusConfig& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
    *request.mutable_config() = config;

		SetConfigResponse response;
		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the status config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}	  
}
