#include <string>
#include <string.h>
#include <stdint.h>
#include <iostream>
#include <grpcpp/grpcpp.h>
#include <stdlib.h>
#include "device.grpc.pb.h"
#include "GatewayClient.h"
#include "ConnectSvc.h"
#include "StatusSvc.h"
#include "DeviceSvc.h"

using grpc::Channel;
using grpc::Status;

using example::GatewayClient;
using example::ConnectSvc;
using example::StatusSvc;
using example::DeviceSvc;

const std::string GATEWAY_CA_FILE = "../cert/gateway/ca.crt";
const std::string GATEWAY_ADDR = "192.168.8.98";
const int GATEWAY_PORT = 4000;

const std::string DEVICE_IP = "192.168.8.200";
const int DEVICE_PORT = 51211;
const bool USE_SSL = false;

extern void testConfig(StatusSvc& statusSvc, uint32_t deviceID);

bool isHeadless(gsdk::device::Type devType);

int main(int argc, char** argv) {
  uint32_t deviceID = 0;

  auto gatewayClient = std::make_shared<GatewayClient>();
  if (!gatewayClient->Connect(GATEWAY_ADDR, GATEWAY_PORT, GATEWAY_CA_FILE)) {
    std::cerr << "Cannot connect to the gateway" << std::endl;
    exit(1);
  }

  ConnectSvc connectSvc(gatewayClient->GetChannel());

  ConnectInfo connInfo;
  connInfo.set_ipaddr(DEVICE_IP);
  connInfo.set_port(DEVICE_PORT);
  connInfo.set_usessl(USE_SSL);

  Status status = connectSvc.Connect(connInfo, &deviceID);
  if (!status.ok()) {
    std::cerr << "Cannot connect to the device " << deviceID << std::endl;
    exit(1);
  }  

  std::vector<uint32_t> deviceIDs;
  deviceIDs.push_back(deviceID);
  
  DeviceSvc deviceSvc(gatewayClient->GetChannel());
  DeviceCapability capability;
  status = deviceSvc.GetCapability(deviceID, &capability);
  if (!status.ok()) {
    std::cerr << "Cannot get the device capability " << deviceID << std::endl;
    connectSvc.Disconnect(deviceIDs);
    exit(1);
  } 

  if (capability.displaysupported()) {
    std::cerr << "Status configuration is effective only for headless devices: " << capability.displaysupported() << std::endl;
    connectSvc.Disconnect(deviceIDs);
    exit(1);
  }

  StatusSvc statusSvc(gatewayClient->GetChannel());
  testConfig(statusSvc, deviceID);

  connectSvc.Disconnect(deviceIDs);

  return 0;
}

bool isHeadless(gsdk::device::Type devType) {
  switch (devType) {
  case gsdk::device::Type::BIOENTRY_P2:
  case gsdk::device::Type::BIOENTRY_R2:
  case gsdk::device::Type::BIOENTRY_W2:
  case gsdk::device::Type::XPASS2:
  case gsdk::device::Type::XPASS2_KEYPAD:
  case gsdk::device::Type::XPASS_D2:
  case gsdk::device::Type::XPASS_D2_KEYPAD:
  case gsdk::device::Type::XPASS_S2:
    return true;
  
  default:
    return false;
  }
}