#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "StatusSvc.h"
#include "Menu.h"
#include "status.grpc.pb.h"
#include "action.grpc.pb.h"
#include "device.grpc.pb.h"

using example::StatusSvc;
using example::Menu;

using gsdk::status::StatusConfig;
using gsdk::status::DeviceStatus;
using gsdk::action::LEDSignal;
using gsdk::action::BuzzerSignal;
using gsdk::device::LEDColor;
using gsdk::device::BuzzerTone;

void testLED(StatusSvc& svc, uint32_t deviceID, StatusConfig& config);
void testBuzzer(StatusSvc& svc, uint32_t deviceID, StatusConfig& config);

void testConfig(StatusSvc& svc, uint32_t deviceID) {
  // Backup the original configuration
  StatusConfig origConfig;
  Status status = svc.GetConfig(deviceID, &origConfig);
  if (!status.ok()) {
	  return;
  }
  std::cout << std::endl << "Original Config: " << std::endl << origConfig.ShortDebugString() << std::endl << std::endl;

  StatusConfig testConfig;
  testConfig.CopyFrom(origConfig);

  testLED(svc, deviceID, testConfig);
  testBuzzer(svc, deviceID, testConfig);

  // Restore the original configuration
  svc.SetConfig(deviceID, origConfig);
}

void testLED(StatusSvc& svc, uint32_t deviceID, StatusConfig& config) {
  std::cout << std::endl << "===== LED Status Test =====" << std::endl << std::endl;

  // Change the LED color of the normal status to yellow
  for(int i = 0; i < config.ledstate().size(); i++) {
    if(config.ledstate()[i].devicestatus() == DeviceStatus::DEVICE_STATUS_NORMAL) {
      LEDSignal signal;
      signal.set_color(LEDColor::LED_COLOR_YELLOW);
      signal.set_duration(2000);
      signal.set_delay(0);

      auto ledStatus = config.mutable_ledstate(i);
      ledStatus->set_count(0);
      ledStatus->clear_signals();
      *ledStatus->add_signals() = signal;

      break;
    }
  }

  svc.SetConfig(deviceID, config);

  StatusConfig newConfig;
  svc.GetConfig(deviceID, &newConfig);
  std::cout << std::endl << "New Config: " << std::endl << newConfig.ShortDebugString() << std::endl << std::endl;

  std::cout << ">> The LED color of the normal status is changed to yellow." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");
}


void testBuzzer(StatusSvc& svc, uint32_t deviceID, StatusConfig& config) {
  std::cout << std::endl << "===== Buzzer Status Test =====" << std::endl << std::endl;

  // Change the buzzer signal for FAIL
  for(int i = 0; i < config.buzzerstate().size(); i++) {
    if(config.buzzerstate()[i].devicestatus() == DeviceStatus::DEVICE_STATUS_FAIL) {
      BuzzerSignal highBeep;
      highBeep.set_tone(BuzzerTone::BUZZER_TONE_HIGH);
      highBeep.set_duration(500);
      highBeep.set_delay(2);

      auto buzzerStatus = config.mutable_buzzerstate(i); // 2 x 500ms beeps
      buzzerStatus->set_count(1);
      buzzerStatus->clear_signals();
      *buzzerStatus->add_signals() = highBeep;
      *buzzerStatus->add_signals() = highBeep;

      break;
    }
  }

  svc.SetConfig(deviceID, config);

  StatusConfig newConfig;
  svc.GetConfig(deviceID, &newConfig);
  std::cout << std::endl << "New Config: " << std::endl << newConfig.ShortDebugString() << std::endl << std::endl;

  std::cout << ">> The buzzer for the FAIL status is changed to two 500ms beeps. Try to authenticate unregistered credentials for the test." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");
}
