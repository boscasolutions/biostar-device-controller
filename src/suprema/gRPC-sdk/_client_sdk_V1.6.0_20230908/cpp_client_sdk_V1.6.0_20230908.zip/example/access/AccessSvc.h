#ifndef __ACCESS_SVC__H__
#define __ACCESS_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "access.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::access::Access;
using gsdk::access::AccessGroup;
using gsdk::access::AccessLevel;

using google::protobuf::RepeatedPtrField;

namespace example {
  class AccessSvc {
  public:
    AccessSvc(std::shared_ptr<Channel> channel)
        : stub_(Access::NewStub(channel)) {}

    Status GetList(uint32_t deviceID, RepeatedPtrField<AccessGroup>* groups);
    Status Add(uint32_t deviceID, RepeatedPtrField<AccessGroup>& groups);
    Status DeleteAll(uint32_t deviceID);

    Status GetLevelList(uint32_t deviceID, RepeatedPtrField<AccessLevel>* levels);
    Status AddLevel(uint32_t deviceID, RepeatedPtrField<AccessLevel>& levels);
    Status DeleteAllLevel(uint32_t deviceID);

  private:
    std::unique_ptr<Access::Stub> stub_;
  };
}

#endif