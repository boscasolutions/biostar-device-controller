#include <iostream>
#include "AccessSvc.h"

using grpc::ClientContext;

using gsdk::access::GetListRequest;
using gsdk::access::GetListResponse;
using gsdk::access::AddRequest;
using gsdk::access::AddResponse;
using gsdk::access::DeleteAllRequest;
using gsdk::access::DeleteAllResponse;

using gsdk::access::GetLevelListRequest;
using gsdk::access::GetLevelListResponse;
using gsdk::access::AddLevelRequest;
using gsdk::access::AddLevelResponse;
using gsdk::access::DeleteAllLevelRequest;
using gsdk::access::DeleteAllLevelResponse;

namespace example {
  Status AccessSvc::GetList(uint32_t deviceID, RepeatedPtrField<AccessGroup>* groups) {
    GetListRequest request;
    request.set_deviceid(deviceID);

    GetListResponse response;
    ClientContext context;

    Status status = stub_->GetList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the access groups: " << status.error_message() << std::endl;
      return status;
    }

    *groups = response.groups();

    return status;
  }

  Status AccessSvc::Add(uint32_t deviceID, RepeatedPtrField<AccessGroup>& groups) {
    AddRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_groups() = groups;

    AddResponse response;
    ClientContext context;

    Status status = stub_->Add(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot add access groups: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status AccessSvc::DeleteAll(uint32_t deviceID) {
    DeleteAllRequest request;
    request.set_deviceid(deviceID);
		
    DeleteAllResponse response;
    ClientContext context;

    Status status = stub_->DeleteAll(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete all access groups: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }

  Status AccessSvc::GetLevelList(uint32_t deviceID, RepeatedPtrField<AccessLevel>* levels) {
    GetLevelListRequest request;
    request.set_deviceid(deviceID);

    GetLevelListResponse response;
    ClientContext context;

    Status status = stub_->GetLevelList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the access levels: " << status.error_message() << std::endl;
      return status;
    }

    *levels = response.levels();

    return status;
  }

  Status AccessSvc::AddLevel(uint32_t deviceID, RepeatedPtrField<AccessLevel>& levels) {
    AddLevelRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_levels() = levels;

    AddLevelResponse response;
    ClientContext context;

    Status status = stub_->AddLevel(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot add access levels: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status AccessSvc::DeleteAllLevel(uint32_t deviceID) {
    DeleteAllLevelRequest request;
    request.set_deviceid(deviceID);
		
    DeleteAllLevelResponse response;
    ClientContext context;

    Status status = stub_->DeleteAllLevel(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete all access levels: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }  
} 