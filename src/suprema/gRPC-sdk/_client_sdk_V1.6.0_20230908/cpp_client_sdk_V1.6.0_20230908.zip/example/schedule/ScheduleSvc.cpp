#include <iostream>
#include "ScheduleSvc.h"

using grpc::ClientContext;

using gsdk::schedule::GetListRequest;
using gsdk::schedule::GetListResponse;
using gsdk::schedule::AddRequest;
using gsdk::schedule::AddResponse;
using gsdk::schedule::DeleteAllRequest;
using gsdk::schedule::DeleteAllResponse;

using gsdk::schedule::GetHolidayListRequest;
using gsdk::schedule::GetHolidayListResponse;
using gsdk::schedule::AddHolidayRequest;
using gsdk::schedule::AddHolidayResponse;
using gsdk::schedule::DeleteAllHolidayRequest;
using gsdk::schedule::DeleteAllHolidayResponse;

namespace example {
  Status ScheduleSvc::GetList(uint32_t deviceID, RepeatedPtrField<ScheduleInfo>* schedules) {
    GetListRequest request;
    request.set_deviceid(deviceID);

    GetListResponse response;
    ClientContext context;

    Status status = stub_->GetList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the schedule list: " << status.error_message() << std::endl;
      return status;
    }

    *schedules = response.schedules();

    return status;
  }

  Status ScheduleSvc::Add(uint32_t deviceID, RepeatedPtrField<ScheduleInfo>& schedules) {
    AddRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_schedules() = schedules;

    AddResponse response;
    ClientContext context;

    Status status = stub_->Add(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot add schedules: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ScheduleSvc::DeleteAll(uint32_t deviceID) {
    DeleteAllRequest request;
    request.set_deviceid(deviceID);
		
    DeleteAllResponse response;
    ClientContext context;

    Status status = stub_->DeleteAll(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete all schedules: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }

  Status ScheduleSvc::GetHolidayList(uint32_t deviceID, RepeatedPtrField<HolidayGroup>* groups) {
    GetHolidayListRequest request;
    request.set_deviceid(deviceID);

    GetHolidayListResponse response;
    ClientContext context;

    Status status = stub_->GetHolidayList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the holiday list: " << status.error_message() << std::endl;
      return status;
    }

    *groups = response.groups();

    return status;
  }

  Status ScheduleSvc::AddHoliday(uint32_t deviceID, RepeatedPtrField<HolidayGroup>& groups) {
    AddHolidayRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_groups() = groups;

    AddHolidayResponse response;
    ClientContext context;

    Status status = stub_->AddHoliday(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot add holiday groups: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ScheduleSvc::DeleteAllHoliday(uint32_t deviceID) {
    DeleteAllHolidayRequest request;
    request.set_deviceid(deviceID);
		
    DeleteAllHolidayResponse response;
    ClientContext context;

    Status status = stub_->DeleteAllHoliday(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete all holiday groups: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }  
} 