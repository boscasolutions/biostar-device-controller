#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <fstream>
#include "ScheduleSvc.h"
#include "Menu.h"
#include "schedule.grpc.pb.h"

using example::ScheduleSvc;
using example::Menu;

using gsdk::schedule::HolidaySchedule;
using gsdk::schedule::Holiday;
using gsdk::schedule::HolidayRecurrence;
using gsdk::schedule::DaySchedule;
using gsdk::schedule::HolidaySchedule;
using gsdk::schedule::TimePeriod;
using gsdk::schedule::WeeklySchedule;
using gsdk::schedule::DailySchedule;

const int SAMPLE_HOLIDAY_GROUP_ID = 1;
const int WEEKLY_SCHEDULE_ID = 2; // 0 and 1 are reserved
const int DAILY_SCHEDULE_ID = WEEKLY_SCHEDULE_ID + 1; 
const int NUM_OF_DAY = 30;

void makeHolidayGroup(ScheduleSvc& svc, uint32_t deviceID);
void makeWeeklySchedule(ScheduleSvc& svc, uint32_t deviceID);
void makeDailySchedule(ScheduleSvc& svc, uint32_t deviceID);

void testSample(ScheduleSvc& svc, uint32_t deviceID) {
  // Backup the schedules
  RepeatedPtrField<ScheduleInfo> origSchedules;
  Status status = svc.GetList(deviceID, &origSchedules);
  if (!status.ok()) {
	  return;
  }

  RepeatedPtrField<HolidayGroup> origGroups;
  status = svc.GetHolidayList(deviceID, &origGroups);
  if (!status.ok()) {
	  return;
  }

  Menu::PrintList<ScheduleInfo>("Original Schedules:", origSchedules);
  Menu::PrintList<HolidayGroup>("Original Holiday Groups:", origGroups);

  // Test sample schedules
  std::cout << std::endl << "===== Test Sample Schedules =====" << std::endl << std::endl;

  svc.DeleteAll(deviceID);
  svc.DeleteAllHoliday(deviceID);

  makeHolidayGroup(svc, deviceID);
  makeWeeklySchedule(svc, deviceID);
  makeDailySchedule(svc, deviceID);

  RepeatedPtrField<ScheduleInfo> newSchedules;
  svc.GetList(deviceID, &newSchedules);

  RepeatedPtrField<HolidayGroup> newGroups;
  status = svc.GetHolidayList(deviceID, &newGroups);

  Menu::PrintList<ScheduleInfo>(">>> Sample Schedules:", newSchedules);
  Menu::PrintList<HolidayGroup>(">>> Sample Holiday Groups:", newGroups);  

  // Restore the schedules
  svc.DeleteAll(deviceID);
  svc.DeleteAllHoliday(deviceID);

  svc.Add(deviceID, origSchedules);
  svc.AddHoliday(deviceID, origGroups);
}

void makeHolidayGroup(ScheduleSvc& svc, uint32_t deviceID){
  Holiday jan1st;
  jan1st.set_date(0);
  jan1st.set_recurrence(HolidayRecurrence::RECUR_YEARLY);

  Holiday dec25th;
  dec25th.set_date(358); // in non leap year, 359 in leap year
  dec25th.set_recurrence(HolidayRecurrence::RECUR_YEARLY);

  HolidayGroup holidayGroup;
  holidayGroup.set_id(SAMPLE_HOLIDAY_GROUP_ID);
  holidayGroup.set_name("Sample Holiday Group");
  *holidayGroup.add_holidays() = jan1st;
  *holidayGroup.add_holidays() = dec25th;

  RepeatedPtrField<HolidayGroup> holidayGroups;
  holidayGroups.Add(std::forward<HolidayGroup>(holidayGroup));

  svc.AddHoliday(deviceID, holidayGroups);
}


void makeWeeklySchedule(ScheduleSvc& svc, uint32_t deviceID) {
  TimePeriod weekday1stPeriod; // 9 am ~ 12 pm
  weekday1stPeriod.set_starttime(540);
  weekday1stPeriod.set_endtime(720);

  TimePeriod weekday2ndPeriod; // 1 pm ~ 6 pm
  weekday2ndPeriod.set_starttime(780);
  weekday2ndPeriod.set_endtime(1080);

  DaySchedule weekdaySchedule;
  *weekdaySchedule.add_periods() = weekday1stPeriod;
  *weekdaySchedule.add_periods() = weekday2ndPeriod;

  TimePeriod weekendPeriod; // 9:30 am ~ 12:30 pm
  weekendPeriod.set_starttime(570);
  weekendPeriod.set_endtime(770); 

  DaySchedule weekendSchedule;
  *weekendSchedule.add_periods() = weekendPeriod;

  WeeklySchedule weeklySchedule;
  *weeklySchedule.add_dayschedules() = weekendSchedule; // Sunday
  *weeklySchedule.add_dayschedules() = weekdaySchedule; // Monday
  *weeklySchedule.add_dayschedules() = weekdaySchedule; // Tuesday
  *weeklySchedule.add_dayschedules() = weekdaySchedule; // Wednesday
  *weeklySchedule.add_dayschedules() = weekdaySchedule; // Thursday
  *weeklySchedule.add_dayschedules() = weekdaySchedule; // Friday
  *weeklySchedule.add_dayschedules() = weekendSchedule; // Saturday

  TimePeriod holidayPeriod; // 10 am ~ 12 pm
  holidayPeriod.set_starttime(600);
  holidayPeriod.set_endtime(720); 

  DaySchedule holidayDaySchedule;
  *holidayDaySchedule.add_periods() = holidayPeriod;

  HolidaySchedule holidaySchedule;
  holidaySchedule.set_groupid(SAMPLE_HOLIDAY_GROUP_ID);
  *holidaySchedule.mutable_dayschedule() = holidayDaySchedule;

  ScheduleInfo schedule;
  schedule.set_id(WEEKLY_SCHEDULE_ID);
  schedule.set_name("Sample Weekly Schedule");
  *schedule.mutable_weekly() = weeklySchedule;
  *schedule.add_holidays() = holidaySchedule;

  RepeatedPtrField<ScheduleInfo> schedules;
  schedules.Add(std::forward<ScheduleInfo>(schedule));

  svc.Add(deviceID, schedules);    
}


void makeDailySchedule(ScheduleSvc& svc, uint32_t deviceID) {
  TimePeriod firstPeriod; // 9 am ~ 12 pm
  firstPeriod.set_starttime(540);
  firstPeriod.set_endtime(720);

  TimePeriod secondPeriod; // 1 pm ~ 6 pm
  secondPeriod.set_starttime(780);
  secondPeriod.set_endtime(1080);

  DaySchedule daySchedule;
  *daySchedule.add_periods() = firstPeriod;
  *daySchedule.add_periods() = secondPeriod;

  time_t curTime = time(NULL);
  DailySchedule dailySchedule;
  dailySchedule.set_startdate(localtime(&curTime)->tm_yday); // 30 days starting from today
  for(int i = 0; i < NUM_OF_DAY; i++) {
    *dailySchedule.add_dayschedules() = daySchedule;
  }

  ScheduleInfo schedule;
  schedule.set_id(DAILY_SCHEDULE_ID);
  schedule.set_name("Sample Daily Schedule");
  *schedule.mutable_daily() = dailySchedule;

  RepeatedPtrField<ScheduleInfo> schedules;
  schedules.Add(std::forward<ScheduleInfo>(schedule));

  svc.Add(deviceID, schedules); 
}