#ifndef __SCHEDULE_SVC__H__
#define __SCHEDULE_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "schedule.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::schedule::Schedule;
using gsdk::schedule::ScheduleInfo;
using gsdk::schedule::HolidayGroup;

using google::protobuf::RepeatedPtrField;

namespace example {
  class ScheduleSvc {
  public:
    ScheduleSvc(std::shared_ptr<Channel> channel)
        : stub_(Schedule::NewStub(channel)) {}

    Status GetList(uint32_t deviceID, RepeatedPtrField<ScheduleInfo>* schedules);
    Status Add(uint32_t deviceID, RepeatedPtrField<ScheduleInfo>& schedules);
    Status DeleteAll(uint32_t deviceID);

    Status GetHolidayList(uint32_t deviceID, RepeatedPtrField<HolidayGroup>* groups);
    Status AddHoliday(uint32_t deviceID, RepeatedPtrField<HolidayGroup>& groups);
    Status DeleteAllHoliday(uint32_t deviceID);

  private:
    std::unique_ptr<Schedule::Stub> stub_;
  };
}

#endif