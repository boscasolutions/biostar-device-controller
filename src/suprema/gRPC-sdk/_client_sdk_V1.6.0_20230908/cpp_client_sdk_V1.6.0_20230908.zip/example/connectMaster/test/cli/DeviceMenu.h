#ifndef __DEVICE_MENU_H__
#define __DEVICE_MENU_H__

#include "ConnectMasterSvc.h"
#include "Menu.h"

namespace example {
  class DeviceMenu {
  public:
		DeviceMenu();
    ~DeviceMenu() {}

		std::shared_ptr<ConnectMasterSvc> GetConnectMasterSvc() { return connectMasterSvc_; }
    std::string GetGatewayID() { return gatewayID_; }

    void SetConnectMasterSvc(std::shared_ptr<ConnectMasterSvc> svc, std::string gatewayID);

    void Show();

    int GetDeviceList();
    
    static void SetConnectionMode(void* arg);
    static void EnableSSL(void* arg);
    static void DisableSSL(void* arg);
    static void Disconnect(void* arg);
    static void DisconnectAll(void* arg);
    static void RefreshDeviceList(void* arg);

  private:
    std::unique_ptr<Menu> menu_;
		std::shared_ptr<ConnectMasterSvc> connectMasterSvc_;

    std::string gatewayID_;
  };
}

#endif