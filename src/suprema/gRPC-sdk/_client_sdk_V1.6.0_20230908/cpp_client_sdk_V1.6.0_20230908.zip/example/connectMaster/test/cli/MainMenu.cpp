#include <iostream>
#include <string>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>
#include "MainMenu.h"
#include "Util.h"

using grpc::Status;
using google::protobuf::RepeatedPtrField;

namespace example {
  const int SEARCH_TIMEOUT = 5000;

  MainMenu::MainMenu() {
    std::vector<std::shared_ptr<MenuItem>> menuItems;

    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"1", "Search devices", SearchDevice, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"2", "Connect to a device synchronously", Connect, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"3", "Manage asynchronous connections", ShowAsyncMenu, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"4", "Accept devices", ShowAcceptMenu, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"5", "Device menu", ShowDeviceMenu, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"q", "Quit", NULL, NULL, true}));

    menu_  = std::make_unique<Menu>(menuItems);

    deviceMenu_ = std::make_shared<DeviceMenu>();
    asyncMenu_ = std::make_shared<AsyncMenu>();
    acceptMenu_ = std::make_shared<AcceptMenu>();
  } 

  void MainMenu::SetConnectMasterSvc(std::shared_ptr<ConnectMasterSvc> svc, std::string gatewayID) {
    connectMasterSvc_ = svc;
    gatewayID_ = gatewayID;

    deviceMenu_->SetConnectMasterSvc(svc, gatewayID);
    asyncMenu_->SetConnectMasterSvc(svc, gatewayID);
    acceptMenu_->SetConnectMasterSvc(svc, gatewayID);
  }

  void MainMenu::Show() {
    menu_->Show("Main Menu");
  }

  void MainMenu::SearchDevice(void* arg) {
		MainMenu* menu = static_cast<MainMenu*>(arg);

    std::cout << "Searching devices in the subnet..." << std::endl;

    RepeatedPtrField<SearchDeviceInfo> deviceInfos;
    Status status = menu->GetConnectMasterSvc()->SearchDevice(menu->GetGatewayID(), SEARCH_TIMEOUT, &deviceInfos);

    if(!status.ok()) {
      std::cerr << "Cannot search devices" << std::endl;
      return;
    }

    std::cout << std::endl << "***** Found Devices: " << deviceInfos.size() << std::endl;
    for(int i = 0; i < deviceInfos.size(); i++) {
      std::cout << deviceInfos[i].ShortDebugString() << std::endl;
    } 
  } 

  void MainMenu::Connect(void* arg) {
		MainMenu* menu = static_cast<MainMenu*>(arg);

    std::shared_ptr<ConnectInfo> connInfo = Util::GetConnectInfo();

    if(!connInfo) {
      return;
    }

    std::cout << "Connecting to the device..." << std::endl;

    uint32_t deviceID;
    Status status = menu->GetConnectMasterSvc()->Connect(menu->GetGatewayID(), *connInfo, &deviceID);

    if(!status.ok()) {
      std::cerr << "Cannot connect to the device" << std::endl;
      return;
    }

    std::cout << "Connected to " << deviceID << std::endl;
  }   

  void MainMenu::ShowDeviceMenu(void* arg) {
		MainMenu* menu = static_cast<MainMenu*>(arg);
    menu->GetDeviceMenu()->Show();
  }  

  void MainMenu::ShowAsyncMenu(void* arg) {
		MainMenu* menu = static_cast<MainMenu*>(arg);
    menu->GetAsyncMenu()->Show();
  }     

  void MainMenu::ShowAcceptMenu(void* arg) {
		MainMenu* menu = static_cast<MainMenu*>(arg);
    menu->GetAcceptMenu()->Show();
  }     

}
