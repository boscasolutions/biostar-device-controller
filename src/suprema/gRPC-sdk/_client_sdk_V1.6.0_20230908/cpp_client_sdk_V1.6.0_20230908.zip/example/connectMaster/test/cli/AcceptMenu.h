#ifndef __ACCEPT_MENU_H__
#define __ACCEPT_MENU_H__

#include "ConnectMasterSvc.h"
#include "Menu.h"

namespace example {
  class AcceptMenu {
  public:
		AcceptMenu();
    ~AcceptMenu() {}

		std::shared_ptr<ConnectMasterSvc> GetConnectMasterSvc() { return connectMasterSvc_; }
    std::string GetGatewayID() { return gatewayID_; }

    void SetConnectMasterSvc(std::shared_ptr<ConnectMasterSvc> svc, std::string gatewayID);

    void Show();

    static void RefreshPendingList(void* arg);
    static void ShowAcceptFilter(void* arg);
    static void AllowAll(void* arg);
    static void DisallowAll(void* arg);
    static void AddDeviceToFilter(void* arg);
    static void DeleteDeviceFromFilter(void* arg);

  private:
    std::unique_ptr<Menu> menu_;
		std::shared_ptr<ConnectMasterSvc> connectMasterSvc_;

    std::string gatewayID_;
  };
}

#endif