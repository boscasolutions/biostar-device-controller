#include "Util.h"

namespace example {
  std::shared_ptr<ConnectInfo> Util::GetConnectInfo() {
    std::vector<std::shared_ptr<InputItem>> inputItems;
  
    inputItems.push_back(std::make_shared<InputItem>(InputItem{"Enter the IP address of the device", ""}));
    inputItems.push_back(std::make_shared<InputItem>(InputItem{"Enter the port of the device (default: 51211)", "51211"}));
    inputItems.push_back(std::make_shared<InputItem>(InputItem{"Use SSL y/n (default: n)", "n"}));

    std::vector<std::string> values;
    Menu::GetUserInput(inputItems, values);
    
    try {
      int port = std::stoi(values[1]);

      std::shared_ptr<ConnectInfo> connInfo = std::make_shared<ConnectInfo>();
      connInfo->set_ipaddr(values[0]);
      connInfo->set_port(port);
      connInfo->set_usessl(values[2] == "y");

      return connInfo;

    } catch (std::invalid_argument const &e) {
      std::cerr << "Invalid port: " << values[1] << std::endl;
      return NULL;
    }    
  } 
}
