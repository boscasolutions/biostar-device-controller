#ifndef __ASYNC_MENU_H__
#define __ASYNC_MENU_H__

#include "ConnectMasterSvc.h"
#include "Menu.h"

namespace example {
  class AsyncMenu {
  public:
		AsyncMenu();
    ~AsyncMenu() {}

		std::shared_ptr<ConnectMasterSvc> GetConnectMasterSvc() { return connectMasterSvc_; }
    std::string GetGatewayID() { return gatewayID_; }

    void SetConnectMasterSvc(std::shared_ptr<ConnectMasterSvc> svc, std::string gatewayID);

    void Show();

    static void AddAsyncConnection(void* arg);
    static void DeleteAsyncConnection(void* arg);
    static void RefreshAsyncList(void* arg);

  private:
    std::unique_ptr<Menu> menu_;
		std::shared_ptr<ConnectMasterSvc> connectMasterSvc_;

    std::string gatewayID_;
  };
}

#endif