#ifndef __CLI_UTIL_H__
#define __CLI_UTIL_H__

#include "connect.grpc.pb.h"
#include "Menu.h"

using gsdk::connect::ConnectInfo;

namespace example {
  class Util {
  public:
		Util() {}
    ~Util() {}

    static std::shared_ptr<ConnectInfo> GetConnectInfo();
  };
}

#endif