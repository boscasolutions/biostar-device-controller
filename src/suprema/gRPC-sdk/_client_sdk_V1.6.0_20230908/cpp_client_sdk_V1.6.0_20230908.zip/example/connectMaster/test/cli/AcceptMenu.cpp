#include <iostream>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>
#include "AcceptMenu.h"
#include "Util.h"

using grpc::Status;
using google::protobuf::RepeatedPtrField;
using google::protobuf::RepeatedField;

namespace example {
  AcceptMenu::AcceptMenu() {
    std::vector<std::shared_ptr<MenuItem>> menuItems;

    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"1", "Add devices to the filter", AddDeviceToFilter, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"2", "Delete devices from the filter", DeleteDeviceFromFilter, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"3", "Allow all devices", AllowAll, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"4", "Disallow all devices", DisallowAll, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"5", "Refresh the pending device list", RefreshPendingList, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"q", "Return to Main Menu", NULL, NULL, true}));

    menu_  = std::make_unique<Menu>(menuItems);
  } 

  void AcceptMenu::SetConnectMasterSvc(std::shared_ptr<ConnectMasterSvc> svc, std::string gatewayID) {
    connectMasterSvc_ = svc;
    gatewayID_ = gatewayID;
  }

  void AcceptMenu::Show() {
    ShowAcceptFilter(this);
    RefreshPendingList(this);

    menu_->Show("Accept Menu");
  }
  
  void AcceptMenu::RefreshPendingList(void* arg) {
    AcceptMenu* menu = static_cast<AcceptMenu*>(arg);

    std::cout << std::endl << "Getting the pending list..." << std::endl;

    RepeatedPtrField<PendingDeviceInfo> deviceInfos;
    Status status = menu->GetConnectMasterSvc()->GetPendingList(menu->GetGatewayID(), &deviceInfos);

    if(!status.ok()) {
      return;
    }

    std::cout << "***** Pending Devices: " << deviceInfos.size() << std::endl;

    for(int i = 0; i < deviceInfos.size(); i++) {
      std::cout << deviceInfos[i].ShortDebugString() << std::endl;
    }
  }

  void AcceptMenu::ShowAcceptFilter(void* arg) {
    AcceptMenu* menu = static_cast<AcceptMenu*>(arg);

    std::cout << std::endl << "Getting the accept filter..." << std::endl;

    AcceptFilter filter;
    Status status = menu->GetConnectMasterSvc()->GetAcceptFilter(menu->GetGatewayID(), &filter);

    if(!status.ok()) {
      return;
    }

    std::cout << "***** Accept Filter: " << filter.ShortDebugString() << std::endl;
  }  

  void AcceptMenu::AllowAll(void* arg) {
    AcceptMenu* menu = static_cast<AcceptMenu*>(arg);

    AcceptFilter filter;
    filter.set_allowall(true);

    Status status = menu->GetConnectMasterSvc()->SetAcceptFilter(menu->GetGatewayID(), filter);

    if(!status.ok()) {
      return;
    }

    ShowAcceptFilter(arg);
  }    

  void AcceptMenu::DisallowAll(void* arg) {
    AcceptMenu* menu = static_cast<AcceptMenu*>(arg);

    AcceptFilter filter;
    filter.set_allowall(false);

    Status status = menu->GetConnectMasterSvc()->SetAcceptFilter(menu->GetGatewayID(), filter);

    if(!status.ok()) {
      return;
    }

    ShowAcceptFilter(arg);
  } 

  void AcceptMenu::AddDeviceToFilter(void* arg) {
    AcceptMenu* menu = static_cast<AcceptMenu*>(arg);

    std::cout << "Enter the device IDs to add" << std::endl;

    std::vector<uint32_t> deviceIDs;
    Menu::GetDeviceID(deviceIDs);

    if(deviceIDs.size() == 0) {
      std::cout << "No device to add" << std::endl;
      return;
    }

    AcceptFilter filter;
    Status status = menu->GetConnectMasterSvc()->GetAcceptFilter(menu->GetGatewayID(), &filter);

    if(!status.ok()) {
      return;
    }

    filter.set_allowall(false);

    for(int i = 0; i < deviceIDs.size(); i++) {
      bool exist = false;

      for(int j = 0; j < filter.deviceids_size(); j++) {
        if(deviceIDs[i] == filter.deviceids(j)) {
          exist = true;
          break;
        }
      }

      if(!exist) {
        filter.add_deviceids(deviceIDs[i]);
      }
    }

    status = menu->GetConnectMasterSvc()->SetAcceptFilter(menu->GetGatewayID(), filter);

    if(!status.ok()) {
      return;
    }

    ShowAcceptFilter(arg);
  }

  void AcceptMenu::DeleteDeviceFromFilter(void* arg) {
    AcceptMenu* menu = static_cast<AcceptMenu*>(arg);

    std::cout << "Enter the device IDs to delete" << std::endl;

    std::vector<uint32_t> deviceIDs;
    Menu::GetDeviceID(deviceIDs);

    if(deviceIDs.size() == 0) {
      std::cout << "No device to delete" << std::endl;
      return;
    }

    AcceptFilter filter;
    Status status = menu->GetConnectMasterSvc()->GetAcceptFilter(menu->GetGatewayID(), &filter);

    if(!status.ok()) {
      return;
    }

    filter.set_allowall(false);

    RepeatedField<uint32_t> newDeviceIDs;

    for(int i = 0; i < filter.deviceids_size(); i++) {
      bool shouldDelete = false;

      for(int j = 0; j < deviceIDs.size(); j++) {
        if(filter.deviceids(i) == deviceIDs[j]) {
          shouldDelete = true;
          break;
        }
      }

      if(!shouldDelete) {
        newDeviceIDs.Add(filter.deviceids(i));
      }
    }

    *filter.mutable_deviceids() = newDeviceIDs;

    status = menu->GetConnectMasterSvc()->SetAcceptFilter(menu->GetGatewayID(), filter);

    if(!status.ok()) {
      return;
    }

    ShowAcceptFilter(arg);
  }

}
