#include <iostream>
#include <thread>
#include <sstream>

#include "MainMenu.h"
#include "MasterClient.h"
#include "ConnectMasterSvc.h"
#include "TenantSvc.h"

using grpc::ClientReader;
using grpc::ClientContext;

using gsdk::connect::StatusChange;

using example::MainMenu;
using example::MasterClient;
using example::ConnectMasterSvc;
using example::TenantSvc;

const std::string MASTER_CA_FILE = "../cert/master/ca.crt";
const std::string MASTER_ADDR = "192.168.0.2";
const int MASTER_PORT = 4010;
const std::string TENANT_CERT_FILE = "../cert/master/tenant1.crt";
const std::string TENANT_KEY_FILE = "../cert/master/tenant1_key.pem";
const std::string ADMIN_CERT_FILE = "../cert/master/admin.crt";
const std::string ADMIN_KEY_FILE = "../cert/master/admin_key.pem";

const std::string TENANT_ID = "tenant1";
const std::string GATEWAY_ID = "gateway1";  

const int STATUS_QUEUE_SIZE = 16;

void subscribeStatus(std::unique_ptr<ClientReader<StatusChange>> statusReader) {
  StatusChange devStatus;

  while(statusReader->Read(&devStatus)) {
    if(devStatus.status() != gsdk::connect::Status::TCP_NOT_ALLOWED && devStatus.status() != gsdk::connect::Status::TLS_NOT_ALLOWED) {
      std::stringstream s;

      s << std::endl << "[STATUS] " << devStatus.ShortDebugString() << std::endl << std::endl;

      std::cout << s.str() << std::flush;
    }
  }  

  std::cout << "Subscribing thread is stopped" << std::endl;

  statusReader->Finish();
}

void initTenant() {
  auto masterClient = std::make_shared<MasterClient>();
  if(!masterClient->ConnectAdmin(MASTER_ADDR, MASTER_PORT, MASTER_CA_FILE, ADMIN_CERT_FILE, ADMIN_KEY_FILE)) {
    std::cerr << "Cannot connect to the master gateway" << std::endl;
    exit(1);
  }

  auto tenantSvc = std::make_shared<TenantSvc>(masterClient->GetChannel());

  std::vector<std::string> tenantIDs;
  tenantIDs.push_back(TENANT_ID);  
	RepeatedPtrField<TenantInfo> tenantInfos;
  auto status = tenantSvc->Get(tenantIDs, &tenantInfos);

  if(status.ok()) {
    std::cerr << TENANT_ID << " is already registered" << std::endl;
  } else {
    std::cerr << TENANT_ID << " is not registered. Trying to add the tenant..." << std::endl;

    RepeatedPtrField<TenantInfo> newTenantInfos;
    TenantInfo tenantInfo;
    tenantInfo.set_tenantid(TENANT_ID);
    tenantInfo.add_gatewayids(GATEWAY_ID);
		newTenantInfos.Add(std::forward<TenantInfo>(tenantInfo));

    status = tenantSvc->Add(newTenantInfos);

    if(status.ok()) {
      std::cerr << TENANT_ID << " is registered successfully" << std::endl;
    } else {
      std::cerr << "Cannot add the tenant: " << status.error_message() << std::endl;
    }
  }
}

int main(int argc, char** argv) {
  for(int i = 1; i < argc; i++) {
    if(strcmp(argv[i], "-i") == 0) {
      initTenant();
      return 0;
    }
  }

  MasterClient client;
  if(!client.ConnectTenant(MASTER_ADDR, MASTER_PORT, MASTER_CA_FILE, TENANT_CERT_FILE, TENANT_KEY_FILE)) {
    std::cerr << "Cannot connect to the master gateway" << std::endl;
    exit(1);
  }

	auto connectMasterSvc = std::make_shared<ConnectMasterSvc>(client.GetChannel());

  ClientContext context;
  auto statusReader(connectMasterSvc->Subscribe(&context, STATUS_QUEUE_SIZE));
  std::thread subThread(subscribeStatus, std::move(statusReader));
  
	MainMenu mainMenu;
  mainMenu.SetConnectMasterSvc(connectMasterSvc, GATEWAY_ID);
  mainMenu.Show();

  context.TryCancel();
  subThread.join();

  return 0;
}

