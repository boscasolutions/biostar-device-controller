#ifndef __MAIN_MENU_H__
#define __MAIN_MENU_H__

#include "ConnectMasterSvc.h"
#include "Menu.h"
#include "DeviceMenu.h"
#include "AsyncMenu.h"
#include "AcceptMenu.h"

namespace example {
  class MainMenu {
  public:
		MainMenu();
    ~MainMenu() {}

		std::shared_ptr<ConnectMasterSvc> GetConnectMasterSvc() { return connectMasterSvc_; }
    std::string GetGatewayID() { return gatewayID_; }
    
    void SetConnectMasterSvc(std::shared_ptr<ConnectMasterSvc> svc, std::string gatewayID);

    std::shared_ptr<DeviceMenu> GetDeviceMenu() { return deviceMenu_; }
    std::shared_ptr<AsyncMenu> GetAsyncMenu() { return asyncMenu_; }
    std::shared_ptr<AcceptMenu> GetAcceptMenu() { return acceptMenu_; }

    void Show();
    
    static void SearchDevice(void* arg);
    static void ShowDeviceMenu(void* arg);
    static void ShowAsyncMenu(void* arg);
    static void ShowAcceptMenu(void* arg);
    static void Connect(void* arg);

  private:
    std::unique_ptr<Menu> menu_;
		std::shared_ptr<ConnectMasterSvc> connectMasterSvc_;
    std::string gatewayID_;

    std::shared_ptr<DeviceMenu> deviceMenu_;
    std::shared_ptr<AsyncMenu> asyncMenu_;
    std::shared_ptr<AcceptMenu> acceptMenu_;
  };
}

#endif