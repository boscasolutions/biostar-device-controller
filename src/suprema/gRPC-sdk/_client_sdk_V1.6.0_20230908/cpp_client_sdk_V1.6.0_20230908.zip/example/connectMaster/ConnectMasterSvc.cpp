#include <iostream>
#include "ConnectMasterSvc.h"

using grpc::ClientContext;

using gsdk::connect_master::GetDeviceListRequest;
using gsdk::connect_master::GetDeviceListResponse;

using gsdk::connect_master::SearchDeviceRequest;
using gsdk::connect_master::SearchDeviceResponse;

using gsdk::connect_master::ConnectRequest;
using gsdk::connect_master::ConnectResponse;

using gsdk::connect_master::DisconnectRequest;
using gsdk::connect_master::DisconnectResponse;

using gsdk::connect_master::DisconnectAllRequest;
using gsdk::connect_master::DisconnectAllResponse;

using gsdk::connect_master::SetConnectionModeMultiRequest;
using gsdk::connect_master::SetConnectionModeMultiResponse;

using gsdk::connect_master::EnableSSLMultiRequest;
using gsdk::connect_master::EnableSSLMultiResponse;

using gsdk::connect_master::DisableSSLMultiRequest;
using gsdk::connect_master::DisableSSLMultiResponse;

using gsdk::connect_master::AddAsyncConnectionRequest;
using gsdk::connect_master::AddAsyncConnectionResponse;

using gsdk::connect_master::DeleteAsyncConnectionRequest;
using gsdk::connect_master::DeleteAsyncConnectionResponse;

using gsdk::connect_master::GetAcceptFilterRequest;
using gsdk::connect_master::GetAcceptFilterResponse;

using gsdk::connect_master::SetAcceptFilterRequest;
using gsdk::connect_master::SetAcceptFilterResponse;

using gsdk::connect_master::GetPendingListRequest;
using gsdk::connect_master::GetPendingListResponse;


using gsdk::connect_master::SubscribeStatusRequest;

namespace example {
  Status ConnectMasterSvc::GetDeviceList(std::string gatewayID, RepeatedPtrField<DeviceInfo>* deviceInfos) {
    GetDeviceListRequest request;
    request.set_gatewayid(gatewayID);

    GetDeviceListResponse response;

    ClientContext context;

    Status status = stub_->GetDeviceList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get device list: " << status.error_message() << std::endl;
      return status;
    }

    *deviceInfos = response.deviceinfos();

    return status;
  }

  Status ConnectMasterSvc::SearchDevice(std::string gatewayID, int searchTimeout, RepeatedPtrField<SearchDeviceInfo>* deviceInfos) {
    SearchDeviceRequest request;
    request.set_gatewayid(gatewayID);
    request.set_timeout(searchTimeout);

    SearchDeviceResponse response;

    ClientContext context;

    Status status = stub_->SearchDevice(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot search devices: " << status.error_message() << std::endl;
      return status;
    }

    *deviceInfos = response.deviceinfos();

    return status;
  }


  Status ConnectMasterSvc::Connect(std::string gatewayID, ConnectInfo& connInfo, uint32_t* deviceID) {
    ConnectRequest request;
    request.set_gatewayid(gatewayID);
    *request.mutable_connectinfo() = connInfo;

    ConnectResponse response;

    ClientContext context;

    Status status = stub_->Connect(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot connect to the device: " << status.error_message() << std::endl;
      return status;
    }

    *deviceID = response.deviceid();

    return status;
  }

  Status ConnectMasterSvc::Disconnect(std::vector<uint32_t>& deviceIDs) {
    DisconnectRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }

    DisconnectResponse response;

    ClientContext context;

    Status status = stub_->Disconnect(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot disconnect the device: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectMasterSvc::DisconnectAll(std::string gatewayID) {
    DisconnectAllRequest request;
    request.set_gatewayid(gatewayID);
    DisconnectAllResponse response;

    ClientContext context;

    Status status = stub_->DisconnectAll(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot disconnect all devices: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }  

  Status ConnectMasterSvc::SetConnectionMode(std::vector<uint32_t>& deviceIDs, ConnectionMode mode) {
    SetConnectionModeMultiRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }
    request.set_connectionmode(mode);

    SetConnectionModeMultiResponse response;

    ClientContext context;

    Status status = stub_->SetConnectionModeMulti(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot set connection mode: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectMasterSvc::EnableSSL(std::vector<uint32_t>& deviceIDs) {
    EnableSSLMultiRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }

    EnableSSLMultiResponse response;

    ClientContext context;

    Status status = stub_->EnableSSLMulti(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot enable SSL: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectMasterSvc::DisableSSL(std::vector<uint32_t>& deviceIDs) {
    DisableSSLMultiRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }

    DisableSSLMultiResponse response;

    ClientContext context;

    Status status = stub_->DisableSSLMulti(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot disable SSL: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectMasterSvc::AddAsyncConnection(std::string gatewayID, RepeatedPtrField<AsyncConnectInfo>& asyncInfos) {
    AddAsyncConnectionRequest request;
    request.set_gatewayid(gatewayID);
    *request.mutable_connectinfos() = asyncInfos;

    AddAsyncConnectionResponse response;

    ClientContext context;

    Status status = stub_->AddAsyncConnection(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot add async connections: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectMasterSvc::DeleteAsyncConnection(std::string gatewayID, std::vector<uint32_t>& deviceIDs) {
    DeleteAsyncConnectionRequest request;
    request.set_gatewayid(gatewayID);
     for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }

    DeleteAsyncConnectionResponse response;

    ClientContext context;

    Status status = stub_->DeleteAsyncConnection(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete async connections: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectMasterSvc::GetPendingList(std::string gatewayID, RepeatedPtrField<PendingDeviceInfo>* deviceInfos) {
    GetPendingListRequest request;
    request.set_gatewayid(gatewayID);
    GetPendingListResponse response;

    ClientContext context;

    Status status = stub_->GetPendingList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the pending list: " << status.error_message() << std::endl;
      return status;
    }

    *deviceInfos = response.deviceinfos();

    return status;
  }  

  Status ConnectMasterSvc::GetAcceptFilter(std::string gatewayID, AcceptFilter* filter) {
    GetAcceptFilterRequest request;
    request.set_gatewayid(gatewayID);
    GetAcceptFilterResponse response;

    ClientContext context;

    Status status = stub_->GetAcceptFilter(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the accept filter: " << status.error_message() << std::endl;
      return status;
    }

    *filter = response.filter();

    return status;    
  }

  Status ConnectMasterSvc::SetAcceptFilter(std::string gatewayID, AcceptFilter& filter) {
    SetAcceptFilterRequest request;
    request.set_gatewayid(gatewayID);
    *request.mutable_filter() = filter;

    SetAcceptFilterResponse response;

    ClientContext context;

    Status status = stub_->SetAcceptFilter(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot set the accept filter: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }  

  std::unique_ptr<ClientReader<StatusChange>> ConnectMasterSvc::Subscribe(ClientContext* context, int queueSize) {
    SubscribeStatusRequest request;
    request.set_queuesize(queueSize);

    return stub_->SubscribeStatus(context, request);
  }  
} 