#ifndef __CONNECT_MASTER_SVC__H__
#define __CONNECT_MASTER_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "connect.grpc.pb.h"
#include "connect_master.grpc.pb.h"

using grpc::Channel;
using grpc::Status;
using grpc::ClientReader;
using grpc::ClientContext;

using gsdk::connect::DeviceInfo;
using gsdk::connect::ConnectInfo;
using gsdk::connect::SearchDeviceInfo;
using gsdk::connect::AsyncConnectInfo;
using gsdk::connect::StatusChange;
using gsdk::connect::PendingDeviceInfo;
using gsdk::connect::AcceptFilter;
using gsdk::connect::ConnectionMode;

using gsdk::connect_master::ConnectMaster;

using google::protobuf::RepeatedPtrField;

namespace example {
  class ConnectMasterSvc {
  public:
    ConnectMasterSvc(std::shared_ptr<Channel> channel)
        : stub_(ConnectMaster::NewStub(channel)) {}

    Status GetDeviceList(std::string gatewayID, RepeatedPtrField<DeviceInfo>* deviceInfos);

    Status SearchDevice(std::string gatewayID, int searchTimeout, RepeatedPtrField<SearchDeviceInfo>* deviceInfos);

    Status Connect(std::string gatewayID, ConnectInfo& connInfo, uint32_t* deviceID);

    Status Disconnect(std::vector<uint32_t>& deviceIDs);
    Status DisconnectAll(std::string gatewayID);

    Status SetConnectionMode(std::vector<uint32_t>& deviceIDs, ConnectionMode mode);
    Status EnableSSL(std::vector<uint32_t>& deviceIDs);
    Status DisableSSL(std::vector<uint32_t>& deviceIDs);

    Status AddAsyncConnection(std::string gatewayID, RepeatedPtrField<AsyncConnectInfo>& asyncInfos);
    Status DeleteAsyncConnection(std::string gatewayID, std::vector<uint32_t>& deviceIDs);

    Status GetPendingList(std::string gatewayID, RepeatedPtrField<PendingDeviceInfo>* deviceInfos);
    Status GetAcceptFilter(std::string gatewayID, AcceptFilter* filter);
    Status SetAcceptFilter(std::string gatewayID, AcceptFilter& filter);

    std::unique_ptr<ClientReader<StatusChange>> Subscribe(ClientContext* context, int queueSize);
  private:
    std::unique_ptr<ConnectMaster::Stub> stub_;
  };
}

#endif