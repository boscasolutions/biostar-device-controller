#ifndef __EVENT_SVC__H__
#define __EVENT_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>
#include <nlohmann/json.hpp>

#include "event.grpc.pb.h"

using grpc::Channel;
using grpc::Status;
using grpc::ClientReader;
using grpc::ClientContext;

using gsdk::event::Event;
using gsdk::event::EventLog;
using gsdk::event::EventFilter;
using gsdk::event::ImageLog;

using google::protobuf::RepeatedPtrField;

using json = nlohmann::json;

namespace example {
  class EventSvc {
  public:
    EventSvc(std::shared_ptr<Channel> channel)
        : stub_(Event::NewStub(channel)) {}

    Status GetLog(uint32_t deviceID, int startEventID, int maxNumOfLog, RepeatedPtrField<EventLog>* events);
    Status GetLogWithFilter(uint32_t deviceID, int startEventID, int maxNumOfLog, EventFilter& filter, RepeatedPtrField<EventLog>* events);
    Status GetImageLog(uint32_t deviceID, int startEventID, int maxNumOfLog, RepeatedPtrField<ImageLog>* events);

    Status EnableMonitoring(uint32_t deviceID);
    Status DisableMonitoring(uint32_t deviceID);
    
    std::unique_ptr<ClientReader<EventLog>> Subscribe(ClientContext* context, int queueSize);

    void InitCodeMap(std::string filename);
    std::string GetEventString(uint32_t eventCode, uint32_t subCode);

  private:
    std::unique_ptr<Event::Stub> stub_;
    json codeMap_;
  };
}

#endif
