#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <thread>
#include "EventSvc.h"
#include "Menu.h"

using grpc::ClientContext;
using example::EventSvc;
using gsdk::event::EventFilter;
using example::Menu;

std::shared_ptr<ClientContext> s_Context;
std::thread s_MonitoringThread;
const int EVENT_QUEUE_SIZE = 16;
const int MAX_NUM_EVENT = 32;

int s_FirstEventID = 0;

void handleEvent(std::unique_ptr<ClientReader<EventLog>> eventReader);
void printEvent(EventSvc& svc, EventLog& event);

void startMonitoring(EventSvc& svc, uint32_t deviceID) {
  Status status = svc.EnableMonitoring(deviceID);

  if (!status.ok()) {
	  return;
  }

	s_Context = std::make_shared<ClientContext>();
	auto eventReader(svc.Subscribe(s_Context.get(), EVENT_QUEUE_SIZE));

	s_MonitoringThread = std::thread(handleEvent, std::move(eventReader));
}


void stopMonitoring(EventSvc& svc, uint32_t deviceID) {
  s_Context->TryCancel();
	s_MonitoringThread.join();
  svc.DisableMonitoring(deviceID);  
}


void handleEvent(std::unique_ptr<ClientReader<EventLog>> eventReader) {
	EventLog realtimeEvent;

	while (eventReader->Read(&realtimeEvent)) {
		if (s_FirstEventID == 0) {
			s_FirstEventID = realtimeEvent.id();
		}

		std::cout << "[EVENT] " << realtimeEvent.ShortDebugString() << std::endl;
	}

	std::cout << "Monitoring thread is stopped" << std::endl;

	eventReader->Finish();
}

void testEvent(EventSvc& svc, uint32_t deviceID) {
  std::cout << std::endl << "===== Event Test =====" << std::endl << std::endl;
  Menu::PressEnter(">> Try to authenticate credentials to check real-time monitoring. And, press ENTER to read the generated event logs.\n");

  if(s_FirstEventID == 0) {
    std::cout << std::endl << ">> There is no new event. Just read " <<  MAX_NUM_EVENT << " event logs from the start." << std::endl;
  } else {
    std::cout << std::endl << ">> Read new events starting from " << s_FirstEventID << std::endl;
  }

  RepeatedPtrField<EventLog> events;
  Status status = svc.GetLog(deviceID, s_FirstEventID, MAX_NUM_EVENT, &events);
  if (!status.ok()) {
	  return;
  }

  for(int i = 0; i < events.size(); i++) {
    printEvent(svc, events[i]);
  }

  if(events.size() > 0 && s_FirstEventID != 0) {
    EventFilter filter;
    filter.set_eventcode(events[0].eventcode());

    std::cout << std::endl << ">> Filter with event code " << events[0].eventcode() << std::endl;

    status = svc.GetLogWithFilter(deviceID, s_FirstEventID, MAX_NUM_EVENT, filter, &events);
    if (!status.ok()) {
      return;
    }

    for(int i = 0; i < events.size(); i++) {
      printEvent(svc, events[i]);
    }
  }
}


void printEvent(EventSvc& svc, EventLog& event) {
	time_t eventTime = (time_t)event.timestamp();
  std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Device " << event.deviceid() << ", User " << event.userid() << ", " << svc.GetEventString(event.eventcode(), event.subcode()) << std::endl;
}

