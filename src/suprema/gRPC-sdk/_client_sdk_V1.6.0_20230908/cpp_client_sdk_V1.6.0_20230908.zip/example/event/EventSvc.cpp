#include <iostream>
#include <fstream>
#include "EventSvc.h"

using gsdk::event::GetLogRequest;
using gsdk::event::GetLogResponse;

using gsdk::event::GetLogWithFilterRequest;
using gsdk::event::GetLogWithFilterResponse;

using gsdk::event::GetImageLogRequest;
using gsdk::event::GetImageLogResponse;

using gsdk::event::EnableMonitoringRequest;
using gsdk::event::EnableMonitoringResponse;

using gsdk::event::DisableMonitoringRequest;
using gsdk::event::DisableMonitoringResponse;

using gsdk::event::SubscribeRealtimeLogRequest;

namespace example {
  Status EventSvc::GetLog(uint32_t deviceID, int startEventID, int maxNumOfLog, RepeatedPtrField<EventLog>* events) {
    GetLogRequest request;
    request.set_deviceid(deviceID);
    request.set_starteventid(startEventID);
    request.set_maxnumoflog(maxNumOfLog);

    GetLogResponse response;

    ClientContext context;

    Status status = stub_->GetLog(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get log events: " << status.error_message() << std::endl;
      return status;
    }

    *events = response.events();

    return status;
  }

  Status EventSvc::GetLogWithFilter(uint32_t deviceID, int startEventID, int maxNumOfLog, EventFilter& filter, RepeatedPtrField<EventLog>* events) {
    GetLogWithFilterRequest request;
    request.set_deviceid(deviceID);
    request.set_starteventid(startEventID);
    request.set_maxnumoflog(maxNumOfLog);
    *request.add_filters() = filter;

    GetLogWithFilterResponse response;

    ClientContext context;

    Status status = stub_->GetLogWithFilter(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get log events: " << status.error_message() << std::endl;
      return status;
    }

    *events = response.events();

    return status;
  }  

  Status EventSvc::GetImageLog(uint32_t deviceID, int startEventID, int maxNumOfLog, RepeatedPtrField<ImageLog>* events) {
    GetImageLogRequest request;
    request.set_deviceid(deviceID);
    request.set_starteventid(startEventID);
    request.set_maxnumoflog(maxNumOfLog);

    GetImageLogResponse response;

    ClientContext context;

    Status status = stub_->GetImageLog(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get image logs: " << status.error_message() << std::endl;
      return status;
    }

    *events = response.imageevents();

    return status;
  }

  Status EventSvc::EnableMonitoring(uint32_t deviceID) {
    EnableMonitoringRequest request;
    request.set_deviceid(deviceID);

    EnableMonitoringResponse response;

    ClientContext context;

    Status status = stub_->EnableMonitoring(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot enable monitoring: " << status.error_message() << std::endl;
    }

    return status;
  }

  Status EventSvc::DisableMonitoring(uint32_t deviceID) {
    DisableMonitoringRequest request;
    request.set_deviceid(deviceID);

    DisableMonitoringResponse response;

    ClientContext context;

    Status status = stub_->DisableMonitoring(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot disable monitoring: " << status.error_message() << std::endl;
    }

    return status;
  }

  std::unique_ptr<ClientReader<EventLog>> EventSvc::Subscribe(ClientContext* context, int queueSize) {
    SubscribeRealtimeLogRequest request;
    request.set_queuesize(queueSize);

    return stub_->SubscribeRealtimeLog(context, request);
  }

  void EventSvc::InitCodeMap(std::string filename) {
    std::ifstream mapFile(filename);
    mapFile >> codeMap_;
  }

  std::string EventSvc::GetEventString(uint32_t eventCode, uint32_t subCode) {
    char buf[256];

    if(codeMap_.empty()) {
      sprintf(buf, "No code map(%#x)", eventCode | subCode);
      return buf;
    }

    for(int i = 0; i < codeMap_["entries"].size(); i++) {
      if(eventCode == codeMap_["entries"].at(i)["event_code"] && subCode == codeMap_["entries"].at(i)["sub_code"]) {
        return codeMap_["entries"].at(i)["desc"];
      }
    }

    sprintf(buf, "Unknown code(%#x)", eventCode | subCode);
    return buf;
  }
} 