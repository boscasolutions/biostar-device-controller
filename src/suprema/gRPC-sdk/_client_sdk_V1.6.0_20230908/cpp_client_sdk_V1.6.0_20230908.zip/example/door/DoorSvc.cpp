#include <iostream>
#include "DoorSvc.h"

using grpc::ClientContext;

using gsdk::door::GetListRequest;
using gsdk::door::GetListResponse;
using gsdk::door::GetStatusRequest;
using gsdk::door::GetStatusResponse;
using gsdk::door::AddRequest;
using gsdk::door::AddResponse;
using gsdk::door::DeleteAllRequest;
using gsdk::door::DeleteAllResponse;
using gsdk::door::LockRequest;
using gsdk::door::LockResponse;
using gsdk::door::UnlockRequest;
using gsdk::door::UnlockResponse;
using gsdk::door::ReleaseRequest;
using gsdk::door::ReleaseResponse;

namespace example {
  Status DoorSvc::GetList(uint32_t deviceID, RepeatedPtrField<DoorInfo>* doors) {
    GetListRequest request;
    request.set_deviceid(deviceID);

    GetListResponse response;
    ClientContext context;

    Status status = stub_->GetList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the doors: " << status.error_message() << std::endl;
      return status;
    }

    *doors = response.doors();

    return status;
  }

  Status DoorSvc::GetStatus(uint32_t deviceID, RepeatedPtrField<gsdk::door::Status>* doorStatus) {
    GetStatusRequest request;
    request.set_deviceid(deviceID);

    GetStatusResponse response;
    ClientContext context;

    Status status = stub_->GetStatus(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the door status: " << status.error_message() << std::endl;
      return status;
    }

    *doorStatus = response.status();

    return status;
  }


  Status DoorSvc::Add(uint32_t deviceID, RepeatedPtrField<DoorInfo>& doors) {
    AddRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_doors() = doors;

    AddResponse response;
    ClientContext context;

    Status status = stub_->Add(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot add doors: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status DoorSvc::DeleteAll(uint32_t deviceID) {
    DeleteAllRequest request;
    request.set_deviceid(deviceID);
		
    DeleteAllResponse response;
    ClientContext context;

    Status status = stub_->DeleteAll(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete all doors: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }

  Status DoorSvc::Lock(uint32_t deviceID, std::vector<uint32_t>& doorIDs, DoorFlag doorFlag) {
    LockRequest request;
    request.set_deviceid(deviceID);
    request.set_doorflag(doorFlag);
    for(int i = 0; i < doorIDs.size(); i++) {
      request.add_doorids(doorIDs[i]);
    }    
		
    LockResponse response;
    ClientContext context;

    Status status = stub_->Lock(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot lock the doors: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }

  Status DoorSvc::Unlock(uint32_t deviceID, std::vector<uint32_t>& doorIDs, DoorFlag doorFlag) {
    UnlockRequest request;
    request.set_deviceid(deviceID);
    request.set_doorflag(doorFlag);
    for(int i = 0; i < doorIDs.size(); i++) {
      request.add_doorids(doorIDs[i]);
    }    
		
    UnlockResponse response;
    ClientContext context;

    Status status = stub_->Unlock(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot unlock the doors: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }

  Status DoorSvc::Release(uint32_t deviceID, std::vector<uint32_t>& doorIDs, DoorFlag doorFlag) {
    ReleaseRequest request;
    request.set_deviceid(deviceID);
    request.set_doorflag(doorFlag);
    for(int i = 0; i < doorIDs.size(); i++) {
      request.add_doorids(doorIDs[i]);
    }    
		
    ReleaseResponse response;
    ClientContext context;

    Status status = stub_->Release(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot release the door flags: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }
} 