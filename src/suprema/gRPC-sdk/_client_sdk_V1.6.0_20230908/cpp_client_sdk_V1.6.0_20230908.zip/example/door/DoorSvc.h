#ifndef __DOOR_SVC__H__
#define __DOOR_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "door.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::door::Door;
using gsdk::door::DoorInfo;
using gsdk::door::DoorFlag;

using google::protobuf::RepeatedPtrField;

namespace example {
  class DoorSvc {
  public:
    DoorSvc(std::shared_ptr<Channel> channel)
        : stub_(Door::NewStub(channel)) {}

    Status GetList(uint32_t deviceID, RepeatedPtrField<DoorInfo>* doors);
    Status GetStatus(uint32_t deviceID, RepeatedPtrField<gsdk::door::Status>* status);
    Status Add(uint32_t deviceID, RepeatedPtrField<DoorInfo>& doors);
    Status DeleteAll(uint32_t deviceID);
    Status Lock(uint32_t deviceID, std::vector<uint32_t>& doorIDs, DoorFlag doorFlag);
    Status Unlock(uint32_t deviceID, std::vector<uint32_t>& doorIDs, DoorFlag doorFlag);
    Status Release(uint32_t deviceID, std::vector<uint32_t>& doorIDs, DoorFlag doorFlag);

  private:
    std::unique_ptr<Door::Stub> stub_;
  };
}

#endif