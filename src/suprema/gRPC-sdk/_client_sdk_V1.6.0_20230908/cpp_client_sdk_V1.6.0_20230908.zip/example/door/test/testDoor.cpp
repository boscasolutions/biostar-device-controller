#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <fstream>
#include "DoorSvc.h"
#include "AccessSvc.h"
#include "UserSvc.h"
#include "EventSvc.h"
#include "Menu.h"
#include "door.grpc.pb.h"
#include "device.grpc.pb.h"
#include "access.grpc.pb.h"

using example::DoorSvc;
using example::AccessSvc;
using example::UserSvc;
using example::EventSvc;
using example::Menu;

using gsdk::door::Relay;
using gsdk::door::Sensor;
using gsdk::door::ExitButton;
using gsdk::device::SwitchType;
using gsdk::access::DoorSchedule;

const int TEST_DOOR_ID = 1;
const int RELAY_PORT = 0; // 1st relay
const int SENSOR_PORT = 0; // 1st input port
const int EXIT_BUTTON_PORT = 1; // 2nd input port
const int AUTO_LOCK_TIMEOUT = 3; // locked after 3 seconds
const int HELD_OPEN_TIMEOUT = 10; // held open alarm after 10 seconds

const int TEST_ACCESS_LEVEL_ID = 1;
const int TEST_ACCESS_GROUP_ID = 1;
const int ALWAYS_SCHEDULE_ID = 1; // ID 1 is reserved for 'always'

void makeDoor(DoorSvc& doorSvc, uint32_t deviceID);
std::string getUserID(EventSvc& svc, uint32_t deviceID);
void testAccessGroup(DoorSvc& doorSvc, EventSvc& eventSvc, AccessSvc& accessSvc, UserSvc& userSvc, uint32_t deviceID);
void testLock(DoorSvc& doorSvc, uint32_t deviceID);

void testDoor(DoorSvc& doorSvc, EventSvc& eventSvc, AccessSvc& accessSvc, UserSvc& userSvc, uint32_t deviceID) {
  // Backup the doors
  RepeatedPtrField<DoorInfo> origDoors;
  Status status = doorSvc.GetList(deviceID, &origDoors);
  if (!status.ok()) {
	  return;
  }

  Menu::PrintList<DoorInfo>("Original Doors:", origDoors);

  makeDoor(doorSvc, deviceID);
  testAccessGroup(doorSvc, eventSvc, accessSvc, userSvc, deviceID);

  // Restore the doors
  doorSvc.DeleteAll(deviceID);
  if(origDoors.size() > 0) {
    doorSvc.Add(deviceID, origDoors);
  }
}

void makeDoor(DoorSvc& doorSvc, uint32_t deviceID) {
  doorSvc.DeleteAll(deviceID);

  Relay relay;
  relay.set_deviceid(deviceID);
  relay.set_port(RELAY_PORT);

  Sensor sensor;
  sensor.set_deviceid(deviceID);
  sensor.set_port(SENSOR_PORT);
  sensor.set_type(SwitchType::NORMALLY_OPEN);

  ExitButton button;
  button.set_deviceid(deviceID);
  button.set_port(EXIT_BUTTON_PORT);
  button.set_type(SwitchType::NORMALLY_OPEN);

  DoorInfo doorInfo;
  doorInfo.set_doorid(TEST_DOOR_ID);
  doorInfo.set_name("Test Door");
  doorInfo.set_entrydeviceid(deviceID);
  *doorInfo.mutable_relay() = relay;
  *doorInfo.mutable_sensor() = sensor;
  *doorInfo.mutable_button() = button;
  doorInfo.set_autolocktimeout(AUTO_LOCK_TIMEOUT);
  doorInfo.set_heldopentimeout(HELD_OPEN_TIMEOUT);

  RepeatedPtrField<DoorInfo> doorInfos;
  doorInfos.Add(std::forward<DoorInfo>(doorInfo));

  doorSvc.Add(deviceID, doorInfos);

  std::cout << std::endl << "===== Door Test =====" << std::endl << std::endl;

  RepeatedPtrField<DoorInfo> newDoors;
  doorSvc.GetList(deviceID, &newDoors);

  Menu::PrintList<DoorInfo>("Test Doors:", newDoors);

  std::cout << ">> Try to authenticate a registered credential. It should fail since you can access a door only with a proper access group." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");
}

void testAccessGroup(DoorSvc& doorSvc, EventSvc& eventSvc, AccessSvc& accessSvc, UserSvc& userSvc, uint32_t deviceID) {
  auto userID = getUserID(eventSvc, deviceID);

  if(userID == "") {
    std::cout << "!! Cannot find ACCESS_DENIED event. You should have tried to authenticate a registered credentail for the test." << std::endl;
    return;
  }

  std::vector<std::string> userIDs;
  userIDs.push_back(userID);

  // Backup access groups
  RepeatedPtrField<AccessGroup> origGroups;
  RepeatedPtrField<AccessLevel> origLevels;
  RepeatedPtrField<UserAccessGroup> origUserAccessGroups;

  accessSvc.GetList(deviceID, &origGroups);
  accessSvc.GetLevelList(deviceID, &origLevels);
  userSvc.GetAccessGroup(deviceID, userIDs, &origUserAccessGroups);

  Menu::PrintList<AccessGroup>("Original Access Groups:", origGroups);
  Menu::PrintList<AccessLevel>("Original Access Levels:", origLevels);
  Menu::PrintList<UserAccessGroup>("Original User Access Groups:", origUserAccessGroups);

  accessSvc.DeleteAll(deviceID);
  accessSvc.DeleteAllLevel(deviceID);  

  // Make an access group and assign it to the user
  DoorSchedule doorSchedule; // can access the test door all the time
  doorSchedule.set_doorid(TEST_DOOR_ID);
  doorSchedule.set_scheduleid(ALWAYS_SCHEDULE_ID);

  AccessLevel accessLevel;
  accessLevel.set_id(TEST_ACCESS_LEVEL_ID);
  *accessLevel.add_doorschedules() = doorSchedule;

  RepeatedPtrField<AccessLevel> accessLevels;
  accessLevels.Add(std::forward<AccessLevel>(accessLevel));

  accessSvc.AddLevel(deviceID, accessLevels);

  AccessGroup accessGroup;
  accessGroup.set_id(TEST_ACCESS_GROUP_ID);
  accessGroup.add_levelids(TEST_ACCESS_LEVEL_ID);

  RepeatedPtrField<AccessGroup> accessGroups;
  accessGroups.Add(std::forward<AccessGroup>(accessGroup));

  accessSvc.Add(deviceID, accessGroups);

  UserAccessGroup userAccessGroup;
  userAccessGroup.set_userid(userID);
  userAccessGroup.add_accessgroupids(TEST_ACCESS_GROUP_ID);

  RepeatedPtrField<UserAccessGroup> userAccessGroups;
  userAccessGroups.Add(std::forward<UserAccessGroup>(userAccessGroup));

  userSvc.SetAccessGroup(deviceID, userAccessGroups);

  RepeatedPtrField<AccessGroup> newGroups;
  RepeatedPtrField<AccessLevel> newLevels;
  RepeatedPtrField<UserAccessGroup> newUserAccessGroups;

  accessSvc.GetList(deviceID, &newGroups);
  accessSvc.GetLevelList(deviceID, &newLevels);
  userSvc.GetAccessGroup(deviceID, userIDs, &newUserAccessGroups);

  Menu::PrintList<AccessGroup>("Test Access Groups:", newGroups);
  Menu::PrintList<AccessLevel>("Test Access Levels:", newLevels);
  Menu::PrintList<UserAccessGroup>("Test User Access Groups:", newUserAccessGroups);

  std::cout << ">> Try to authenticate the same registered credential. It should succeed since the access group is added." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");

  testLock(doorSvc, deviceID);

  // Restore access groups
  userSvc.SetAccessGroup(deviceID, origUserAccessGroups);
  accessSvc.DeleteAll(deviceID);
  if(origGroups.size() > 0) {
    accessSvc.Add(deviceID, origGroups);
  }
  accessSvc.DeleteAllLevel(deviceID);
  if(origLevels.size() > 0) {
    accessSvc.AddLevel(deviceID, origLevels);
  }
}

void testLock(DoorSvc& doorSvc, uint32_t deviceID) {
  Menu::PressEnter(">> Press ENTER to unlock the door.\n");

  std::vector<uint32_t> doorIDs;
  doorIDs.push_back(TEST_DOOR_ID);

  doorSvc.Unlock(deviceID, doorIDs, DoorFlag::OPERATOR);
  RepeatedPtrField<gsdk::door::Status> doorStatus;
  doorSvc.GetStatus(deviceID, &doorStatus);
  Menu::PrintList<gsdk::door::Status>("Status after unlocking the door:", doorStatus);

  Menu::PressEnter(">> Press ENTER to lock the door.\n");

  doorSvc.Lock(deviceID, doorIDs, DoorFlag::OPERATOR);
  doorSvc.GetStatus(deviceID, &doorStatus);
  Menu::PrintList<gsdk::door::Status>("Status after locking the door:", doorStatus);

  std::cout << ">> Try to authenticate the same registered credential. The relay should not work since the door is locked by the operator with the higher priority." << std::endl;
  Menu::PressEnter(">> Press ENTER to release the door flag.\n");  

  doorSvc.Release(deviceID, doorIDs, DoorFlag::OPERATOR);
  doorSvc.GetStatus(deviceID, &doorStatus);
  Menu::PrintList<gsdk::door::Status>("Status after releasing the door flag:", doorStatus);

  std::cout << ">> Try to authenticate the same registered credential. The relay should work since the door flag is cleared." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");  
}
