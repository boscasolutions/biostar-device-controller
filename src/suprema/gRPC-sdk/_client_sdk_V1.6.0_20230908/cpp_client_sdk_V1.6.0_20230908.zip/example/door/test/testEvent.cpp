#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <thread>
#include "EventSvc.h"

using grpc::ClientContext;
using example::EventSvc;

std::shared_ptr<ClientContext> s_Context;
std::thread s_MonitoringThread;

const int EVENT_QUEUE_SIZE = 16;
const int FIRST_DOOR_EVENT = 0x5000; // BS2_EVENT_DOOR_UNLOCKED
const int LAST_DOOR_EVENT = 0x5E00; // BS2_EVENT_DOOR_UNLOCK
const int MAX_NUM_OF_LOG = 16;

int s_FirstEventID = 0;

void handleEvent(EventSvc& svc, std::unique_ptr<ClientReader<EventLog>> eventReader);
void printEvent(EventSvc& svc, EventLog& event);

void startMonitoring(EventSvc& svc, uint32_t deviceID) {
  Status status = svc.EnableMonitoring(deviceID);

  if (!status.ok()) {
	  return;
  }

	s_Context = std::make_shared<ClientContext>();
	auto eventReader(svc.Subscribe(s_Context.get(), EVENT_QUEUE_SIZE));

	s_MonitoringThread = std::thread(handleEvent, std::ref(svc), std::move(eventReader));
}


void stopMonitoring(EventSvc& svc, uint32_t deviceID) {
  s_Context->TryCancel();
	s_MonitoringThread.join();
  svc.DisableMonitoring(deviceID);  
}


void handleEvent(EventSvc& svc, std::unique_ptr<ClientReader<EventLog>> eventReader) {
	EventLog realtimeEvent;

	while (eventReader->Read(&realtimeEvent)) {
		if (s_FirstEventID == 0) {
			s_FirstEventID = realtimeEvent.id();
		}

		printEvent(svc, realtimeEvent);
	}

	std::cout << "Monitoring thread is stopped" << std::endl;

	eventReader->Finish();
}


void printEvent(EventSvc& svc, EventLog& event) {
	time_t eventTime = (time_t)event.timestamp();

  if(event.eventcode() >= FIRST_DOOR_EVENT && event.eventcode() <= LAST_DOOR_EVENT) {
    std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Door " << event.entityid() << ", " << svc.GetEventString(event.eventcode(), event.subcode()) << std::endl;
  } else {
    std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Device " << event.deviceid() << ", User " << event.userid() << ", " << svc.GetEventString(event.eventcode(), event.subcode()) << std::endl;
  }
}

std::string getUserID(EventSvc& svc, uint32_t deviceID) {
  RepeatedPtrField<EventLog> events;
  Status status = svc.GetLog(deviceID, s_FirstEventID, MAX_NUM_OF_LOG, &events);
  if (!status.ok()) {
	  return "";
  }

  for(int i = 0; i < events.size(); i++) {
    if(events[i].eventcode() == 0x1900) { // BS2_EVENT_ACCESS_DENIED
      return events[i].userid();
    }
  }

  return "";
}


