#ifndef __DISPLAY_SVC__H__
#define __DISPLAY_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>

#include "display.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::display::Display;
using gsdk::display::DisplayConfig;

namespace example {
	class DisplaySvc {
	public:
		DisplaySvc(std::shared_ptr<Channel> channel)
			: stub_(Display::NewStub(channel)) {}

		Status GetConfig(uint32_t deviceID, DisplayConfig* config);

	private:
		std::unique_ptr<Display::Stub> stub_;
	};
}

#endif
