#include <iostream>
#include "DisplaySvc.h"

using grpc::ClientContext;

using gsdk::display::GetConfigRequest;
using gsdk::display::GetConfigResponse;


namespace example {
	Status DisplaySvc::GetConfig(uint32_t deviceID, DisplayConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the display config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config();

		return status;
	}
}