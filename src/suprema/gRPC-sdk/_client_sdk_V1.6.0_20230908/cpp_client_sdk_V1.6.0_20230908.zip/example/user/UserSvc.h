#ifndef __USER_SVC__H__
#define __USER_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "user.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::user::User;
using gsdk::user::UserHdr;
using gsdk::user::UserInfo;
using gsdk::user::UserFinger;
using gsdk::user::UserCard;
using gsdk::user::UserFace;
using gsdk::user::UserAccessGroup;

using google::protobuf::RepeatedPtrField;

namespace example {
  class UserSvc {
  public:
    UserSvc(std::shared_ptr<Channel> channel)
        : stub_(User::NewStub(channel)) {}

    Status GetList(uint32_t deviceID, RepeatedPtrField<UserHdr>* userList);
    Status GetUser(uint32_t deviceID, std::vector<std::string>& userIDs, RepeatedPtrField<UserInfo>* userInfos);
    Status Enroll(uint32_t deviceID, RepeatedPtrField<UserInfo>& userInfos);
    Status EnrollMulti(std::vector<uint32_t> deviceIDs, RepeatedPtrField<UserInfo>& userInfos);
    Status Update(uint32_t deviceID, RepeatedPtrField<UserInfo>& userInfos);
    Status UpdateMulti(std::vector<uint32_t> deviceIDs, RepeatedPtrField<UserInfo>& userInfos);
    Status SetFinger(uint32_t deviceID, RepeatedPtrField<UserFinger>& userFingers);
    Status SetCard(uint32_t deviceID, RepeatedPtrField<UserCard>& userCards);
    Status SetFace(uint32_t deviceID, RepeatedPtrField<UserFace>& userFaces);
    Status SetAccessGroup(uint32_t deviceID, RepeatedPtrField<UserAccessGroup>& userAccessGroups);
    Status GetAccessGroup(uint32_t deviceID, std::vector<std::string>& userIDs, RepeatedPtrField<UserAccessGroup>* userAccessGroups);
    Status Delete(uint32_t deviceID, std::vector<std::string>& userIDs);
    Status DeleteMulti(std::vector<uint32_t> deviceIDs, std::vector<std::string>& userIDs);

  private:
    std::unique_ptr<User::Stub> stub_;
  };
}

#endif