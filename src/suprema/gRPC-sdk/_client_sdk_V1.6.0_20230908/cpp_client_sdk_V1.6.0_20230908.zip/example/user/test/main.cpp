#include <string>
#include <string.h>
#include <stdint.h>
#include <iostream>
#include <grpcpp/grpcpp.h>
#include <stdlib.h>
#include "GatewayClient.h"
#include "ConnectSvc.h"
#include "EventSvc.h"
#include "UserSvc.h"
#include "DeviceSvc.h"
#include "AuthSvc.h"
#include "CardSvc.h"
#include "FingerSvc.h"
#include "FaceSvc.h"

using grpc::Channel;
using grpc::Status;

using example::GatewayClient;
using example::ConnectSvc;
using example::EventSvc;
using example::UserSvc;
using example::DeviceSvc;
using example::AuthSvc;
using example::CardSvc;
using example::FingerSvc;
using example::FaceSvc;

using google::protobuf::RepeatedPtrField;

const std::string GATEWAY_CA_FILE = "../cert/gateway/ca.crt";
const std::string GATEWAY_ADDR = "192.168.8.98";
const int GATEWAY_PORT = 4000;

const std::string DEVICE_IP = "192.168.8.227";
const int DEVICE_PORT = 51211;
const bool USE_SSL = false;

const std::string CODE_MAP_FILE = "./event_code.json";

void startMonitoring(EventSvc& svc, uint32_t deviceID);
void stopMonitoring(EventSvc& svc, uint32_t deviceID);
void testEvent(EventSvc& svc, uint32_t deviceID, std::string userID);
std::string enrollUser(UserSvc& svc, uint32_t deviceID, bool extendedAuthSupported);
extern std::shared_ptr<AuthConfig> prepareAuthConfig(AuthSvc& svc, uint32_t deviceID);
void testCard(CardSvc& cardSvc, UserSvc& userSvc, uint32_t deviceID, std::string userID);
void testFinger(FingerSvc& fingerSvc, UserSvc& userSvc, uint32_t deviceID, std::string userID); 
void testFace(FaceSvc& faceSvc, UserSvc& userSvc, uint32_t deviceID, std::string userID);
void testAuth(AuthSvc& svc, uint32_t deviceID, bool extendedAuthSupported);

int main(int argc, char** argv) {
  uint32_t deviceID = 0;

  auto gatewayClient = std::make_shared<GatewayClient>();
  if (!gatewayClient->Connect(GATEWAY_ADDR, GATEWAY_PORT, GATEWAY_CA_FILE)) {
    std::cerr << "Cannot connect to the gateway" << std::endl;
    exit(1);
  }

  ConnectSvc connectSvc(gatewayClient->GetChannel());

  ConnectInfo connInfo;
  connInfo.set_ipaddr(DEVICE_IP);
  connInfo.set_port(DEVICE_PORT);
  connInfo.set_usessl(USE_SSL);

  Status status = connectSvc.Connect(connInfo, &deviceID);
  if (!status.ok()) {
    std::cerr << "Cannot connect to the device " << deviceID << std::endl;
    exit(1);
  }  

  std::vector<uint32_t> deviceIDs;
  deviceIDs.push_back(deviceID);

  DeviceSvc deviceSvc(gatewayClient->GetChannel());
  DeviceCapability capability;
  status = deviceSvc.GetCapability(deviceID, &capability);
  if (!status.ok()) {
    std::cerr << "Cannot get the device capability " << deviceID << std::endl;
    connectSvc.Disconnect(deviceIDs);
    exit(1);
  }

  EventSvc eventSvc(gatewayClient->GetChannel());
  eventSvc.InitCodeMap(CODE_MAP_FILE);
  startMonitoring(eventSvc, deviceID);  

  UserSvc userSvc(gatewayClient->GetChannel());
  auto userID = enrollUser(userSvc, deviceID, capability.extendedauthsupported());
  if (userID.compare("") == 0) {
    std::cerr << "Cannot enroll the test user" << std::endl;
    connectSvc.Disconnect(deviceIDs);
    exit(1);
  }

  std::vector<std::string> userIDs = {userID};

  AuthSvc authSvc(gatewayClient->GetChannel());
  auto origAuthConfig = prepareAuthConfig(authSvc, deviceID);

  if (capability.cardinputsupported()) {
    CardSvc cardSvc(gatewayClient->GetChannel());
    testCard(cardSvc, userSvc, deviceID, userID);
  } else {
    std::cerr << "!! The device does not support cards. Skip the card test." << std::endl;
  }

  if (capability.fingerprintinputsupported()) {
    FingerSvc fingerSvc(gatewayClient->GetChannel());
    testFinger(fingerSvc, userSvc, deviceID, userID);
  } else {
    std::cerr << "!! The device does not support fingerprints. Skip the finger test." << std::endl;
  }

  if (capability.faceinputsupported()) {
    FaceSvc faceSvc(gatewayClient->GetChannel());
    testFace(faceSvc, userSvc, deviceID, userID);
  } else {
    std::cerr << "!! The device does not support faces. Skip the face test." << std::endl;
  }

  testAuth(authSvc, deviceID, capability.extendedauthsupported());
  testEvent(eventSvc, deviceID, userID);

  userSvc.Delete(deviceID, userIDs);
  if (origAuthConfig) {
    authSvc.SetConfig(deviceID, *origAuthConfig.get());
  }  
  stopMonitoring(eventSvc, deviceID);
  connectSvc.Disconnect(deviceIDs);

  return 0;
}