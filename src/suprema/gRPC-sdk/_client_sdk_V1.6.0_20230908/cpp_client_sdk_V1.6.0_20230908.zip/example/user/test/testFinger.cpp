#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "FingerSvc.h"
#include "UserSvc.h"
#include "Menu.h"

using example::FingerSvc;
using example::UserSvc;
using example::Menu;

using gsdk::finger::FingerData;

const int QUALITY_THRESHOLD = 50;

void testFinger(FingerSvc& fingerSvc, UserSvc& userSvc, uint32_t deviceID, std::string userID) {
  std::cout << std::endl << "===== Finger Test =====" << std::endl << std::endl;

  FingerData fingerData;
  std::string templateData;

  std::cout << ">> Scan a finger on the device..." << std::endl;
  Status status = fingerSvc.Scan(deviceID, gsdk::finger::TEMPLATE_FORMAT_SUPREMA, QUALITY_THRESHOLD, templateData);
  if (!status.ok()) {
	  return;
  }

  fingerData.add_templates(templateData);

  std::cout << ">>> Scan the same finger again on the device..." << std::endl;
  status = fingerSvc.Scan(deviceID, gsdk::finger::TEMPLATE_FORMAT_SUPREMA, QUALITY_THRESHOLD, templateData);
  if (!status.ok()) {
	  return;
  }

  fingerData.add_templates(templateData);  

  RepeatedPtrField<UserFinger> userFingers;
  
  UserFinger userFinger;
  userFinger.set_userid(userID);
  userFinger.mutable_fingers()->Add(std::forward<FingerData>(fingerData));

  userFingers.Add(std::forward<UserFinger>(userFinger));

  status = userSvc.SetFinger(deviceID, userFingers);
  if (!status.ok()) {
	  return;
  }

  Menu::PressEnter(">> Try to authenticate the enrolled finger. And, press ENTER to end the test.\n");
}

