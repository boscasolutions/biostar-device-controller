#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <ctime>
#include "AuthSvc.h"
#include "UserSvc.h"
#include "DeviceSvc.h"
#include "Menu.h"

using example::UserSvc;
using example::Menu;

using gsdk::user::UserSetting;

std::string enrollUser(UserSvc& svc, uint32_t deviceID, bool extendedAuthSupported) {
  RepeatedPtrField<UserHdr> userList;
  Status status = svc.GetList(deviceID, &userList);
  if (!status.ok()) {
	  return "";
  }

  std::cout << std::endl << "Existing User list: " << std::endl;
  for(int i = 0; i < userList.size(); i++) {
    std::cout << userList[i].ShortDebugString() << std::endl;
  }
  std::cout << std::endl;

  RepeatedPtrField<UserInfo> newUserInfos;

  UserInfo userInfo;
  std::string userID = std::to_string(std::time(0));
  *userInfo.mutable_hdr()->mutable_id() = userID;

  UserSetting setting;
  if (extendedAuthSupported) {
    setting.set_cardauthextmode(gsdk::auth::AUTH_EXT_MODE_CARD_ONLY);
    setting.set_fingerauthextmode(gsdk::auth::AUTH_EXT_MODE_FINGERPRINT_ONLY);
    setting.set_faceauthextmode(gsdk::auth::AUTH_EXT_MODE_FACE_ONLY);
  } else {
    setting.set_cardauthmode(gsdk::auth::AUTH_MODE_CARD_ONLY);
    setting.set_biometricauthmode(gsdk::auth::AUTH_MODE_BIOMETRIC_ONLY);
  }  

  *userInfo.mutable_setting() = setting;
    
  newUserInfos.Add(std::forward<UserInfo>(userInfo));
  
  status = svc.Enroll(deviceID, newUserInfos);

  if (!status.ok()) {
	  return "";
  }  

  std::vector<std::string> newUserIDs = {userID};
  status = svc.GetUser(deviceID, newUserIDs, &newUserInfos);
  if (!status.ok()) {
	  return "";
  }

  std::cout << std::endl << "Test User: " << newUserInfos[0].ShortDebugString()  << std::endl << std::endl;

  return userID;
}

