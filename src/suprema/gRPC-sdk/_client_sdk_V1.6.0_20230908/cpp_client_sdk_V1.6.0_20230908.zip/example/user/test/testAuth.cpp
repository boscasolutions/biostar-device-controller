#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "AuthSvc.h"
#include "DeviceSvc.h"
#include "Menu.h"

using example::AuthSvc;
using example::Menu;

using gsdk::auth::AuthSchedule;

std::shared_ptr<AuthConfig> prepareAuthConfig(AuthSvc& svc, uint32_t deviceID) {
  // Backup the original configuration
  auto origConfig = std::make_shared<AuthConfig>();
  Status status = svc.GetConfig(deviceID, origConfig.get());
  if (!status.ok()) {
	  return nullptr;
  }

  std::cout << std::endl << "Original Auth Config: " << std::endl << origConfig.get()->ShortDebugString() << std::endl << std::endl;

  // Enable private authentication for test
  AuthConfig config;
  config.CopyFrom(*origConfig.get());

  config.set_useprivateauth(true);
  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return nullptr;
  }  

  return origConfig;
}


void testAuth(AuthSvc& svc, uint32_t deviceID, bool extendedAuthSupported) {
  std::cout << std::endl << "===== Auth Mode Test =====" << std::endl << std::endl;

  AuthConfig config;
  config.set_matchtimeout(10);
  config.set_authtimeout(15);

  AuthSchedule authSchedule;
  authSchedule.set_scheduleid(1); // Always

  if (extendedAuthSupported) {
    authSchedule.set_mode(gsdk::auth::AUTH_EXT_MODE_CARD_ONLY); // Card Only
    *config.add_authschedules() = authSchedule; 
    authSchedule.set_mode(gsdk::auth::AUTH_EXT_MODE_FINGERPRINT_ONLY); // Fingerprint Only
    *config.add_authschedules() = authSchedule; 
    authSchedule.set_mode(gsdk::auth::AUTH_EXT_MODE_FACE_ONLY); // Face Only
    *config.add_authschedules() = authSchedule; 
  } else {
    authSchedule.set_mode(gsdk::auth::AUTH_MODE_CARD_ONLY); // Card Only
    *config.add_authschedules() = authSchedule; 
    authSchedule.set_mode(gsdk::auth::AUTH_MODE_BIOMETRIC_ONLY); // Biometric Only
    *config.add_authschedules() = authSchedule; 
  }

  Status status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return;
  }  

  Menu::PressEnter(">> Try to authenticate card or fingerprint or face. And, press ENTER for the next test.\n");
 
  config.clear_authschedules();

  if (extendedAuthSupported) {
    authSchedule.set_mode(gsdk::auth::AUTH_EXT_MODE_CARD_FINGERPRINT); // Card + Fingerprint
    *config.add_authschedules() = authSchedule; 
    authSchedule.set_mode(gsdk::auth::AUTH_EXT_MODE_CARD_FACE); // Card + Face
    *config.add_authschedules() = authSchedule; 
  } else {
    authSchedule.set_mode(gsdk::auth::AUTH_MODE_CARD_BIOMETRIC); // Card + Biometric
    *config.add_authschedules() = authSchedule; 
  }

  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return;
  }   

  Menu::PressEnter(">> Try to authenticate (card + fingerprint) or (card + face). And, press ENTER to end the test.\n");
}
