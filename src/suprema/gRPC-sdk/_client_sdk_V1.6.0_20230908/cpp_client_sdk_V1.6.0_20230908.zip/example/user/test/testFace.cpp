#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "FaceSvc.h"
#include "UserSvc.h"
#include "Menu.h"

using example::FaceSvc;
using example::UserSvc;
using example::Menu;
using gsdk::face::FaceData;

void testFace(FaceSvc& faceSvc, UserSvc& userSvc, uint32_t deviceID, std::string userID) {
  std::cout << std::endl << "===== Face Test =====" << std::endl << std::endl;
  std::cout << ">> Enroll a unregistered face on the device..." << std::endl;

  FaceData faceData;
  Status status = faceSvc.Scan(deviceID, gsdk::face::BS2_FACE_ENROLL_THRESHOLD_DEFAULT, &faceData);
  if (!status.ok()) {
	  return;
  }

  UserFace userFace;
  userFace.set_userid(userID);
  userFace.mutable_faces()->Add(std::forward<FaceData>(faceData));

  RepeatedPtrField<UserFace> userFaces;
  userFaces.Add(std::forward<UserFace>(userFace));

  status = userSvc.SetFace(deviceID, userFaces);
  if (!status.ok()) {
	  return;
  }

  Menu::PressEnter(">> Try to authenticate the enrolled face. And, press ENTER to end the test.\n");
}

