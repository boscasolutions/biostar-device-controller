#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <thread>
#include "EventSvc.h"

using grpc::ClientContext;
using example::EventSvc;
using gsdk::event::EventFilter;

std::shared_ptr<ClientContext> s_Context;
std::thread s_MonitoringThread;
const int EVENT_QUEUE_SIZE = 16;

int s_FirstEventID = 0;

void handleEvent(std::unique_ptr<ClientReader<EventLog>> eventReader);
void printEvent(EventSvc& svc, EventLog& event);

void startMonitoring(EventSvc& svc, uint32_t deviceID) {
  Status status = svc.EnableMonitoring(deviceID);

  if (!status.ok()) {
	  return;
  }

	s_Context = std::make_shared<ClientContext>();
	auto eventReader(svc.Subscribe(s_Context.get(), EVENT_QUEUE_SIZE));

	s_MonitoringThread = std::thread(handleEvent, std::move(eventReader));
}


void stopMonitoring(EventSvc& svc, uint32_t deviceID) {
  s_Context->TryCancel();
	s_MonitoringThread.join();
  svc.DisableMonitoring(deviceID);  
}


void handleEvent(std::unique_ptr<ClientReader<EventLog>> eventReader) {
	EventLog realtimeEvent;

	while (eventReader->Read(&realtimeEvent)) {
		if (s_FirstEventID == 0) {
			s_FirstEventID = realtimeEvent.id();
		}

		std::cout << "[EVENT] " << realtimeEvent.ShortDebugString() << std::endl;
	}

	std::cout << "Monitoring thread is stopped" << std::endl;

	eventReader->Finish();
}

void testEvent(EventSvc& svc, uint32_t deviceID, std::string userID) {
  std::cout << std::endl << "===== Log Events of Test User =====" << std::endl << std::endl;

  EventFilter filter;
  filter.set_userid(userID);

  RepeatedPtrField<EventLog> events;
  Status status = svc.GetLogWithFilter(deviceID, s_FirstEventID, 0, filter, &events);
  if (!status.ok()) {
	  return;
  }

  for(int i = 0; i < events.size(); i++) {
    printEvent(svc, events[i]);
  }

  std::cout << std::endl << "===== Verify Success Events of Test User =====" << std::endl << std::endl;

  filter.set_eventcode(0x1000); // BS2_EVENT_VERIFY_SUCCESS

  status = svc.GetLogWithFilter(deviceID, s_FirstEventID, 0, filter, &events);
  if (!status.ok()) {
	  return;
  }

  for(int i = 0; i < events.size(); i++) {
    printEvent(svc, events[i]);
  }  
}


void printEvent(EventSvc& svc, EventLog& event) {
	time_t eventTime = (time_t)event.timestamp();
  std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Device " << event.deviceid() << ", User " << event.userid() << ", " << svc.GetEventString(event.eventcode(), event.subcode()) << std::endl;
}

