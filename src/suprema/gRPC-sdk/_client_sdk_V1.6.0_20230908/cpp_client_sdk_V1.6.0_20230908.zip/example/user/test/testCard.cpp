#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "CardSvc.h"
#include "UserSvc.h"
#include "Menu.h"

using example::CardSvc;
using example::UserSvc;
using example::Menu;

void testCard(CardSvc& cardSvc, UserSvc& userSvc, uint32_t deviceID, std::string userID) {
  std::cout << std::endl << "===== Card Test =====" << std::endl << std::endl;
  std::cout << ">> Place a unregistered card on the device..." << std::endl;

  CardData cardData;
  Status status = cardSvc.Scan(deviceID, &cardData);
  if (!status.ok()) {
	  return;
  }

  if(!cardData.has_csncarddata()) {
    std::cerr << "!! The card is a smart card. For this test, you have to use a CSN card. Skip the card test." << std::endl;
    return;
  }

  UserCard userCard;
  userCard.set_userid(userID);
	*userCard.add_cards() = cardData.csncarddata();

  RepeatedPtrField<UserCard> userCards;
  userCards.Add(std::forward<UserCard>(userCard));

  status = userSvc.SetCard(deviceID, userCards);
  if (!status.ok()) {
	  return;
  }

  Menu::PressEnter(">> Try to authenticate the enrolled card. And, press ENTER to end the test.\n");
}

