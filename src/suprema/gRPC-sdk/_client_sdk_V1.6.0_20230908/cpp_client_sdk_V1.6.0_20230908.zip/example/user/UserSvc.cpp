#include <iostream>
#include "UserSvc.h"

using grpc::ClientContext;

using gsdk::user::GetListRequest;
using gsdk::user::GetListResponse;

using gsdk::user::GetRequest;
using gsdk::user::GetResponse;

using gsdk::user::EnrollRequest;
using gsdk::user::EnrollResponse;
using gsdk::user::EnrollMultiRequest;
using gsdk::user::EnrollMultiResponse;

using gsdk::user::UpdateRequest;
using gsdk::user::UpdateResponse;
using gsdk::user::UpdateMultiRequest;
using gsdk::user::UpdateMultiResponse;

using gsdk::user::SetFingerRequest;
using gsdk::user::SetFingerResponse;

using gsdk::user::SetCardRequest;
using gsdk::user::SetCardResponse;

using gsdk::user::SetFaceRequest;
using gsdk::user::SetFaceResponse;

using gsdk::user::SetAccessGroupRequest;
using gsdk::user::SetAccessGroupResponse;

using gsdk::user::GetAccessGroupRequest;
using gsdk::user::GetAccessGroupResponse;

using gsdk::user::DeleteRequest;
using gsdk::user::DeleteResponse;
using gsdk::user::DeleteMultiRequest;
using gsdk::user::DeleteMultiResponse;

namespace example {
  Status UserSvc::GetList(uint32_t deviceID, RepeatedPtrField<UserHdr>* userList) {
    GetListRequest request;
    request.set_deviceid(deviceID);

    GetListResponse response;

    ClientContext context;

    Status status = stub_->GetList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the user list: " << status.error_message() << std::endl;
      return status;
    }

    *userList = response.hdrs();

    return status;
  }

  Status UserSvc::GetUser(uint32_t deviceID, std::vector<std::string>& userIDs, RepeatedPtrField<UserInfo>* userInfos) {
    GetRequest request;
    request.set_deviceid(deviceID);
    for(int i = 0; i < userIDs.size(); i++) {
      request.add_userids(userIDs[i]);
    } 

    GetResponse response;

    ClientContext context;

    Status status = stub_->Get(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get users: " << status.error_message() << std::endl;
      return status;
    }

    *userInfos = response.users();

    return status;
  }

  Status UserSvc::Enroll(uint32_t deviceID, RepeatedPtrField<UserInfo>& userInfos) {
    EnrollRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_users() = userInfos;

    EnrollResponse response;

    ClientContext context;

    Status status = stub_->Enroll(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot enroll users: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status UserSvc::EnrollMulti(std::vector<uint32_t> deviceIDs, RepeatedPtrField<UserInfo>& userInfos) {
    EnrollMultiRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }
    *request.mutable_users() = userInfos;

    EnrollMultiResponse response;

    ClientContext context;

    Status status = stub_->EnrollMulti(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot enroll users multi: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status UserSvc::Update(uint32_t deviceID, RepeatedPtrField<UserInfo>& userInfos) {
    UpdateRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_users() = userInfos;

    UpdateResponse response;

    ClientContext context;

    Status status = stub_->Update(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot update users: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status UserSvc::UpdateMulti(std::vector<uint32_t> deviceIDs, RepeatedPtrField<UserInfo>& userInfos) {
    UpdateMultiRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }
    *request.mutable_users() = userInfos;

    UpdateMultiResponse response;

    ClientContext context;

    Status status = stub_->UpdateMulti(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot update users multi: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status UserSvc::SetFinger(uint32_t deviceID, RepeatedPtrField<UserFinger>& userFingers) {
    SetFingerRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_userfingers() = userFingers;

    SetFingerResponse response;

    ClientContext context;

    Status status = stub_->SetFinger(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot set user fingers: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status UserSvc::SetCard(uint32_t deviceID, RepeatedPtrField<UserCard>& userCards) {
    SetCardRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_usercards() = userCards;

    SetCardResponse response;

    ClientContext context;

    Status status = stub_->SetCard(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot set user cards: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }  

  Status UserSvc::SetFace(uint32_t deviceID, RepeatedPtrField<UserFace>& userFaces) {
    SetFaceRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_userfaces() = userFaces;

    SetFaceResponse response;

    ClientContext context;

    Status status = stub_->SetFace(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot set user facess: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }    

  Status UserSvc::SetAccessGroup(uint32_t deviceID, RepeatedPtrField<UserAccessGroup>& userAccessGroups) {
    SetAccessGroupRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_useraccessgroups() = userAccessGroups;

    SetAccessGroupResponse response;
    ClientContext context;

    Status status = stub_->SetAccessGroup(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot set user access groups: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }    

  Status UserSvc::GetAccessGroup(uint32_t deviceID, std::vector<std::string>& userIDs, RepeatedPtrField<UserAccessGroup>* userAccessGroups) {
    GetAccessGroupRequest request;
    request.set_deviceid(deviceID);
    for(int i = 0; i < userIDs.size(); i++) {
      request.add_userids(userIDs[i]);
    }   

    GetAccessGroupResponse response;
    ClientContext context;

    Status status = stub_->GetAccessGroup(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get user access groups: " << status.error_message() << std::endl;
      return status;
    }

    *userAccessGroups = response.useraccessgroups();

    return status;
  }      


  Status UserSvc::Delete(uint32_t deviceID, std::vector<std::string> &userIDs) {
    DeleteRequest request;
    request.set_deviceid(deviceID);
    for(int i = 0; i < userIDs.size(); i++) {
      request.add_userids(userIDs[i]);
    }    
		
    DeleteResponse response;

    ClientContext context;

    Status status = stub_->Delete(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete users: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }

  Status UserSvc::DeleteMulti(std::vector<uint32_t> deviceIDs, std::vector<std::string> &userIDs) {
    DeleteMultiRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }    
    for(int i = 0; i < userIDs.size(); i++) {
      request.add_userids(userIDs[i]);
    }    
		
    DeleteMultiResponse response;

    ClientContext context;

    Status status = stub_->DeleteMulti(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete users multi: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }
} 