#include <iostream>
#include "RtspSvc.h"

using grpc::ClientContext;

using gsdk::rtsp::GetConfigRequest;
using gsdk::rtsp::GetConfigResponse;

using gsdk::rtsp::SetConfigRequest;
using gsdk::rtsp::SetConfigResponse;

namespace example {

	Status RtspSvc::GetConfig(uint32_t deviceID, RTSPConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the rtsp config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}	

	Status RtspSvc::SetConfig(uint32_t deviceID, RTSPConfig& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
    *request.mutable_config() = config;

		SetConfigResponse response;

		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the rtsp config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}	  
}