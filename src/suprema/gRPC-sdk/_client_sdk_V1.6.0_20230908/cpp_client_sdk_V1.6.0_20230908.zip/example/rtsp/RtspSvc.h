#ifndef __RTSP_SVC__H__
#define __RTSP_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "rtsp.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::rtsp::RTSP;
using gsdk::rtsp::RTSPConfig;

using google::protobuf::RepeatedPtrField;

namespace example {
	class RtspSvc {
	public:
		RtspSvc(std::shared_ptr<Channel> channel)
			: stub_(RTSP::NewStub(channel)) {}

		Status GetConfig(uint32_t deviceID, RTSPConfig* config);
		Status SetConfig(uint32_t deviceID, RTSPConfig& config);

	private:
		std::unique_ptr<RTSP::Stub> stub_;
	};
}

#endif
