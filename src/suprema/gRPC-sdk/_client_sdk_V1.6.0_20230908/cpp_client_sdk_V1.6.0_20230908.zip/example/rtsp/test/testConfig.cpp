#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "RtspSvc.h"
#include "Menu.h"

using example::RtspSvc;
using example::Menu;

void testConfig(RtspSvc& svc, uint32_t deviceID, RTSPConfig& config) {
  std::cout << std::endl << "===== Test for RTSPConfig =====" << std::endl << std::endl;

  // Backup the original configuration
  RTSPConfig origConfig;
  origConfig.CopyFrom(config);

  config.set_serverurl("rtsp.server.com");
  config.set_serverport(554);
  config.set_userid("RTSP User ID");
  config.set_userpw("2378129307");
  config.set_enabled(true);

  Status status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return;
  }

  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");    

  // Restore the original configuration   
  svc.SetConfig(deviceID, origConfig);
}

