#include <iostream>
#include "TenantSvc.h"

using grpc::ClientContext;

using gsdk::tenant::GetRequest;
using gsdk::tenant::GetResponse;

using gsdk::tenant::AddRequest;
using gsdk::tenant::AddResponse;

namespace example {
	Status TenantSvc::Get(std::vector<std::string>& tenantIDs, RepeatedPtrField<TenantInfo>* tenantInfos) {
		GetRequest request;
    for(int i = 0; i < tenantIDs.size(); i++) {
      request.add_tenantids(tenantIDs[i]);
    }

		GetResponse response;
		ClientContext context;

		Status status = stub_->Get(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the tenant information: " << status.error_message() << std::endl;
			return status;
		}

    *tenantInfos = response.tenantinfos();

		return status;
	}

	Status TenantSvc::Add(RepeatedPtrField<TenantInfo>& tenantInfos) {
		AddRequest request;
    *request.mutable_tenantinfos() = tenantInfos;

		AddResponse response;
		ClientContext context;

		Status status = stub_->Add(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot add the tenant information: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}
}