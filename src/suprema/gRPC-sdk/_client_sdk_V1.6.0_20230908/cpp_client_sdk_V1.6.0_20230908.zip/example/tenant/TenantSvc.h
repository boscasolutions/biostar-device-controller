#ifndef __TENANT_SVC__H__
#define __TENANT_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>

#include "tenant.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::tenant::Tenant;
using gsdk::tenant::TenantInfo;

using google::protobuf::RepeatedPtrField;

namespace example {
	class TenantSvc {
	public:
		TenantSvc(std::shared_ptr<Channel> channel)
			: stub_(Tenant::NewStub(channel)) {}

		Status Get(std::vector<std::string>& tenantIDs, RepeatedPtrField<TenantInfo>* infos);
		Status Add(RepeatedPtrField<TenantInfo>& infos);

	private:
		std::unique_ptr<Tenant::Stub> stub_;
	};
}

#endif
