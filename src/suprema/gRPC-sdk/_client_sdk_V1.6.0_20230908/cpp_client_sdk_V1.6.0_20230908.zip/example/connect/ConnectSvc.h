#ifndef __CONNECT_SVC__H__
#define __CONNECT_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "connect.grpc.pb.h"

using grpc::Channel;
using grpc::Status;
using grpc::ClientReader;
using grpc::ClientContext;

using gsdk::connect::DeviceInfo;
using gsdk::connect::Connect;
using gsdk::connect::ConnectInfo;
using gsdk::connect::SearchDeviceInfo;
using gsdk::connect::AsyncConnectInfo;
using gsdk::connect::StatusChange;
using gsdk::connect::PendingDeviceInfo;
using gsdk::connect::AcceptFilter;
using gsdk::connect::ConnectionMode;

using google::protobuf::RepeatedPtrField;

namespace example {
  class ConnectSvc {
  public:
    ConnectSvc(std::shared_ptr<Channel> channel)
        : stub_(Connect::NewStub(channel)) {}

    Status GetDeviceList(RepeatedPtrField<DeviceInfo>* deviceInfos);

    Status SearchDevice(int searchTimeout, RepeatedPtrField<SearchDeviceInfo>* deviceInfos);

    Status Connect(ConnectInfo& connInfo, uint32_t* deviceID);

    Status Disconnect(std::vector<uint32_t>& deviceIDs);
    Status DisconnectAll();

    Status SetConnectionMode(std::vector<uint32_t>& deviceIDs, ConnectionMode mode);
    Status EnableSSL(std::vector<uint32_t>& deviceIDs);
    Status DisableSSL(std::vector<uint32_t>& deviceIDs);

    Status AddAsyncConnection(RepeatedPtrField<AsyncConnectInfo>& asyncInfos);
    Status DeleteAsyncConnection(std::vector<uint32_t>& deviceIDs);

    Status GetPendingList(RepeatedPtrField<PendingDeviceInfo>* deviceInfos);
    Status GetAcceptFilter(AcceptFilter* filter);
    Status SetAcceptFilter(AcceptFilter& filter);

    std::unique_ptr<ClientReader<StatusChange>> Subscribe(ClientContext* context, int queueSize);
  private:
    std::unique_ptr<Connect::Stub> stub_;
  };
}

#endif