#include <iostream>
#include "ConnectSvc.h"

using grpc::ClientContext;

using gsdk::connect::GetDeviceListRequest;
using gsdk::connect::GetDeviceListResponse;

using gsdk::connect::SearchDeviceRequest;
using gsdk::connect::SearchDeviceResponse;

using gsdk::connect::ConnectRequest;
using gsdk::connect::ConnectResponse;

using gsdk::connect::DisconnectRequest;
using gsdk::connect::DisconnectResponse;

using gsdk::connect::DisconnectAllRequest;
using gsdk::connect::DisconnectAllResponse;

using gsdk::connect::SetConnectionModeMultiRequest;
using gsdk::connect::SetConnectionModeMultiResponse;

using gsdk::connect::EnableSSLMultiRequest;
using gsdk::connect::EnableSSLMultiResponse;

using gsdk::connect::DisableSSLMultiRequest;
using gsdk::connect::DisableSSLMultiResponse;

using gsdk::connect::AddAsyncConnectionRequest;
using gsdk::connect::AddAsyncConnectionResponse;

using gsdk::connect::DeleteAsyncConnectionRequest;
using gsdk::connect::DeleteAsyncConnectionResponse;

using gsdk::connect::GetAcceptFilterRequest;
using gsdk::connect::GetAcceptFilterResponse;

using gsdk::connect::SetAcceptFilterRequest;
using gsdk::connect::SetAcceptFilterResponse;

using gsdk::connect::GetPendingListRequest;
using gsdk::connect::GetPendingListResponse;


using gsdk::connect::SubscribeStatusRequest;

namespace example {
  Status ConnectSvc::GetDeviceList(RepeatedPtrField<DeviceInfo>* deviceInfos) {
    GetDeviceListRequest request;
    GetDeviceListResponse response;

    ClientContext context;

    Status status = stub_->GetDeviceList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get device list: " << status.error_message() << std::endl;
      return status;
    }

    *deviceInfos = response.deviceinfos();

    return status;
  }

  Status ConnectSvc::SearchDevice(int searchTimeout, RepeatedPtrField<SearchDeviceInfo>* deviceInfos) {
    SearchDeviceRequest request;
    request.set_timeout(searchTimeout);

    SearchDeviceResponse response;

    ClientContext context;

    Status status = stub_->SearchDevice(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot search devices: " << status.error_message() << std::endl;
      return status;
    }

    *deviceInfos = response.deviceinfos();

    return status;
  }


  Status ConnectSvc::Connect(ConnectInfo& connInfo, uint32_t* deviceID) {
    ConnectRequest request;
    *request.mutable_connectinfo() = connInfo;

    ConnectResponse response;

    ClientContext context;

    Status status = stub_->Connect(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot connect to the device: " << status.error_message() << std::endl;
      return status;
    }

    *deviceID = response.deviceid();

    return status;
  }

  Status ConnectSvc::Disconnect(std::vector<uint32_t>& deviceIDs) {
    DisconnectRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }

    DisconnectResponse response;

    ClientContext context;

    Status status = stub_->Disconnect(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot disconnect the device: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectSvc::DisconnectAll() {
    DisconnectAllRequest request;
    DisconnectAllResponse response;

    ClientContext context;

    Status status = stub_->DisconnectAll(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot disconnect all devices: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }  

  Status ConnectSvc::SetConnectionMode(std::vector<uint32_t>& deviceIDs, ConnectionMode mode) {
    SetConnectionModeMultiRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }
    request.set_connectionmode(mode);

    SetConnectionModeMultiResponse response;

    ClientContext context;

    Status status = stub_->SetConnectionModeMulti(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot set connection mode: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectSvc::EnableSSL(std::vector<uint32_t>& deviceIDs) {
    EnableSSLMultiRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }

    EnableSSLMultiResponse response;

    ClientContext context;

    Status status = stub_->EnableSSLMulti(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot enable SSL: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectSvc::DisableSSL(std::vector<uint32_t>& deviceIDs) {
    DisableSSLMultiRequest request;
    for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }

    DisableSSLMultiResponse response;

    ClientContext context;

    Status status = stub_->DisableSSLMulti(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot disable SSL: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectSvc::AddAsyncConnection(RepeatedPtrField<AsyncConnectInfo>& asyncInfos) {
    AddAsyncConnectionRequest request;
    *request.mutable_connectinfos() = asyncInfos;

    AddAsyncConnectionResponse response;

    ClientContext context;

    Status status = stub_->AddAsyncConnection(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot add async connections: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectSvc::DeleteAsyncConnection(std::vector<uint32_t>& deviceIDs) {
    DeleteAsyncConnectionRequest request;
     for(int i = 0; i < deviceIDs.size(); i++) {
      request.add_deviceids(deviceIDs[i]);
    }

    DeleteAsyncConnectionResponse response;

    ClientContext context;

    Status status = stub_->DeleteAsyncConnection(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete async connections: " << status.error_message() << std::endl;
      return status;
    }

    return status;
  }

  Status ConnectSvc::GetPendingList(RepeatedPtrField<PendingDeviceInfo>* deviceInfos) {
    GetPendingListRequest request;
    GetPendingListResponse response;

    ClientContext context;

    Status status = stub_->GetPendingList(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the pending list: " << status.error_message() << std::endl;
      return status;
    }

    *deviceInfos = response.deviceinfos();

    return status;
  }  

  Status ConnectSvc::GetAcceptFilter(AcceptFilter* filter) {
    GetAcceptFilterRequest request;
    GetAcceptFilterResponse response;

    ClientContext context;

    Status status = stub_->GetAcceptFilter(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the accept filter: " << status.error_message() << std::endl;
      return status;
    }

    *filter = response.filter();

    return status;    
  }

  Status ConnectSvc::SetAcceptFilter(AcceptFilter& filter) {
    SetAcceptFilterRequest request;
    *request.mutable_filter() = filter;

    SetAcceptFilterResponse response;

    ClientContext context;

    Status status = stub_->SetAcceptFilter(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot set the accept filter: " << status.error_message() << std::endl;
      return status;
    }

    return status;    
  }  

  std::unique_ptr<ClientReader<StatusChange>> ConnectSvc::Subscribe(ClientContext* context, int queueSize) {
    SubscribeStatusRequest request;
    request.set_queuesize(queueSize);

    return stub_->SubscribeStatus(context, request);
  }  
} 