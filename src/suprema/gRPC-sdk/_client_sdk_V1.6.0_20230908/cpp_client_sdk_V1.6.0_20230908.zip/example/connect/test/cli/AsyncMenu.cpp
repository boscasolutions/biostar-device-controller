#include <iostream>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>
#include "AsyncMenu.h"
#include "Util.h"

using grpc::Status;
using google::protobuf::RepeatedPtrField;

namespace example {
  AsyncMenu::AsyncMenu() {
    std::vector<std::shared_ptr<MenuItem>> menuItems;

    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"1", "Add async connections", AddAsyncConnection, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"2", "Delete async connections", DeleteAsyncConnection, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"3", "Refresh the connection list", RefreshAsyncList, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"q", "Return to Main Menu", NULL, NULL, true}));

    menu_  = std::make_unique<Menu>(menuItems);
  } 

  void AsyncMenu::SetConnectSvc(std::shared_ptr<ConnectSvc> svc) {
    connectSvc_ = svc;
  }

  void AsyncMenu::Show() {
    RefreshAsyncList(this);

    menu_->Show("Async Menu");
  }
  
  void AsyncMenu::RefreshAsyncList(void* arg) {
    AsyncMenu* menu = static_cast<AsyncMenu*>(arg);

    std::cout << "Getting the async connections..." << std::endl;

    RepeatedPtrField<DeviceInfo> deviceInfos;
    Status status = menu->GetConnectSvc()->GetDeviceList(&deviceInfos);

    if(!status.ok()) {
      return;
    }

    std::vector<DeviceInfo*> asyncInfos;
    for(int i = 0; i < deviceInfos.size(); i++) {
      if(deviceInfos[i].autoreconnect()) {
        asyncInfos.push_back(&deviceInfos[i]);
      }
    }

    std::cout << "***** Async Connections: " << asyncInfos.size() << std::endl;

    for(int i = 0; i < asyncInfos.size(); i++) {
      std::cout << asyncInfos[i]->ShortDebugString() << std::endl;
    }
  }

  void AsyncMenu::AddAsyncConnection(void* arg) {
    AsyncMenu* menu = static_cast<AsyncMenu*>(arg);  

    RepeatedPtrField<AsyncConnectInfo> asyncConnInfos;

    while(true) {
      std::cout << ">> Enter the device ID (Press just ENTER if no more device): ";
      std::string idStr;
      std::getline(std::cin, idStr);

      if(idStr == "") {
        break;
      }

      AsyncConnectInfo asyncConnInfo;

      try {
		    uint32_t deviceID = std::stoi(idStr);
        asyncConnInfo.set_deviceid(deviceID);
      } catch (std::invalid_argument const &e) {
        std::cerr << "Invalid device ID: " << idStr << std::endl;
        return;
      }

      std::shared_ptr<ConnectInfo> connInfo = Util::GetConnectInfo();

      if(!connInfo) {
        return;
      }

      asyncConnInfo.set_ipaddr(connInfo->ipaddr());
      asyncConnInfo.set_port(connInfo->port());
      asyncConnInfo.set_usessl(connInfo->usessl());

      asyncConnInfos.Add(std::forward<AsyncConnectInfo>(asyncConnInfo));
    }

    if(asyncConnInfos.size() == 0) {
      std::cout << "No connection to add" << std::endl;
      return;
    }

    std::cout << "Adding async connections..." << std::endl;
    Status status = menu->GetConnectSvc()->AddAsyncConnection(asyncConnInfos);

    if(!status.ok()) {
      return;
    }

    RefreshAsyncList(arg);
  }

  void AsyncMenu::DeleteAsyncConnection(void* arg) {
    AsyncMenu* menu = static_cast<AsyncMenu*>(arg);  

    std::cout << "Enter the device IDs to delete" << std::endl;

    std::vector<uint32_t> deviceIDs;
    Menu::GetDeviceID(deviceIDs);

    if(deviceIDs.size() == 0) {
      std::cout << "No connection to delete" << std::endl;
      return;
    }

    std::cout << "Deleting async connections..." << std::endl;
    Status status = menu->GetConnectSvc()->DeleteAsyncConnection(deviceIDs);

    if(!status.ok()) {
      return;
    }

    RefreshAsyncList(arg);
  }

}
