#ifndef __ACCEPT_MENU_H__
#define __ACCEPT_MENU_H__

#include "ConnectSvc.h"
#include "Menu.h"

namespace example {
  class AcceptMenu {
  public:
		AcceptMenu();
    ~AcceptMenu() {}

		std::shared_ptr<ConnectSvc> GetConnectSvc() { return connectSvc_; }
    void SetConnectSvc(std::shared_ptr<ConnectSvc> svc);

    void Show();

    static void RefreshPendingList(void* arg);
    static void ShowAcceptFilter(void* arg);
    static void AllowAll(void* arg);
    static void DisallowAll(void* arg);
    static void AddDeviceToFilter(void* arg);
    static void DeleteDeviceFromFilter(void* arg);

  private:
    std::unique_ptr<Menu> menu_;
		std::shared_ptr<ConnectSvc> connectSvc_;
  };
}

#endif