#include <iostream>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>
#include "DeviceMenu.h"

using grpc::Status;
using google::protobuf::RepeatedPtrField;

namespace example {
  DeviceMenu::DeviceMenu() {
    std::vector<std::shared_ptr<MenuItem>> menuItems;

    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"1", "Set connection mode", SetConnectionMode, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"2", "Enable SSL", EnableSSL, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"3", "Disable SSL", DisableSSL, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"4", "Disconnect devices", Disconnect, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"5", "Disconnect all devices", DisconnectAll,  static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"6", "Refresh the managed device list", RefreshDeviceList, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"q", "Return to Main Menu", NULL, NULL, true}));

    menu_  = std::make_unique<Menu>(menuItems);
  } 

  void DeviceMenu::SetConnectSvc(std::shared_ptr<ConnectSvc> svc) {
    connectSvc_ = svc;
  }

  void DeviceMenu::Show() {
    if(GetDeviceList() == 0) {
      std::cout << "No connected device. Please connect to some devices first." << std::endl;
      return;
    }

    menu_->Show("Device Menu");
  }

  int DeviceMenu::GetDeviceList() {
    std::cout << "Getting the devices managed by the gateway..." << std::endl;

    RepeatedPtrField<DeviceInfo> deviceInfos;
    Status status = connectSvc_->GetDeviceList(&deviceInfos);

    if(!status.ok()) {
      return 0;
    }

    std::cout << "***** Managed Devices: " << deviceInfos.size() << std::endl;

    for(int i = 0; i < deviceInfos.size(); i++) {
      std::cout << deviceInfos[i].ShortDebugString() << std::endl;
    }

    return deviceInfos.size();
  }

  void DeviceMenu::DisconnectAll(void* arg) {
    DeviceMenu* menu = static_cast<DeviceMenu*>(arg);

    std::cout << "Disconnecting all devices..." << std::endl;

    Status status = menu->GetConnectSvc()->DisconnectAll();

		if (!status.ok()) {
			std::cerr << "Cannot disconnect all devices!" << std::endl;
		}
  }

  void DeviceMenu::Disconnect(void* arg) {
    DeviceMenu* menu = static_cast<DeviceMenu*>(arg);

    std::cout << "Enter the device IDs to disconnect" << std::endl;

    std::vector<uint32_t> deviceIDs;
    Menu::GetDeviceID(deviceIDs);

    if(deviceIDs.size() == 0) {
      std::cout << "No device to disconnect" << std::endl;
      return;
    }

    std::cout << "Disconnecting the devices..." << std::endl;

    Status status = menu->GetConnectSvc()->Disconnect(deviceIDs);

		if (!status.ok()) {
			std::cerr << "Cannot disconnect the device!" << std::endl;
		}
  }  

  void DeviceMenu::SetConnectionMode(void* arg) {
    DeviceMenu* menu = static_cast<DeviceMenu*>(arg);

    std::cout << "Enter the device IDs to change" << std::endl;

    std::vector<uint32_t> deviceIDs;
    Menu::GetDeviceID(deviceIDs);

    if(deviceIDs.size() == 0) {
      std::cout << "No device to set" << std::endl;
      return;
    }

    std::cout << ">> Select the connection mode (0: Gateway to Device(default), 1: Device to Gateway): ";
    std::string inputStr;
    std::getline(std::cin, inputStr);

    ConnectionMode mode = ConnectionMode::SERVER_TO_DEVICE;

    try {
      int modeVal = std::stoi(inputStr);
      if(modeVal == 1) {
        mode = ConnectionMode::DEVICE_TO_SERVER;
      }
    } catch (std::invalid_argument const &e) {
      // just set default value
    }    

    std::cout << "Setting the connection mode..." << std::endl;

    Status status = menu->GetConnectSvc()->SetConnectionMode(deviceIDs, mode);

		if (!status.ok()) {
			std::cerr << "Cannot set the connection mode!" << std::endl;
		}    
  }

  void DeviceMenu::EnableSSL(void* arg) {
    DeviceMenu* menu = static_cast<DeviceMenu*>(arg);

    std::cout << "Enter the device IDs to enable" << std::endl;

    std::vector<uint32_t> deviceIDs;
    Menu::GetDeviceID(deviceIDs);

    if(deviceIDs.size() == 0) {
      std::cout << "No device to enable" << std::endl;
      return;
    }

    std::cout << "Enabling SSL..." << std::endl;

    Status status = menu->GetConnectSvc()->EnableSSL(deviceIDs);

		if (!status.ok()) {
			std::cerr << "Cannot enable SSL!" << std::endl;
		}
  }

  void DeviceMenu::DisableSSL(void* arg) {
    DeviceMenu* menu = static_cast<DeviceMenu*>(arg);

    std::cout << "Enter the device IDs to disable" << std::endl;

    std::vector<uint32_t> deviceIDs;
    Menu::GetDeviceID(deviceIDs);

    if(deviceIDs.size() == 0) {
      std::cout << "No device to disable" << std::endl;
      return;
    }

    std::cout << "Disabling SSL..." << std::endl;

    Status status = menu->GetConnectSvc()->DisableSSL(deviceIDs);

		if (!status.ok()) {
			std::cerr << "Cannot disable SSL!" << std::endl;
		}
  }


  void DeviceMenu::RefreshDeviceList(void* arg) {
    DeviceMenu* menu = static_cast<DeviceMenu*>(arg);
    
    menu->GetDeviceList();
  }
}
