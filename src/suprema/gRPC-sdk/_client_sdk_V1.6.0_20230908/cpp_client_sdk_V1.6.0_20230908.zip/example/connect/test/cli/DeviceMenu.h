#ifndef __DEVICE_MENU_H__
#define __DEVICE_MENU_H__

#include "ConnectSvc.h"
#include "Menu.h"

namespace example {
  class DeviceMenu {
  public:
		DeviceMenu();
    ~DeviceMenu() {}

		std::shared_ptr<ConnectSvc> GetConnectSvc() { return connectSvc_; }
    void SetConnectSvc(std::shared_ptr<ConnectSvc> svc);

    void Show();

    int GetDeviceList();
    
    static void SetConnectionMode(void* arg);
    static void EnableSSL(void* arg);
    static void DisableSSL(void* arg);
    static void Disconnect(void* arg);
    static void DisconnectAll(void* arg);
    static void RefreshDeviceList(void* arg);

  private:
    std::unique_ptr<Menu> menu_;
		std::shared_ptr<ConnectSvc> connectSvc_;
  };
}

#endif