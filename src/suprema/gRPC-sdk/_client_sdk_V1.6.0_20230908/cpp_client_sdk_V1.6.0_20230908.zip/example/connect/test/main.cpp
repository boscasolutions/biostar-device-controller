#include <iostream>
#include <thread>
#include <sstream>

#include "MainMenu.h"
#include "GatewayClient.h"
#include "ConnectSvc.h"

using grpc::ClientReader;
using grpc::ClientContext;

using gsdk::connect::StatusChange;

using example::MainMenu;
using example::GatewayClient;
using example::ConnectSvc;

const std::string GATEWAY_CA_FILE = "../cert/gateway/ca.crt";
const std::string GATEWAY_ADDR = "192.168.0.2";
const int GATEWAY_PORT = 4000;

const int STATUS_QUEUE_SIZE = 16;

void subscribeStatus(std::unique_ptr<ClientReader<StatusChange>> statusReader) {
  StatusChange devStatus;

  while(statusReader->Read(&devStatus)) {
    if(devStatus.status() != gsdk::connect::Status::TCP_NOT_ALLOWED && devStatus.status() != gsdk::connect::Status::TLS_NOT_ALLOWED) {
      std::stringstream s;

      s << std::endl << "[STATUS] " << devStatus.ShortDebugString() << std::endl << std::endl;

      std::cout << s.str() << std::flush;
    }
  }  

  std::cout << "Subscribing thread is stopped" << std::endl;

  statusReader->Finish();
}

int main(int argc, char** argv) {
  GatewayClient client;
  if(!client.Connect(GATEWAY_ADDR, GATEWAY_PORT, GATEWAY_CA_FILE)) {
    std::cerr << "Cannot connect to the gateway" << std::endl;
    exit(1);
  }

	auto connectSvc = std::make_shared<ConnectSvc>(client.GetChannel());

  ClientContext context;
  auto statusReader(connectSvc->Subscribe(&context, STATUS_QUEUE_SIZE));
  std::thread subThread(subscribeStatus, std::move(statusReader));
  
	MainMenu mainMenu;
  mainMenu.SetConnectSvc(connectSvc);
  mainMenu.Show();

  context.TryCancel();
  subThread.join();

  return 0;
}

