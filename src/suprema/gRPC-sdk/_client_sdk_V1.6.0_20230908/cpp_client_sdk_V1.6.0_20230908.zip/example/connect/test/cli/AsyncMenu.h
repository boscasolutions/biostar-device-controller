#ifndef __ASYNC_MENU_H__
#define __ASYNC_MENU_H__

#include "ConnectSvc.h"
#include "Menu.h"

namespace example {
  class AsyncMenu {
  public:
		AsyncMenu();
    ~AsyncMenu() {}

		std::shared_ptr<ConnectSvc> GetConnectSvc() { return connectSvc_; }
    void SetConnectSvc(std::shared_ptr<ConnectSvc> svc);

    void Show();

    static void AddAsyncConnection(void* arg);
    static void DeleteAsyncConnection(void* arg);
    static void RefreshAsyncList(void* arg);

  private:
    std::unique_ptr<Menu> menu_;
		std::shared_ptr<ConnectSvc> connectSvc_;
  };
}

#endif