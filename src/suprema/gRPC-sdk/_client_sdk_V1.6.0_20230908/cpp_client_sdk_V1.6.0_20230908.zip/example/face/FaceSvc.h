#ifndef __FACE_SVC__H__
#define __FACE_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>

#include "face.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::face::Face;
using gsdk::face::FaceEnrollThreshold;
using gsdk::face::FaceData;
using gsdk::face::FaceConfig;

namespace example {
	class FaceSvc {
	public:
		FaceSvc(std::shared_ptr<Channel> channel)
			: stub_(Face::NewStub(channel)) {}

		Status Scan(uint32_t deviceID, FaceEnrollThreshold threshold, FaceData* faceData);
		Status GetConfig(uint32_t deviceID, FaceConfig* config);
		Status SetConfig(uint32_t deviceID, FaceConfig& config);

	private:
		std::unique_ptr<Face::Stub> stub_;
	};
}

#endif
