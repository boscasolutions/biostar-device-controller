#include <iostream>
#include "FaceSvc.h"

using grpc::ClientContext;

using gsdk::face::ScanRequest;
using gsdk::face::ScanResponse;

using gsdk::face::GetConfigRequest;
using gsdk::face::GetConfigResponse;

using gsdk::face::SetConfigRequest;
using gsdk::face::SetConfigResponse;

namespace example {
	Status FaceSvc::Scan(uint32_t deviceID, FaceEnrollThreshold threshold, FaceData* faceData) {
		ScanRequest request;
		request.set_deviceid(deviceID);
		request.set_enrollthreshold(threshold);

		ScanResponse response;

		ClientContext context;

		Status status = stub_->Scan(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot scan a face: " << status.error_message() << std::endl;
			return status;
		}

		*faceData = response.facedata();

		return status;
	}

	Status FaceSvc::GetConfig(uint32_t deviceID, FaceConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the Face config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}	

	Status FaceSvc::SetConfig(uint32_t deviceID, FaceConfig& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
    
		*request.mutable_config() = config;

		SetConfigResponse response;
		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the Face config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}
}