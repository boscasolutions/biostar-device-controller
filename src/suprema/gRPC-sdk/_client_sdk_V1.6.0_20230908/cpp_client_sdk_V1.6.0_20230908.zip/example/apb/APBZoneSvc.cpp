#include <iostream>
#include "APBZoneSvc.h"

using grpc::ClientContext;

using gsdk::apb_zone::GetRequest;
using gsdk::apb_zone::GetResponse;

using gsdk::apb_zone::GetStatusRequest;
using gsdk::apb_zone::GetStatusResponse;

using gsdk::apb_zone::AddRequest;
using gsdk::apb_zone::AddResponse;

using gsdk::apb_zone::DeleteAllRequest;
using gsdk::apb_zone::DeleteAllResponse;

using gsdk::apb_zone::ClearAllRequest;
using gsdk::apb_zone::ClearAllResponse;


namespace example {
  Status APBZoneSvc::Get(uint32_t deviceID, RepeatedPtrField<ZoneInfo>* zones) {
    GetRequest request;
    request.set_deviceid(deviceID);

    GetResponse response;
    ClientContext context;

    Status status = stub_->Get(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the apb zones: " << status.error_message() << std::endl;
      return status;
    }

    *zones = response.zones();

    return status;
  }

  Status APBZoneSvc::GetStatus(uint32_t deviceID, RepeatedPtrField<ZoneStatus>* zoneStatus) {
    GetStatusRequest request;
    request.set_deviceid(deviceID);

    GetStatusResponse response;
    ClientContext context;

    Status status = stub_->GetStatus(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get the zone status: " << status.error_message() << std::endl;
      return status;
    }

    *zoneStatus = response.status();

    return status;
  }


  Status APBZoneSvc::Add(uint32_t deviceID, RepeatedPtrField<ZoneInfo>& zones) {
    AddRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_zones() = zones;

    AddResponse response;
    ClientContext context;

    Status status = stub_->Add(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot add the zones: " << status.error_message() << std::endl;
    }

    return status;
  }

  Status APBZoneSvc::DeleteAll(uint32_t deviceID) {
    DeleteAllRequest request;
    request.set_deviceid(deviceID);
		
    DeleteAllResponse response;
    ClientContext context;

    Status status = stub_->DeleteAll(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot delete all the zones: " << status.error_message() << std::endl;
    }

    return status;    
  }

  Status APBZoneSvc::ClearAll(uint32_t deviceID, uint32_t zoneID) {
    ClearAllRequest request;
    request.set_deviceid(deviceID);
    request.set_zoneid(zoneID);
		
    ClearAllResponse response;
    ClientContext context;

    Status status = stub_->ClearAll(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot clear all the apb records: " << status.error_message() << std::endl;
    }

    return status;    
  }

} 