#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <fstream>
#include "APBZoneSvc.h"
#include "RS485Svc.h"
#include "Menu.h"
#include "action.grpc.pb.h"

using example::APBZoneSvc;
using example::Menu;

using gsdk::apb_zone::Member;
using gsdk::apb_zone::ReaderType;
using gsdk::apb_zone::Type;

using gsdk::action::Signal;
using gsdk::action::RelayAction;
using gsdk::action::Action;
using gsdk::action::ActionType;

const int TEST_ZONE_ID = 1;

void testZone(APBZoneSvc& zoneSvc, uint32_t deviceID, RepeatedPtrField<SlaveDeviceInfo> slaves);

void testAPBZone(APBZoneSvc& zoneSvc, uint32_t deviceID, RepeatedPtrField<SlaveDeviceInfo> slaves) {
  // Backup the zones
  RepeatedPtrField<ZoneInfo> origZones;
  Status status = zoneSvc.Get(deviceID, &origZones);
  if (!status.ok()) {
	  return;
  }

  Menu::PrintList<ZoneInfo>("Original Zones:", origZones);

  testZone(zoneSvc, deviceID, slaves);

  // Restore the zones
  zoneSvc.DeleteAll(deviceID);
  if(origZones.size() > 0) {
    zoneSvc.Add(deviceID, origZones);
  }
}


void testZone(APBZoneSvc& zoneSvc, uint32_t deviceID, RepeatedPtrField<SlaveDeviceInfo> slaves) {
  // Make a zone with the master device and the 1st slave device
  Member entryReader;
  entryReader.set_deviceid(deviceID);
  entryReader.set_readertype(ReaderType::ENTRY);

  Member exitReader;
  exitReader.set_deviceid(slaves[0].deviceid());
  exitReader.set_readertype(ReaderType::EXIT);

  Signal relaySignal;
  relaySignal.set_count(3);
  relaySignal.set_onduration(500);
  relaySignal.set_offduration(500);

  RelayAction relayAction;
  relayAction.set_relayindex(0);
  *relayAction.mutable_signal() = relaySignal;

  Action zoneAction;
  zoneAction.set_deviceid(deviceID);
  zoneAction.set_type(ActionType::ACTION_RELAY);
  *zoneAction.mutable_relay() = relayAction;

  ZoneInfo zone;
  zone.set_zoneid(TEST_ZONE_ID);
  zone.set_name("Test APB Zone");
  zone.set_type(Type::HARD); // hard APB
  zone.set_resetduration(0); // indefinite
  *zone.add_members() = entryReader;
  *zone.add_members() = exitReader;
  *zone.add_actions() = zoneAction;

  RepeatedPtrField<ZoneInfo> zones;
  zones.Add(std::forward<ZoneInfo>(zone));

  zoneSvc.Add(deviceID, zones);

  std::cout << std::endl << "===== Anti Passback Zone Test =====" << std::endl << std::endl;
  RepeatedPtrField<ZoneInfo> newZones;
  zoneSvc.Get(deviceID, &newZones);

  Menu::PrintList<ZoneInfo>("Test Zones:", newZones);

  std::cout << ">> Authenticate a regsistered credential on the entry device(" << deviceID << ") and/or the exit device(" << slaves[0].deviceid() << ") to test if the APB zone works correctly." << std::endl;
  Menu::PressEnter(">> Press ENTER for the next test.\n");

  Menu::PressEnter(">> Press ENTER after generating an APB violation.\n");

  zoneSvc.ClearAll(deviceID, TEST_ZONE_ID);

  std::cout << ">> The APB records are cleared. Try to authenticate the last credential which caused the APB violation. It should succeed since the APB records are cleared." << std::endl;  

  Menu::PressEnter(">> Press ENTER to finish the test.\n");
}
