#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <thread>
#include "EventSvc.h"

using grpc::ClientContext;
using example::EventSvc;

std::shared_ptr<ClientContext> s_Context;
std::thread s_MonitoringThread;

const int EVENT_QUEUE_SIZE = 16;
const int FIRST_ZONE_EVENT = 0x6000; // BS2_EVENT_ZONE_APB_VIOLATION
const int LAST_ZONE_EVENT = 0x6200; // BS2_EVENT_ZONE_APB_ALARM_CLEAR

void handleEvent(EventSvc& svc, std::unique_ptr<ClientReader<EventLog>> eventReader);
void printEvent(EventSvc& svc, EventLog& event);

void startMonitoring(EventSvc& svc, uint32_t deviceID) {
  Status status = svc.EnableMonitoring(deviceID);

  if (!status.ok()) {
	  return;
  }

	s_Context = std::make_shared<ClientContext>();
	auto eventReader(svc.Subscribe(s_Context.get(), EVENT_QUEUE_SIZE));

	s_MonitoringThread = std::thread(handleEvent, std::ref(svc), std::move(eventReader));
}


void stopMonitoring(EventSvc& svc, uint32_t deviceID) {
  s_Context->TryCancel();
	s_MonitoringThread.join();
  svc.DisableMonitoring(deviceID);  
}


void handleEvent(EventSvc& svc, std::unique_ptr<ClientReader<EventLog>> eventReader) {
	EventLog realtimeEvent;

	while (eventReader->Read(&realtimeEvent)) {
		printEvent(svc, realtimeEvent);
	}

	std::cout << "Monitoring thread is stopped" << std::endl;

	eventReader->Finish();
}


void printEvent(EventSvc& svc, EventLog& event) {
	time_t eventTime = (time_t)event.timestamp();

  if(event.eventcode() >= FIRST_ZONE_EVENT && event.eventcode() <= LAST_ZONE_EVENT) {
    std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": APBZone " << event.entityid() << ", " << svc.GetEventString(event.eventcode(), event.subcode()) << std::endl;
  } else {
    std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Device " << event.deviceid() << ", User " << event.userid() << ", " << svc.GetEventString(event.eventcode(), event.subcode()) << std::endl;
  }
}

