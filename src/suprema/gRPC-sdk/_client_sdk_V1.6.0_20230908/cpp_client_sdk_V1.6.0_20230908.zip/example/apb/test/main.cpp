#include <string>
#include <string.h>
#include <stdint.h>
#include <iostream>
#include <grpcpp/grpcpp.h>
#include <stdlib.h>
#include "GatewayClient.h"
#include "ConnectSvc.h"
#include "EventSvc.h"
#include "APBZoneSvc.h"
#include "RS485Svc.h"

using grpc::Channel;
using grpc::Status;

using example::GatewayClient;
using example::ConnectSvc;
using example::EventSvc;
using example::APBZoneSvc;
using example::RS485Svc;

using google::protobuf::RepeatedPtrField;

const std::string GATEWAY_CA_FILE = "../cert/gateway/ca.crt";
const std::string GATEWAY_ADDR = "192.168.0.2";
const int GATEWAY_PORT = 4000;

const std::string DEVICE_IP = "192.168.0.120";
const int DEVICE_PORT = 51211;
const bool USE_SSL = false;

const std::string CODE_MAP_FILE = "./event_code.json";

void startMonitoring(EventSvc& svc, uint32_t deviceID);
void stopMonitoring(EventSvc& svc, uint32_t deviceID);

bool checkSlaves(RS485Svc& rs485Svc, uint32_t deviceID);
void restoreSlaves(RS485Svc& rs485Svc, uint32_t deviceID);
RepeatedPtrField<SlaveDeviceInfo> getSlaves();

void testAPBZone(APBZoneSvc& apb_zoneSvc, uint32_t deviceID, RepeatedPtrField<SlaveDeviceInfo> slaves);

int main(int argc, char** argv) {
  uint32_t deviceID = 0;

  auto gatewayClient = std::make_shared<GatewayClient>();
  if(!gatewayClient->Connect(GATEWAY_ADDR, GATEWAY_PORT, GATEWAY_CA_FILE)) {
    std::cerr << "Cannot connect to the gateway" << std::endl;
    exit(1);
  }

  ConnectSvc connectSvc(gatewayClient->GetChannel());

  ConnectInfo connInfo;
  connInfo.set_ipaddr(DEVICE_IP);
  connInfo.set_port(DEVICE_PORT);
  connInfo.set_usessl(USE_SSL);

  Status status = connectSvc.Connect(connInfo, &deviceID);
  if(!status.ok()) {
    std::cerr << "Cannot connect to the device " << deviceID << std::endl;
    exit(1);
  }  

  std::vector<uint32_t> deviceIDs;
  deviceIDs.push_back(deviceID);

  RS485Svc rs485Svc(gatewayClient->GetChannel());
  if(!checkSlaves(rs485Svc, deviceID)) {
    connectSvc.Disconnect(deviceIDs);    
    exit(1);
  } 

  EventSvc eventSvc(gatewayClient->GetChannel());
  eventSvc.InitCodeMap(CODE_MAP_FILE);
  startMonitoring(eventSvc, deviceID);  

  APBZoneSvc zoneSvc(gatewayClient->GetChannel());

  testAPBZone(zoneSvc, deviceID, getSlaves());

  stopMonitoring(eventSvc, deviceID);
  restoreSlaves(rs485Svc, deviceID);
  connectSvc.Disconnect(deviceIDs);

  return 0;
}