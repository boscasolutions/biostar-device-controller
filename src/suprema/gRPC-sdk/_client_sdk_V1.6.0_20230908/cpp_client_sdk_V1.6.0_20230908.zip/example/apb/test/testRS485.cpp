#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <fstream>
#include <thread>
#include <chrono>
#include "RS485Svc.h"
#include "Menu.h"

using example::RS485Svc;
using example::Menu;

using gsdk::rs485::Mode;

RepeatedPtrField<SlaveDeviceInfo> s_Slaves;
RepeatedPtrField<SlaveDeviceInfo> s_RegisteredSlaves;
bool s_HasSlave = false;

RepeatedPtrField<SlaveDeviceInfo> getSlaves() {
  return s_Slaves;
}

bool checkSlaves(RS485Svc& rs485Svc, uint32_t deviceID) {
  s_HasSlave = false;

  RS485Config config;
  Status status = rs485Svc.GetConfig(deviceID, &config);
  if(!status.ok()) {
    return false;
  }

  bool hasMasterChannel = false;

  for(int i = 0; i < config.channels().size(); i++) {
    if(config.channels()[i].mode() == Mode::MASTER) {
      hasMasterChannel = true;
      break;
    }
  }

  if(!hasMasterChannel) {
    std::cout << "!! Only a master device can have slave devices. Skip the test." << std::endl;
    return false;
  }

  status = rs485Svc.SearchSlave(deviceID, &s_Slaves);
  if(!status.ok() || s_Slaves.size() == 0) {
    std::cout << "!! No slave device is configured. Configure and wire the slave devices first." << std::endl;
    return false;
  }
  Menu::PrintList<SlaveDeviceInfo>("Found Slaves:", s_Slaves);

  rs485Svc.GetSlave(deviceID, &s_RegisteredSlaves);
  Menu::PrintList<SlaveDeviceInfo>("Registered Slaves:", s_RegisteredSlaves);

  if(s_RegisteredSlaves.size() == 0) {
    rs485Svc.SetSlave(deviceID, s_Slaves);
  }

  for(int i = 0; i < 10; i++) {
    RepeatedPtrField<SlaveDeviceInfo> newSlaves;
    rs485Svc.SearchSlave(deviceID, &newSlaves);

    if(newSlaves[0].connected()) {
      break;
    }

    std::cout << "Waiting for the slave to be connected " << i << "..." << std::endl;;
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
  }

  s_HasSlave = true;
  return true; 
}

void restoreSlaves(RS485Svc& rs485Svc, uint32_t deviceID) {
  if(s_HasSlave) {
    rs485Svc.SetSlave(deviceID, s_RegisteredSlaves);
  }
}

