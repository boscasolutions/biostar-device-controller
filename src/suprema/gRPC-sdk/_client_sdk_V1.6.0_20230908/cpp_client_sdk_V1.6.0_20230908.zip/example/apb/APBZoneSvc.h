#ifndef __APBZONE_SVC__H__
#define __APBZONE_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "apb_zone.grpc.pb.h"
#include "zone.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::apb_zone::APBZone;
using gsdk::apb_zone::ZoneInfo;
using gsdk::zone::ZoneStatus;

using google::protobuf::RepeatedPtrField;

namespace example {
  class APBZoneSvc {
  public:
    APBZoneSvc(std::shared_ptr<Channel> channel)
        : stub_(APBZone::NewStub(channel)) {}

    Status Get(uint32_t deviceID, RepeatedPtrField<ZoneInfo>* zones);
    Status GetStatus(uint32_t deviceID, RepeatedPtrField<ZoneStatus>* zoneStatus);
    Status Add(uint32_t deviceID, RepeatedPtrField<ZoneInfo>& zones);
    Status DeleteAll(uint32_t deviceID);
    Status ClearAll(uint32_t deviceID, uint32_t zoneID);

  private:
    std::unique_ptr<APBZone::Stub> stub_;
  };
}

#endif