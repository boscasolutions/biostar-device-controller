#ifndef __GRPC_CLIENT__H__
#define __GRPC_CLIENT__H__

#include <string>
#include <grpcpp/grpcpp.h>

using grpc::Channel;

namespace example {
  class GrpcClient {
  public:
    GrpcClient() {}
    virtual ~GrpcClient() {}

    std::shared_ptr<Channel> GetChannel() {
      return channel_;
    } 

  protected:
    std::shared_ptr<Channel> channel_;
  };
}

#endif