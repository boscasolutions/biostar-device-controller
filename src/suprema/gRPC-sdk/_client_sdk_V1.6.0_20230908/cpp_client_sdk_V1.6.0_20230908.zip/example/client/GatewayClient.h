#ifndef __GATEWAY_CLIENT__H__
#define __GATEWAY_CLIENT__H__

#include <string>
#include "GrpcClient.h"

namespace example {
  class GatewayClient : public GrpcClient {
  public:    
    GatewayClient() {}
    ~GatewayClient() {}

    bool Connect(std::string ipAddr, int port, std::string caFile);
  };
}

#endif