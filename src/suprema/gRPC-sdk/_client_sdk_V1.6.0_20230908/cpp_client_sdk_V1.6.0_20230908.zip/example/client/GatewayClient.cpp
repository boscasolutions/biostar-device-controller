#include <sstream>
#include <fstream>
#include <grpcpp/grpcpp.h>
#include "GatewayClient.h"

namespace example {
  bool GatewayClient::Connect(std::string ipAddr, int port, std::string caFile) {
    std::ifstream certFile(caFile);
    std::stringstream certBuf;
    certBuf << certFile.rdbuf();
    
    grpc::SslCredentialsOptions sslOpts;
    sslOpts.pem_root_certs = certBuf.str();
    auto channelCreds = grpc::SslCredentials(sslOpts);

    std::stringstream gatewayAddr;
    gatewayAddr << ipAddr << ":" << port;

    channel_ = grpc::CreateChannel(gatewayAddr.str(),  channelCreds);

    return channel_ != NULL;
  }
}