#include <iostream>
#include "RS485Svc.h"

using grpc::ClientContext;

using gsdk::rs485::GetConfigRequest;
using gsdk::rs485::GetConfigResponse;

using gsdk::rs485::SetConfigRequest;
using gsdk::rs485::SetConfigResponse;

using gsdk::rs485::SearchDeviceRequest;
using gsdk::rs485::SearchDeviceResponse;

using gsdk::rs485::GetDeviceRequest;
using gsdk::rs485::GetDeviceResponse;

using gsdk::rs485::SetDeviceRequest;
using gsdk::rs485::SetDeviceResponse;

namespace example {

	Status RS485Svc::GetConfig(uint32_t deviceID, RS485Config* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the rs485 config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}	

	Status RS485Svc::SetConfig(uint32_t deviceID, RS485Config& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
    *request.mutable_config() = config;

		SetConfigResponse response;

		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the rs485 config: " << status.error_message() << std::endl;
		}

		return status;
	}

  Status RS485Svc::SearchSlave(uint32_t deviceID, RepeatedPtrField<SlaveDeviceInfo>* slaves) {
    SearchDeviceRequest request;
    request.set_deviceid(deviceID);

    SearchDeviceResponse response;
    ClientContext context;

    Status status = stub_->SearchDevice(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot search slaves: " << status.error_message() << std::endl;
      return status;
    }

    *slaves = response.slaveinfos();

    return status;
  }  	  

  Status RS485Svc::GetSlave(uint32_t deviceID, RepeatedPtrField<SlaveDeviceInfo>* slaves) {
    GetDeviceRequest request;
    request.set_deviceid(deviceID);

    GetDeviceResponse response;
    ClientContext context;

    Status status = stub_->GetDevice(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get slaves: " << status.error_message() << std::endl;
      return status;
    }

    *slaves = response.slaveinfos();

    return status;
  }  	  

  Status RS485Svc::SetSlave(uint32_t deviceID, RepeatedPtrField<SlaveDeviceInfo>& slaves) {
    SetDeviceRequest request;
    request.set_deviceid(deviceID);
    *request.mutable_slaveinfos() = slaves;

    SetDeviceResponse response;
    ClientContext context;

    Status status = stub_->SetDevice(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot set slaves: " << status.error_message() << std::endl;
    }

    return status;
  }  	  


}