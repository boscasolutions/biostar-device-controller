#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "WiegandSvc.h"
#include "Menu.h"
#include "wiegand.grpc.pb.h"

using example::WiegandSvc;
using example::Menu;

using gsdk::wiegand::WiegandConfig;
using gsdk::wiegand::WiegandFormat;
using gsdk::wiegand::ParityField;
using gsdk::wiegand::WiegandParity;
using gsdk::wiegand::WiegandMode;
using gsdk::wiegand::WiegandOutType;

void test26bit(WiegandSvc& svc, uint32_t deviceID);
void test37bit(WiegandSvc& svc, uint32_t deviceID);

void testConfig(WiegandSvc& svc, uint32_t deviceID) {
  // Backup the original configuration
  WiegandConfig origConfig;
  Status status = svc.GetConfig(deviceID, &origConfig);
  if (!status.ok()) {
	  return;
  }
  std::cout << std::endl << "Original Wiegand Config: " << std::endl << origConfig.ShortDebugString() << std::endl << std::endl;

  std::cout << std::endl << "===== Wiegand Config Test =====" << std::endl << std::endl;
  test26bit(svc, deviceID);
  test37bit(svc, deviceID);

  // Restore the original configuration
  status = svc.SetConfig(deviceID, origConfig);
  if (!status.ok()) {
	  return;
  }
}

// 26 bit standard
// FC: 01 1111 1110 0000 0000 0000 0000 : 0x01fe0000
// ID: 00 0000 0001 1111 1111 1111 1110 : 0x0001fffe
// EP: 01 1111 1111 1110 0000 0000 0000 : 0x01ffe000, Pos 0, Type: Even
// OP: 00 0000 0000 0001 1111 1111 1110 : 0x00001ffe, Pos 25, Type: Odd 

void test26bit(WiegandSvc& svc, uint32_t deviceID) {
  WiegandFormat default26bit;
  default26bit.set_length(26);
  *default26bit.add_idfields() = {0, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0}; // Facility Code
  *default26bit.add_idfields() = {0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0}; // ID

  ParityField evenParity;
  evenParity.set_paritypos(0);
  evenParity.set_paritytype(WiegandParity::WIEGAND_PARITY_EVEN);
  evenParity.set_data({0, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0});

  ParityField oddParity;
  oddParity.set_paritypos(25);
  oddParity.set_paritytype(WiegandParity::WIEGAND_PARITY_ODD);
  oddParity.set_data({0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0});

  *default26bit.add_parityfields() = evenParity;
  *default26bit.add_parityfields() = oddParity;

  WiegandConfig config;
  config.set_mode(WiegandMode::WIEGAND_IN_ONLY);
  config.set_outpulsewidth(40);
  config.set_outpulseinterval(10000);
  *config.add_formats() = default26bit;
  config.set_usewieganduserid(WiegandOutType::WIEGAND_OUT_USER_ID);

  Status status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return;
  }

  WiegandConfig newConfig;
  status = svc.GetConfig(deviceID, &newConfig);
  if (!status.ok()) {
	  return;
  }
  std::cout << std::endl << ">>> Wiegand Config with Standard 26bit Format: " << std::endl << newConfig.ShortDebugString() << std::endl << std::endl;
}

// 37 bit HID
// FC: 0 1111 1111 1111 1111 0000 0000 0000 0000 0000 : 0x0ffff00000
// ID: 0 0000 0000 0000 0000 1111 1111 1111 1111 1110 : 0x00000ffffe
// EP: 0 1111 1111 1111 1111 1100 0000 0000 0000 0000 : 0x0ffffc0000, Pos 0, Type: Even
// OP: 0 0000 0000 0000 0000 0111 1111 1111 1111 1110 : 0x000007fffe, Pos 36, Type: Odd 

void test37bit(WiegandSvc& svc, uint32_t deviceID) {
  WiegandFormat hid37bitFormat;
  hid37bitFormat.set_length(37);
  *hid37bitFormat.add_idfields() = {0, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0}; // Facility Code
  *hid37bitFormat.add_idfields() = {0, 0, 0, 0, 0, /**/ 0, 0 ,0 ,0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0}; // ID

  ParityField evenParity;
  evenParity.set_paritypos(0);
  evenParity.set_paritytype(WiegandParity::WIEGAND_PARITY_EVEN);
  evenParity.set_data({0, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 0, 0, 0});

  ParityField oddParity;
  oddParity.set_paritypos(36);
  oddParity.set_paritytype(WiegandParity::WIEGAND_PARITY_ODD);
  oddParity.set_data({0, 0, 0, 0, 0, /**/ 0, 0 ,0 ,0, 0, 0, 0, 0, /**/ 0, 0, 0, 0, 0, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 1, /**/ 1, 1, 1, 1, 1, 1, 1, 0});

  *hid37bitFormat.add_parityfields() = evenParity;
  *hid37bitFormat.add_parityfields() = oddParity;

  WiegandConfig config;
  config.set_mode(WiegandMode::WIEGAND_IN_ONLY);
  config.set_outpulsewidth(40);
  config.set_outpulseinterval(10000);
  *config.add_formats() = hid37bitFormat;
  config.set_usewieganduserid(WiegandOutType::WIEGAND_OUT_USER_ID);

  Status status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return;
  }

  WiegandConfig newConfig;
  status = svc.GetConfig(deviceID, &newConfig);
  if (!status.ok()) {
	  return;
  }
  std::cout << std::endl << ">>> Wiegand Config with HID 37bit Format: " << std::endl << newConfig.ShortDebugString() << std::endl << std::endl;
}