#ifndef __WIEGAND_SVC__H__
#define __WIEGAND_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>

#include "wiegand.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::wiegand::Wiegand;
using gsdk::wiegand::WiegandConfig;

namespace example {
	class WiegandSvc {
	public:
		WiegandSvc(std::shared_ptr<Channel> channel)
			: stub_(Wiegand::NewStub(channel)) {}

		Status GetConfig(uint32_t deviceID, WiegandConfig* config);
		Status SetConfig(uint32_t deviceID, WiegandConfig& config);

	private:
		std::unique_ptr<Wiegand::Stub> stub_;
	};
}

#endif
