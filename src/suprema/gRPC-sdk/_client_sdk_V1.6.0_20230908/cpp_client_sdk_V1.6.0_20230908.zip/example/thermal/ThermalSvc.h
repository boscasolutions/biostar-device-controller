#ifndef __THERMAL_SVC__H__
#define __THERMAL_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "thermal.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::thermal::Thermal;
using gsdk::thermal::ThermalConfig;
using gsdk::thermal::TemperatureLog;

using google::protobuf::RepeatedPtrField;

namespace example {
	class ThermalSvc {
	public:
		ThermalSvc(std::shared_ptr<Channel> channel)
			: stub_(Thermal::NewStub(channel)) {}

		Status GetConfig(uint32_t deviceID, ThermalConfig* config);
		Status SetConfig(uint32_t deviceID, ThermalConfig& config);
    Status GetTemperatureLog(uint32_t deviceID, int startEventID, int maxNumOfLog, RepeatedPtrField<TemperatureLog>* events);

	private:
		std::unique_ptr<Thermal::Stub> stub_;
	};
}

#endif
