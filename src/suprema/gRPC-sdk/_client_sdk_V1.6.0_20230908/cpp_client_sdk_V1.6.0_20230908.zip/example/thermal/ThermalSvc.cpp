#include <iostream>
#include "ThermalSvc.h"

using grpc::ClientContext;

using gsdk::thermal::GetConfigRequest;
using gsdk::thermal::GetConfigResponse;

using gsdk::thermal::SetConfigRequest;
using gsdk::thermal::SetConfigResponse;

using gsdk::thermal::GetTemperatureLogRequest;
using gsdk::thermal::GetTemperatureLogResponse;

namespace example {

	Status ThermalSvc::GetConfig(uint32_t deviceID, ThermalConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the thermal config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}	

	Status ThermalSvc::SetConfig(uint32_t deviceID, ThermalConfig& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
    *request.mutable_config() = config;

		SetConfigResponse response;

		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the thermal config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}	  

  Status ThermalSvc::GetTemperatureLog(uint32_t deviceID, int startEventID, int maxNumOfLog, RepeatedPtrField<TemperatureLog>* events) {
    GetTemperatureLogRequest request;
    request.set_deviceid(deviceID);
    request.set_starteventid(startEventID);
    request.set_maxnumoflog(maxNumOfLog);

    GetTemperatureLogResponse response;

    ClientContext context;

    Status status = stub_->GetTemperatureLog(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get temperature log events: " << status.error_message() << std::endl;
      return status;
    }

    *events = response.temperatureevents();

    return status;
  }  
}