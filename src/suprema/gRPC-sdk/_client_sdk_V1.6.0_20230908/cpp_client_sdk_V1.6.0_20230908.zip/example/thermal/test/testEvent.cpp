#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <thread>
#include "EventSvc.h"
#include "ThermalSvc.h"

using grpc::ClientContext;
using example::EventSvc;
using example::ThermalSvc;

std::shared_ptr<ClientContext> s_Context;
std::thread s_MonitoringThread;
const int EVENT_QUEUE_SIZE = 16;

int s_FirstEventID = 0;

void handleEvent(std::unique_ptr<ClientReader<EventLog>> eventReader);
void printEvent(EventSvc& svc, TemperatureLog& event);

void startMonitoring(EventSvc& svc, uint32_t deviceID) {
  Status status = svc.EnableMonitoring(deviceID);

  if (!status.ok()) {
	  return;
  }

	s_Context = std::make_shared<ClientContext>();
	auto eventReader(svc.Subscribe(s_Context.get(), EVENT_QUEUE_SIZE));

	s_MonitoringThread = std::thread(handleEvent, std::move(eventReader));
}


void stopMonitoring(EventSvc& svc, uint32_t deviceID) {
  s_Context->TryCancel();
	s_MonitoringThread.join();
  svc.DisableMonitoring(deviceID);  
}


void handleEvent(std::unique_ptr<ClientReader<EventLog>> eventReader) {
	EventLog realtimeEvent;

	while (eventReader->Read(&realtimeEvent)) {
		if (s_FirstEventID == 0) {
			s_FirstEventID = realtimeEvent.id();
		}

		std::cout << "[EVENT] " << realtimeEvent.ShortDebugString() << std::endl;
	}

	std::cout << "Monitoring thread is stopped" << std::endl;

	eventReader->Finish();
}

void testEvent(ThermalSvc& thermalSvc, EventSvc& eventSvc, uint32_t deviceID) {
  std::cout << std::endl << "===== Log Events with Temperature =====" << std::endl << std::endl;

  RepeatedPtrField<TemperatureLog> events;
  Status status = thermalSvc.GetTemperatureLog(deviceID, s_FirstEventID, 0, &events);

  if (!status.ok()) {
	  return;
  }

  for(int i = 0; i < events.size(); i++) {
    printEvent(eventSvc, events[i]);
  }  
}

void printEvent(EventSvc& eventSvc, TemperatureLog& event) {
	time_t eventTime = (time_t)event.timestamp();
  long userID = strtoul(event.userid().c_str(), NULL, 0);

  if(userID == 0 || userID == 0xffffffff) {// no user iD
    std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Device " << event.deviceid() << ", " << eventSvc.GetEventString(event.eventcode(), event.subcode()) << ", Temperature " << event.temperature() << std::endl;  
  } else {
    std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Device " << event.deviceid() << ", User " << event.userid() << ", " << eventSvc.GetEventString(event.eventcode(), event.subcode()) << ", Temperature " << event.temperature() << std::endl;
  }
}

