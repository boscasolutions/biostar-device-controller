#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "ThermalSvc.h"
#include "Menu.h"

using example::ThermalSvc;
using example::Menu;

void testConfig(ThermalSvc& svc, uint32_t deviceID, ThermalConfig& config) {
  std::cout << std::endl << "===== Test for ThermalConfig =====" << std::endl << std::endl;

  // Backup the original configuration
  ThermalConfig origConfig;
  origConfig.CopyFrom(config);

  // Set options for the test
  config.set_audittemperature(true);
  config.set_checkmode(gsdk::thermal::HARD);

  // (1) Set check order to AFTER_AUTH
  config.set_checkorder(gsdk::thermal::AFTER_AUTH);
  Status status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return;
  }

  std::cout << "(1) The Check Order is set to AFTER_AUTH. The device will measure the temperature only after successful authentication. Try to authenticate faces." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");

  // (2) Set check order to BEFORE_AUTH
  config.set_checkorder(gsdk::thermal::BEFORE_AUTH);
  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return;
  }

  std::cout << "(2) The Check Order is set to BEFORE_AUTH. The device will try to authenticate a user only when the user's temperature is within the threshold. Try to authenticate faces." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");  

  // (3) Set check order to WITHOUT_AUTH
  config.set_checkorder(gsdk::thermal::WITHOUT_AUTH);
  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return;
  }

  std::cout << "(3) The Check Order is set to WITHOUT_AUTH. Any user whose temperature is within the threshold will be allowed to access. Try to authenticate faces." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");    

  // (4) Set check order to AFTER_AUTH with too low threshold
  config.set_checkorder(gsdk::thermal::AFTER_AUTH);
  config.set_temperaturethresholdhigh(3500);
  config.set_temperaturethresholdlow(3000);
  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return;
  }

  std::cout << "(4) To reproduce the case of high temperature, the Check Order is set to AFTER_AUTH with the threshold of 35 degree Celsius. Most temperature check will fail, now. Try to authenticate faces." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");    

  // Restore the original configuration   
  svc.SetConfig(deviceID, origConfig);
}

