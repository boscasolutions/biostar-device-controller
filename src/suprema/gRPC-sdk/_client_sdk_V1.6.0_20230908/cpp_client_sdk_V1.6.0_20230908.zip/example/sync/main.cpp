#include <string>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <iostream>
#include <grpcpp/grpcpp.h>
#include <stdlib.h>
#include "GatewayClient.h"
#include "ConnectSvc.h"
#include "CardSvc.h"
#include "UserSvc.h"
#include "EventSvc.h"
#include "TestConfig.h"
#include "TestMenu.h"
#include "DeviceMgr.h"
#include "EventMgr.h"
#include "Menu.h"

using grpc::Channel;
using grpc::Status;

using example::GatewayClient;
using example::ConnectSvc;
using example::CardSvc;
using example::UserSvc;
using example::EventSvc;
using example::TestConfig;
using example::TestMenu;
using example::DeviceMgr;
using example::EventMgr;
using example::Menu;

using google::protobuf::RepeatedPtrField;

const std::string GATEWAY_CA_FILE = "../cert/gateway/ca.crt";
const std::string GATEWAY_ADDR = "192.168.0.2";
const int GATEWAY_PORT = 4000;

const std::string CONFIG_FILE = "./sync_config.json";
const std::string CODE_MAP_FILE = "./event_code.json";

int main(int argc, char** argv) {
  auto gatewayClient = std::make_shared<GatewayClient>();
  if(!gatewayClient->Connect(GATEWAY_ADDR, GATEWAY_PORT, GATEWAY_CA_FILE)) {
    std::cerr << "Cannot connect to the gateway" << std::endl;
    exit(1);
  }

  auto connectSvc = std::make_shared<ConnectSvc>(gatewayClient->GetChannel());
  auto cardSvc = std::make_shared<CardSvc>(gatewayClient->GetChannel());
  auto userSvc = std::make_shared<UserSvc>(gatewayClient->GetChannel());
  auto eventSvc = std::make_shared<EventSvc>(gatewayClient->GetChannel());
  eventSvc->InitCodeMap(CODE_MAP_FILE);

  auto testConfig = std::make_shared<TestConfig>();
  testConfig->Read(CONFIG_FILE);

  auto eventMgr = std::make_shared<EventMgr>(eventSvc, testConfig);
  auto deviceMgr = std::make_shared<DeviceMgr>(connectSvc, testConfig);
  auto userMgr = std::make_shared<UserMgr>(userSvc, cardSvc, testConfig, deviceMgr, eventMgr);

	std::cout << "Trying to connect to the devices..." << std::endl;

  eventMgr->HandleEvent(UserMgr::SyncUser, userMgr.get());
  deviceMgr->HandleConnection(EventMgr::HandleConnection, eventMgr.get());
  deviceMgr->ConnectToDevices();

  Menu::PressEnter(">>> Press ENTER to show the test menu\n");

  TestMenu testMenu(deviceMgr, eventMgr, userMgr, testConfig);
  testMenu.Show();

  eventMgr->StopHandleEvent();
  deviceMgr->DeleteConnection();
  
  return 0;
}