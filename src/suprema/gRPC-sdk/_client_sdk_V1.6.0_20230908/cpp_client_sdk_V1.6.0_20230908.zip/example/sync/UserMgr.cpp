#include <algorithm>
#include "card.grpc.pb.h"
#include "UserMgr.h"
#include "ErrSvc.h"

using gsdk::card::CSNCardData;
using example::ErrSvc;

const int BS2_EVENT_USER_ENROLL_SUCCESS = 0x2000;
const int BS2_EVENT_USER_UPDATE_SUCCESS = 0x2200;
const int BS2_EVENT_USER_DELETE_SUCCESS = 0x2400;
const int BS2_EVENT_USER_DELETE_ALL_SUCCESS = 0x2600;    

namespace example {
  void UserMgr::EnrollUser(std::string userID) {
    uint32_t enrollDeviceID = testConfig_->GetConfigData()["enroll_device"]["device_id"];

    std::cout << ">>> Place a unregistered CSN card on the device " << enrollDeviceID << "..." << std::endl;

    CardData cardData;
    Status status = cardSvc_->Scan(enrollDeviceID, &cardData);
    if (!status.ok()) {
      return;
    }

    CSNCardData csnData = cardData.csncarddata();

    RepeatedPtrField<UserInfo> userInfos;
    UserInfo userInfo;
    *userInfo.mutable_hdr()->mutable_id() = userID;
    userInfo.mutable_hdr()->set_numofcard(1);
    userInfo.mutable_cards()->Add(std::forward<CSNCardData>(csnData));

    userInfos.Add(std::forward<UserInfo>(userInfo));

    userSvc_->Enroll(enrollDeviceID, userInfos);
  }

  void UserMgr::DeleteUser(std::string userID) {
    uint32_t enrollDeviceID = testConfig_->GetConfigData()["enroll_device"]["device_id"];

    std::vector<std::string> userIDs;
    userIDs.push_back(userID);

    userSvc_->Delete(enrollDeviceID, userIDs);
  }

  void UserMgr::GetNewUser(uint32_t deviceID, RepeatedPtrField<UserInfo>* userInfos) {
    if(enrolledIDs_.size() == 0) {
      std::cout << "No new user" << std::endl;
      return;
    }

    userSvc_->GetUser(deviceID, enrolledIDs_, userInfos);
  }

  void UserMgr::SyncUser(void* arg, EventLog& eventLog) {
    auto userMgr = static_cast<UserMgr*>(arg);

    std::cout << "[EVENT] ";
    userMgr->eventMgr_->PrintEvent(eventLog);

    uint32_t enrollDeviceID = userMgr->testConfig_->GetConfigData()["enroll_device"]["device_id"];

    // Handle only the events of the enrollment device
    if(eventLog.deviceid() != enrollDeviceID) {
      return;
    }

    std::vector<uint32_t> connectedIDs;
    userMgr->deviceMgr_->GetConnectedDevices(false, connectedIDs);
    std::vector<uint32_t> targetDeviceIDs;
    userMgr->testConfig_->GetTargetDeviceIDs(connectedIDs, targetDeviceIDs);

    if(targetDeviceIDs.size() == 0) {
      std::cout << "No device to sync" << std::endl;
      return;
    }

    if(eventLog.eventcode() == BS2_EVENT_USER_ENROLL_SUCCESS || eventLog.eventcode() == BS2_EVENT_USER_UPDATE_SUCCESS) {
      std::cout <<  "Trying to synchronize the enrolled user " << eventLog.userid() << "..." << std::endl;

      std::vector<std::string> userIDs;
      userIDs.push_back(eventLog.userid());

      RepeatedPtrField<UserInfo> newUserInfos;
      userMgr->userSvc_->GetUser(eventLog.deviceid(), userIDs, &newUserInfos);

      userMgr->userSvc_->EnrollMulti(targetDeviceIDs, newUserInfos);

      userMgr->enrolledIDs_.push_back(eventLog.userid());

      // Generate a MultiErrorResponse 
      // It should fail since the users are duplicated.      
      // Dependent on grpc++_error_details lib
      /* Status status = userMgr->userSvc_->EnrollMulti(targetDeviceIDs, newUserInfos);
      MultiErrorResponse multiError;
      if(ErrSvc::GetMultiError(status, &multiError)) {
        std::cout << "Multi Error: " << multiError.ShortDebugString() << std::endl;
      } */
    } else if(eventLog.eventcode() == BS2_EVENT_USER_DELETE_SUCCESS) {
      std::cout <<  "Trying to synchronize the deleted user " << eventLog.userid() << "..." << std::endl;     

      std::vector<std::string> userIDs;
      userIDs.push_back(eventLog.userid()); 

      userMgr->userSvc_->DeleteMulti(targetDeviceIDs, userIDs);

      auto pos = std::find(userMgr->enrolledIDs_.begin(), userMgr->enrolledIDs_.end(), eventLog.userid());
      if(pos != userMgr->enrolledIDs_.end()) {
        userMgr->enrolledIDs_.erase(pos);
      }      
    }

  }
}