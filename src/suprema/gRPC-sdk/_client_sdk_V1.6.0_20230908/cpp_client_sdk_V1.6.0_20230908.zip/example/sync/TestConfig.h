#ifndef __TEST_CONFIG_H__
#define __TEST_CONFIG_H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <nlohmann/json.hpp>
#include "ConnectSvc.h"

using json = nlohmann::json;

namespace example {
  class TestConfig {
  public:
    TestConfig() {}

    void Read(std::string configFile);
    json GetConfigData() {
      return configData_;
    }

    void GetDeviceInfo(uint32_t deviceID, json* devInfo);

    void GetAsyncConnectInfo(RepeatedPtrField<AsyncConnectInfo>& connInfos);
    void GetTargetDeviceIDs(std::vector<uint32_t>& connectedIDs, std::vector<uint32_t>& targetDeviceIDs);

    void UpdateLastEventID(uint32_t deviceID, int lastEventID);

  private:
    std::string configFile_;
    json configData_;
  };
}

#endif