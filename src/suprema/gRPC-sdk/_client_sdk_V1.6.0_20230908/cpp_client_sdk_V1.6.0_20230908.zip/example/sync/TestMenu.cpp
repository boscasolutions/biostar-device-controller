#include "TestMenu.h"

const std::string DEFAULT_USER_ID = "1234";
const int MAX_NEW_LOG = 16;

using example::MAX_NUM_OF_LOG;

namespace example {
  TestMenu::TestMenu(std::shared_ptr<DeviceMgr> deviceMgr, std::shared_ptr<EventMgr> eventMgr, std::shared_ptr<UserMgr> userMgr, std::shared_ptr<TestConfig> config) {
    deviceMgr_ = deviceMgr;
    eventMgr_ = eventMgr;
    userMgr_ = userMgr;
    testConfig_ = config;

    std::vector<std::shared_ptr<MenuItem>> menuItems;

    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"1", "Show test devices", ShowTestDevice, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"2", "Show new events", ShowNewEvent, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"3", "Show new users", ShowNewUser, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"4", "Enroll a user", EnrollUser, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"5", "Delete a user", DeleteUser, static_cast<void*>(this), false}));
    menuItems.push_back(std::make_shared<MenuItem>(MenuItem{"q", "Quit", NULL, NULL, true}));

    menu_  = std::make_unique<Menu>(menuItems);
  } 

  void TestMenu::Show() {
    menu_->Show("Test Menu");
  }

  void TestMenu::ShowTestDevice(void* arg) {
    auto testMenu = static_cast<TestMenu*>(arg);

    std::cout << "***** Test Configuration: " << std::endl << testMenu->testConfig_->GetConfigData().dump(2) << std::endl;
    
    std::vector<uint32_t> connectedIDs;
    testMenu->deviceMgr_->GetConnectedDevices(true, connectedIDs);

    std::cout << "***** Connected Devices: ";
    for(auto devID : connectedIDs) {
      std::cout << devID << " ";
    }
    std::cout << std::endl;
  }

  void TestMenu::ShowNewEvent(void* arg) {
    auto testMenu = static_cast<TestMenu*>(arg);

    std::vector<uint32_t> connectedIDs;
    testMenu->deviceMgr_->GetConnectedDevices(true, connectedIDs);

    for(auto devID : connectedIDs) {
      json devInfo;
      testMenu->testConfig_->GetDeviceInfo(devID, &devInfo);

      if(devInfo.empty()) {
        std::cout << "Device " << devID << " is not in the configuration file" << std::endl;
        continue;
      }

      std::cout << "Read new event logs from device " << devID << "..." << std::endl;
      RepeatedPtrField<EventLog> eventLogs;
      testMenu->eventMgr_->ReadNewLog(devInfo, MAX_NUM_OF_LOG, &eventLogs);
      std::cout << "Read " << eventLogs.size() << " event logs" << std::endl;

      int numOfLog = eventLogs.size();
      if(numOfLog > MAX_NEW_LOG) {
        numOfLog = MAX_NEW_LOG;
      }

      if(numOfLog > 0) {
        std::cout << "Show the last " << numOfLog << " events..." << std::endl;
        for(int i = 0; i < numOfLog; i++) {
          testMenu->eventMgr_->PrintEvent(eventLogs[numOfLog - i - 1]);
        }
      }
    }
  }

  void TestMenu::ShowNewUser(void* arg) {
    auto testMenu = static_cast<TestMenu*>(arg);

    std::vector<uint32_t> connectedIDs;
    testMenu->deviceMgr_->GetConnectedDevices(true, connectedIDs);

    for(auto devID : connectedIDs) {
      std::cout << "Read new users from device " << devID << "..." << std::endl;

      RepeatedPtrField<UserInfo> userInfos;
      testMenu->userMgr_->GetNewUser(devID, &userInfos);

      for(auto userInfo : userInfos) {
        std::cout << userInfo.ShortDebugString() << std::endl;
      }
    }
  }

  void TestMenu::EnrollUser(void* arg) {
    auto testMenu = static_cast<TestMenu*>(arg);
    testMenu->userMgr_->EnrollUser(testMenu->GetUserID());
  }

  void TestMenu::DeleteUser(void* arg) {
    auto testMenu = static_cast<TestMenu*>(arg);
    testMenu->userMgr_->DeleteUser(testMenu->GetUserID());
  }

  std::string TestMenu::GetUserID() {
    std::vector<std::shared_ptr<InputItem>> inputItems;
  
    inputItems.push_back(std::make_shared<InputItem>(InputItem{"Enter the user ID", DEFAULT_USER_ID}));

    std::vector<std::string> values;
    Menu::GetUserInput(inputItems, values);

    return values[0];
  }
}

