#include <fstream>
#include "TestConfig.h"

namespace example {
  void TestConfig::Read(std::string configFile) {
    configFile_ = configFile;

    std::ifstream config(configFile);
    config >> configData_;
  }

  void TestConfig::UpdateLastEventID(uint32_t deviceID, int lastEventID) {
    bool updated = false;

    if(deviceID == configData_["enroll_device"]["device_id"]) {
      configData_["enroll_device"]["last_event_id"] = lastEventID;
      updated = true;
    } else {
      for(auto& dev : configData_["devices"]) {
        if(deviceID == dev["device_id"]) {
          dev["last_event_id"] = lastEventID;
          updated = true;
          break;
        }
      }      
    }    

    if(updated) {
      std::ofstream config(configFile_);
      config << configData_.dump(2);
    }
  }

  void TestConfig::GetAsyncConnectInfo(RepeatedPtrField<AsyncConnectInfo>& connInfos) {
    AsyncConnectInfo asyncConnInfo;
    asyncConnInfo.set_deviceid(configData_["enroll_device"]["device_id"]);
    asyncConnInfo.set_ipaddr(configData_["enroll_device"]["ip_addr"]);
    asyncConnInfo.set_port(configData_["enroll_device"]["port"]);
    asyncConnInfo.set_usessl(configData_["enroll_device"]["use_ssl"]);

    connInfos.Add(std::forward<AsyncConnectInfo>(asyncConnInfo));

    for(auto dev : configData_["devices"]) {
      asyncConnInfo.set_deviceid(dev["device_id"]);
      asyncConnInfo.set_ipaddr(dev["ip_addr"]);
      asyncConnInfo.set_port(dev["port"]);
      asyncConnInfo.set_usessl(dev["use_ssl"]);

      connInfos.Add(std::forward<AsyncConnectInfo>(asyncConnInfo));
    }
  }

  void TestConfig::GetTargetDeviceIDs(std::vector<uint32_t>& connectedIDs, std::vector<uint32_t>& targetDeviceIDs) {
    for(uint32_t devID : connectedIDs) {
      for(auto dev : configData_["devices"]) {
        if(devID == dev["device_id"]) {
          targetDeviceIDs.push_back(devID);
          break;
        }
      }
    }
  }

  void TestConfig::GetDeviceInfo(uint32_t deviceID, json* devInfo) {
    if(deviceID == configData_["enroll_device"]["device_id"]) {
      *devInfo = configData_["enroll_device"];
      return;
    } else {
      for(auto dev : configData_["devices"]) {
        if(deviceID == dev["device_id"]) {
          *devInfo = dev;
          return;
        }
      }      
    }
  }
}