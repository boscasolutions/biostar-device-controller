#include <sstream>
#include <algorithm>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>
#include "connect.grpc.pb.h"
#include "DeviceMgr.h"

using grpc::Status;
using google::protobuf::RepeatedPtrField;

const int STATUS_QUEUE_SIZE = 16;

namespace example {
  void DeviceMgr::ConnectToDevices() {
    RepeatedPtrField<AsyncConnectInfo> connInfos;

    testConfig_->GetAsyncConnectInfo(connInfos);
    
    if(connInfos.size() == 0) {
      std::cout << "No device to connect" << std::endl;
      return;
    }

    std::cout << "Adding async connections..." << std::endl;
    connectSvc_->AddAsyncConnection(connInfos);
  }

  void DeviceMgr::GetConnectedDevices(bool refreshList, std::vector<uint32_t>& deviceIDs) {
    RepeatedPtrField<DeviceInfo> deviceInfos;
    Status status = connectSvc_->GetDeviceList(&deviceInfos);

    if(!status.ok()) {
      return;
    }

    for(auto dev : deviceInfos) {
      if(dev.status() == gsdk::connect::Status::TCP_CONNECTED || dev.status() == gsdk::connect::Status::TLS_CONNECTED) {
        deviceIDs.push_back(dev.deviceid());
      }
    }
  }

  void DeviceMgr::HandleConnection(ConnectionCallback callback, void* arg) {
    connCallback_ = callback;
    callbackArg_ = arg;
    statusReader_ = connectSvc_->Subscribe(&subContext_, STATUS_QUEUE_SIZE);
    subThread_ = std::thread(&DeviceMgr::ReceiveStatus, this);
  }

  void DeviceMgr::DeleteConnection() {
    if(connectedIDs_.size() > 0) {
      connectSvc_->DeleteAsyncConnection(connectedIDs_);
    }

    subContext_.TryCancel();
    subThread_.join();
  }


  void DeviceMgr::ReceiveStatus() {
    StatusChange devStatus;

    while(statusReader_->Read(&devStatus)) {
      if(devStatus.status() == gsdk::connect::Status::TCP_CONNECTED || devStatus.status() == gsdk::connect::Status::TLS_CONNECTED) {
        connectedIDs_.push_back(devStatus.deviceid());
        if(connCallback_ != NULL) {
          connCallback_(callbackArg_, devStatus.deviceid());
        }
      } else if(devStatus.status() != gsdk::connect::Status::DISCONNECTED) {
        auto pos = std::find(connectedIDs_.begin(), connectedIDs_.end(), devStatus.deviceid());
        if(pos != connectedIDs_.end()) {
          connectedIDs_.erase(pos);
        }
      }

      if(devStatus.status() != gsdk::connect::Status::TCP_NOT_ALLOWED && devStatus.status() != gsdk::connect::Status::TLS_NOT_ALLOWED) {
        std::cout << std::endl << "[STATUS] " << devStatus.ShortDebugString() << std::endl;
      }
    }  

    std::cout << "Subscribing thread is stopped" << std::endl;

    statusReader_->Finish();    
  }
}
