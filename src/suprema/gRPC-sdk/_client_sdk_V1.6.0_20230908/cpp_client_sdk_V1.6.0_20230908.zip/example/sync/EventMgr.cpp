#include <sstream>
#include <ctime>
#include <iomanip>
#include "EventMgr.h"

const int MONITORING_QUEUE_SIZE = 16;

namespace example {
  void EventMgr::HandleEvent(EventCallback callback, void* arg) {
    eventCallback_ = callback;
    callbackArg_ = arg;
    eventReader_ = eventSvc_->Subscribe(&monitoringContext_, MONITORING_QUEUE_SIZE);
    monitoringThread_ = std::thread(&EventMgr::ReceiveEvent, this);
  }

  void EventMgr::StopHandleEvent() {
    monitoringContext_.TryCancel();
    monitoringThread_.join();
  }

  void EventMgr::ReceiveEvent() {
    EventLog eventLog;

    while(eventReader_->Read(&eventLog)) {
      if(eventCallback_) {
        eventCallback_(callbackArg_, eventLog);
      } else {
        std::cout << "[EVENT] " << eventLog.ShortDebugString() << std::endl;
      }
    }  

    std::cout << "Monitoring thread is stopped" << std::endl;

    eventReader_->Finish();    
  }

  void EventMgr::PrintEvent(EventLog& event) {
	  time_t eventTime = (time_t)event.timestamp();
    std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Device " << event.deviceid() << ", User " << event.userid() << ", " << eventSvc_->GetEventString(event.eventcode(), event.subcode()) << std::endl;
  }

  void EventMgr::ReadNewLog(json devInfo, int maxNumOfLog, RepeatedPtrField<EventLog>* eventLogs) {
    int lastEventID = devInfo["last_event_id"];
    
    RepeatedPtrField<EventLog> newLogs;
    eventSvc_->GetLog(devInfo["device_id"], lastEventID + 1, maxNumOfLog, &newLogs);

    if(newLogs.size() > 0) {
      testConfig_->UpdateLastEventID(devInfo["device_id"], newLogs[newLogs.size() - 1].id());
    }

    *eventLogs = newLogs;
  }

  void EventMgr::HandleConnection(void* arg, uint32_t deviceID) {
    auto mgr = static_cast<EventMgr*>(arg);

    std::cout << "***** Device " << deviceID << " is connected" << std::endl;

    json dev;
    mgr->testConfig_->GetDeviceInfo(deviceID, &dev);

    if(dev.is_null()) {
      std::cout << "!!! Device " << deviceID << " not in the configuration file" << std::endl;
      return;
    } 

    RepeatedPtrField<EventLog> eventLogs;

    // read new logs
    while(true) {
      std::cout <<  "[" << deviceID << "] Reading log records starting from " << dev["last_event_id"] << "..." << std::endl;

      RepeatedPtrField<EventLog> newLogs;
      mgr->ReadNewLog(dev, MAX_NUM_OF_LOG, &newLogs);

      std::cout <<  "[" << deviceID << "] Read " << newLogs.size() << " events" << std::endl;

      eventLogs.MergeFrom(newLogs);

      if(newLogs.size() < MAX_NUM_OF_LOG) { // read the last log
        break;
      }
    } 

    // do something with the event logs
    // ...
    std::cout << "[" << deviceID << "] The total number of new events: " << eventLogs.size() << std::endl; 

    // enable real-time monitoring
    mgr->eventSvc_->EnableMonitoring(deviceID);
  }
}