#ifndef __DEVICE_MGR_H__
#define __DEVICE_MGR_H__

#include <stdint.h>
#include <thread>
#include "ConnectSvc.h"
#include "TestConfig.h"

using grpc::ClientReader;
using grpc::ClientContext;
using gsdk::connect::StatusChange;

using example::ConnectSvc;
using example::TestConfig;

namespace example {
  typedef void (*ConnectionCallback)(void* arg, uint32_t deviceID);

  class DeviceMgr {
  public:
    DeviceMgr(std::shared_ptr<ConnectSvc> connectSvc, std::shared_ptr<TestConfig> testConfig) {
      connectSvc_ = connectSvc;
      testConfig_ = testConfig;
    }

    void GetConnectedDevices(bool refreshList, std::vector<uint32_t>& deviceIDs);
    void ConnectToDevices();
    void HandleConnection(ConnectionCallback callback, void* arg);
    void DeleteConnection();

    void ReceiveStatus();

  private:
    std::shared_ptr<ConnectSvc> connectSvc_;
    std::shared_ptr<TestConfig> testConfig_;

    ClientContext subContext_;
    std::unique_ptr<ClientReader<StatusChange>> statusReader_;
    std::thread subThread_;    

    std::vector<uint32_t> connectedIDs_;
    ConnectionCallback connCallback_;
    void* callbackArg_;
  };
}

#endif