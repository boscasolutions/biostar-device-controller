#ifndef __TEST_MENU_H__
#define __TEST_MENU_H__

#include "Menu.h"
#include "TestConfig.h"
#include "UserMgr.h"
#include "DeviceMgr.h"
#include "EventMgr.h"

using example::TestConfig;
using example::UserMgr;
using example::DeviceMgr;
using example::EventMgr;

namespace example {
  class TestMenu {
  public:
		TestMenu(std::shared_ptr<DeviceMgr> deviceMgr, std::shared_ptr<EventMgr> eventMgr, std::shared_ptr<UserMgr> userMgr, std::shared_ptr<TestConfig> config);

    void Show();
    
    static void ShowTestDevice(void* arg);
    static void ShowNewEvent(void* arg);
    static void ShowNewUser(void* arg);
    static void EnrollUser(void* arg);
    static void DeleteUser(void* arg);

  private:
    std::string GetUserID();

    std::unique_ptr<Menu> menu_;

    std::shared_ptr<DeviceMgr> deviceMgr_;
    std::shared_ptr<EventMgr> eventMgr_;
    std::shared_ptr<UserMgr> userMgr_;
    std::shared_ptr<TestConfig> testConfig_;    
  };
}

#endif