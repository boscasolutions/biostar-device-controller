#ifndef __USER_MGR_H__
#define __USER_MGR_H__

#include <stdint.h>
#include "UserSvc.h"
#include "CardSvc.h"
#include "TestConfig.h"
#include "DeviceMgr.h"
#include "EventMgr.h"

using example::UserSvc;
using example::CardSvc;
using example::TestConfig;
using example::DeviceMgr;
using example::EventMgr;

namespace example {
  class UserMgr {
  public:
    UserMgr(std::shared_ptr<UserSvc> userSvc, std::shared_ptr<CardSvc> cardSvc, std::shared_ptr<TestConfig> testConfig, std::shared_ptr<DeviceMgr> deviceMgr, std::shared_ptr<EventMgr> eventMgr) {
      userSvc_ = userSvc;
      cardSvc_ = cardSvc;
      testConfig_ = testConfig;
      deviceMgr_ = deviceMgr;
      eventMgr_ = eventMgr;
    }

    void EnrollUser(std::string userID);
    void DeleteUser(std::string userID);
    void GetNewUser(uint32_t deviceID, RepeatedPtrField<UserInfo>* userInfos);

    static void SyncUser(void* arg, EventLog& eventLog);

  private:
    std::shared_ptr<UserSvc> userSvc_;
    std::shared_ptr<CardSvc> cardSvc_;
    std::shared_ptr<TestConfig> testConfig_;
    std::shared_ptr<DeviceMgr> deviceMgr_;
    std::shared_ptr<EventMgr> eventMgr_;

    std::vector<std::string> enrolledIDs_;
  };
}

#endif