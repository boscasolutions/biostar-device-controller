#ifndef __EVENT_MGR_H__
#define __EVENT_MGR_H__

#include <stdint.h>
#include <thread>
#include "EventSvc.h"
#include "TestConfig.h"

using example::EventSvc;
using example::TestConfig;

using grpc::ClientReader;
using grpc::ClientContext;

namespace example {
  const int MAX_NUM_OF_LOG = 16384;

  typedef void (*EventCallback)(void* arg, EventLog& eventLog);

  class EventMgr {
  public:
    EventMgr(std::shared_ptr<EventSvc> eventSvc, std::shared_ptr<TestConfig> testConfig) {
      eventSvc_ = eventSvc;
      testConfig_ = testConfig;
    }

    void HandleEvent(EventCallback callback, void* arg);
    void StopHandleEvent();
    void PrintEvent(EventLog& event); 
    void ReceiveEvent();

    static void HandleConnection(void* arg, uint32_t deviceID);

    void ReadNewLog(json devInfo, int maxNumOfLog, RepeatedPtrField<EventLog>* eventLogs);

  private:
    std::shared_ptr<EventSvc> eventSvc_;
    std::shared_ptr<TestConfig> testConfig_;

    ClientContext monitoringContext_;
    std::unique_ptr<ClientReader<EventLog>> eventReader_;
    std::thread monitoringThread_;  

    EventCallback eventCallback_;
    void* callbackArg_;
  };
}

#endif