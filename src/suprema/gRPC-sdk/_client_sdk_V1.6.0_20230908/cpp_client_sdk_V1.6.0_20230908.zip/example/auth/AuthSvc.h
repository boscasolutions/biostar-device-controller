#ifndef __AUTH_SVC__H__
#define __AUTH_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "auth.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::auth::Auth;
using gsdk::auth::AuthConfig;

namespace example {
	class AuthSvc {
	public:
		AuthSvc(std::shared_ptr<Channel> channel)
			: stub_(Auth::NewStub(channel)) {}

		Status GetConfig(uint32_t deviceID, AuthConfig* config);
		Status SetConfig(uint32_t deviceID, AuthConfig& config);

	private:
		std::unique_ptr<Auth::Stub> stub_;
	};
}

#endif
