#include <iostream>
#include "AuthSvc.h"

using grpc::ClientContext;

using gsdk::auth::GetConfigRequest;
using gsdk::auth::GetConfigResponse;

using gsdk::auth::SetConfigRequest;
using gsdk::auth::SetConfigResponse;

namespace example {

	Status AuthSvc::GetConfig(uint32_t deviceID, AuthConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the auth config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config();

		return status;
	}

	Status AuthSvc::SetConfig(uint32_t deviceID, AuthConfig& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
		*request.mutable_config() = config;

		SetConfigResponse response;

		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the auth config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}
}