#include <iostream>
#include "TNASvc.h"

using grpc::ClientContext;

using gsdk::tna::GetConfigRequest;
using gsdk::tna::GetConfigResponse;

using gsdk::tna::SetConfigRequest;
using gsdk::tna::SetConfigResponse;

using gsdk::tna::GetTNALogRequest;
using gsdk::tna::GetTNALogResponse;

namespace example {

	Status TNASvc::GetConfig(uint32_t deviceID, TNAConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the tna config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}	

	Status TNASvc::SetConfig(uint32_t deviceID, TNAConfig& config) {
		SetConfigRequest request;
		request.set_deviceid(deviceID);
    *request.mutable_config() = config;

		SetConfigResponse response;

		ClientContext context;

		Status status = stub_->SetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot set the tna config: " << status.error_message() << std::endl;
			return status;
		}

		return status;
	}	  

  Status TNASvc::GetTNALog(uint32_t deviceID, int startEventID, int maxNumOfLog, RepeatedPtrField<TNALog>* events) {
    GetTNALogRequest request;
    request.set_deviceid(deviceID);
    request.set_starteventid(startEventID);
    request.set_maxnumoflog(maxNumOfLog);

    GetTNALogResponse response;

    ClientContext context;

    Status status = stub_->GetTNALog(&context, request, &response);

    if(!status.ok()) {
      std::cerr << "Cannot get TNA log events: " << status.error_message() << std::endl;
      return status;
    }

    *events = response.tnaevents();

    return status;
  }  
}