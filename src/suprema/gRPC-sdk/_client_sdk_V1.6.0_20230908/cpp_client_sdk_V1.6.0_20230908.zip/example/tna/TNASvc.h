#ifndef __TNA_SVC__H__
#define __TNA_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include <google/protobuf/repeated_field.h>

#include "tna.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::tna::TNA;
using gsdk::tna::TNAConfig;
using gsdk::tna::TNALog;

using google::protobuf::RepeatedPtrField;

namespace example {
	class TNASvc {
	public:
		TNASvc(std::shared_ptr<Channel> channel)
			: stub_(TNA::NewStub(channel)) {}

		Status GetConfig(uint32_t deviceID, TNAConfig* config);
		Status SetConfig(uint32_t deviceID, TNAConfig& config);
    Status GetTNALog(uint32_t deviceID, int startEventID, int maxNumOfLog, RepeatedPtrField<TNALog>* events);

	private:
		std::unique_ptr<TNA::Stub> stub_;
	};
}

#endif
