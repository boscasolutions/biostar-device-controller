#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "TNASvc.h"
#include "Menu.h"

using example::TNASvc;
using example::Menu;

std::shared_ptr<TNAConfig> testConfig(TNASvc& svc, uint32_t deviceID) {
  // Backup the original configuration
  auto origConfig = std::make_shared<TNAConfig>();
  Status status = svc.GetConfig(deviceID, origConfig.get());
  if (!status.ok()) {
	  return nullptr;
  }

  std::cout << std::endl << "Original TNA Config: " << std::endl << origConfig.get()->ShortDebugString() << std::endl << std::endl;

  std::cout << std::endl << "===== Test for TNAConfig =====" << std::endl << std::endl;

  // (1) BY_USER
  TNAConfig config;
  config.set_mode(gsdk::tna::BY_USER);
	config.add_labels("In");
	config.add_labels("Out"); 
	config.add_labels("Scheduled In"); 
	config.add_labels("Fixed Out");

  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return nullptr;
  }  

  std::cout << "(1) The T&A mode is set to BY_USER(optional). You can select a T&A key before authentication. Try to authenticate after selecting a T&A key." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");

  // (2) IsRequired
  config.set_isrequired(true);

  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return nullptr;
  }   

  std::cout << "(2) The T&A mode is set to BY_USER(mandatory). Try to authenticate without selecting a T&A key." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");  

  // (3) LAST_CHOICE
  config.set_mode(gsdk::tna::LAST_CHOICE);

  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return nullptr;
  }   

  std::cout << "(3) The T&A mode is set to LAST_CHOICE. The T&A key selected by the previous user will be used. Try to authenticate multiple users." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");  

  // (4) BY_SCHEDULE
  config.set_mode(gsdk::tna::BY_SCHEDULE);
  config.add_schedules(0);
  config.add_schedules(0);
  config.add_schedules(1); // Always for KEY_3(Scheduled_In)

  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return nullptr;
  }   

  std::cout << "(4) The T&A mode is set to BY_SCHEDULE. The T&A key will be determined automatically by schedule. Try to authenticate without selecting a T&A key." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");   

  // (5) FIXED
  config.set_mode(gsdk::tna::FIXED);
  config.set_key(gsdk::tna::KEY_4); 

  status = svc.SetConfig(deviceID, config);
  if (!status.ok()) {
	  return nullptr;
  }   

  std::cout << "(5) The T&A mode is set to FIXED(KEY_4). Try to authenticate without selecting a T&A key." << std::endl << std::endl;
  Menu::PressEnter(">> Press ENTER if you finish testing this mode.\n");   

  return origConfig;
}

