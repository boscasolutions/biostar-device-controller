#include <string>
#include <string.h>
#include <stdint.h>
#include <iostream>
#include <grpcpp/grpcpp.h>
#include <stdlib.h>
#include "GatewayClient.h"
#include "ConnectSvc.h"
#include "EventSvc.h"
#include "TNASvc.h"
#include "DeviceSvc.h"

using grpc::Channel;
using grpc::Status;

using example::GatewayClient;
using example::ConnectSvc;
using example::EventSvc;
using example::TNASvc;
using example::DeviceSvc;

using google::protobuf::RepeatedPtrField;

const std::string GATEWAY_CA_FILE = "../cert/gateway/ca.crt";
const std::string GATEWAY_ADDR = "192.168.8.98";
const int GATEWAY_PORT = 4000;

const std::string DEVICE_IP = "192.168.8.205";
const int DEVICE_PORT = 51211;
const bool USE_SSL = false;

const std::string CODE_MAP_FILE = "./event_code.json";

extern void startMonitoring(EventSvc& svc, uint32_t deviceID);
extern void stopMonitoring(EventSvc& svc, uint32_t deviceID);
extern std::shared_ptr<TNAConfig> testConfig(TNASvc& svc, uint32_t deviceID);
extern void testEvent(TNASvc& tnaSvc, EventSvc& eventSvc, uint32_t deviceID);

int main(int argc, char** argv) {
  uint32_t deviceID = 0;

  auto gatewayClient = std::make_shared<GatewayClient>();
  if (!gatewayClient->Connect(GATEWAY_ADDR, GATEWAY_PORT, GATEWAY_CA_FILE)) {
    std::cerr << "Cannot connect to the gateway" << std::endl;
    exit(1);
  }

  ConnectSvc connectSvc(gatewayClient->GetChannel());

  ConnectInfo connInfo;
  connInfo.set_ipaddr(DEVICE_IP);
  connInfo.set_port(DEVICE_PORT);
  connInfo.set_usessl(USE_SSL);

  Status status = connectSvc.Connect(connInfo, &deviceID);
  if (!status.ok()) {
    std::cerr << "Cannot connect to the device " << deviceID << std::endl;
    exit(1);
  }  

  std::vector<uint32_t> deviceIDs;
  deviceIDs.push_back(deviceID);

  DeviceSvc deviceSvc(gatewayClient->GetChannel());
  DeviceCapability capability;
  status = deviceSvc.GetCapability(deviceID, &capability);
  if (!status.ok()) {
    std::cerr << "Cannot get the device capability " << deviceID << std::endl;
    connectSvc.Disconnect(deviceIDs);
    exit(1);
  }

  if (!capability.displaysupported()) {
    std::cerr << "T&A is not supported by the device " << deviceID << std::endl;
    connectSvc.Disconnect(deviceIDs);
    exit(1);
  }

  EventSvc eventSvc(gatewayClient->GetChannel());
  eventSvc.InitCodeMap(CODE_MAP_FILE);
  startMonitoring(eventSvc, deviceID);

  TNASvc tnaSvc(gatewayClient->GetChannel());
  auto tnaOrigConfig = testConfig(tnaSvc, deviceID);
  testEvent(tnaSvc, eventSvc, deviceID);

  if (tnaOrigConfig) {
    tnaSvc.SetConfig(deviceID, *tnaOrigConfig.get());
  }
  stopMonitoring(eventSvc, deviceID);
  connectSvc.Disconnect(deviceIDs);

  return 0;
}