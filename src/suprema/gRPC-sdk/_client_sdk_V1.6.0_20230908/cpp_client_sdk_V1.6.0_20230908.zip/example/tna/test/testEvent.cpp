#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <thread>
#include "EventSvc.h"
#include "TNASvc.h"

using grpc::ClientContext;
using example::EventSvc;
using example::TNASvc;

std::shared_ptr<ClientContext> s_Context;
std::thread s_MonitoringThread;
const int EVENT_QUEUE_SIZE = 16;

int s_FirstEventID = 0;

void handleEvent(std::unique_ptr<ClientReader<EventLog>> eventReader);
void printEvent(EventSvc& eventSvc, TNALog& event, TNAConfig& config);
std::string getEventString(uint32_t eventCode, uint32_t subCode);
std::string getTNALabel(gsdk::tna::Key key, TNAConfig& config); 

void startMonitoring(EventSvc& svc, uint32_t deviceID) {
  Status status = svc.EnableMonitoring(deviceID);

  if (!status.ok()) {
	  return;
  }

	s_Context = std::make_shared<ClientContext>();
	auto eventReader(svc.Subscribe(s_Context.get(), EVENT_QUEUE_SIZE));

	s_MonitoringThread = std::thread(handleEvent, std::move(eventReader));
}


void stopMonitoring(EventSvc& svc, uint32_t deviceID) {
  s_Context->TryCancel();
	s_MonitoringThread.join();
  svc.DisableMonitoring(deviceID);  
}


void handleEvent(std::unique_ptr<ClientReader<EventLog>> eventReader) {
	EventLog realtimeEvent;

	while (eventReader->Read(&realtimeEvent)) {
		if (s_FirstEventID == 0) {
			s_FirstEventID = realtimeEvent.id();
		}

		std::cout << "[EVENT] " << realtimeEvent.ShortDebugString() << std::endl;
	}

	std::cout << "Monitoring thread is stopped" << std::endl;

	eventReader->Finish();
}

void testEvent(TNASvc& tnaSvc, EventSvc& eventSvc, uint32_t deviceID) {
  std::cout << std::endl << "===== T&A Log Events =====" << std::endl << std::endl;

  RepeatedPtrField<TNALog> events;
  Status status = tnaSvc.GetTNALog(deviceID, s_FirstEventID, 0, &events);
  if (!status.ok()) {
	  return;
  }

  TNAConfig config;
  status = tnaSvc.GetConfig(deviceID, &config);
  if (!status.ok()) {
	  return;
  }

  for(int i = 0; i < events.size(); i++) {
    printEvent(eventSvc, events[i], config);
  }  
}

void printEvent(EventSvc& eventSvc, TNALog& event, TNAConfig& config) {
  time_t eventTime = (time_t)event.timestamp();
  std::cout << std::put_time(std::localtime(&eventTime), "%Y-%m-%d %H:%M:%S") << ": Device " << event.deviceid() << ", User " << event.userid() << ", " << eventSvc.GetEventString(event.eventcode(), event.subcode()) << ", " << getTNALabel(event.tnakey(), config) << std::endl;
}


std::string getTNALabel(gsdk::tna::Key key, TNAConfig& config) {
	char buf[64];

  if(config.labels_size() > (int)key - 1) {
		sprintf(buf, "%s(Key_%d)", config.labels((int)key - 1).c_str(), key);
  } else {
		sprintf(buf, "Key_%s", key);
  } 

	return buf;
}
