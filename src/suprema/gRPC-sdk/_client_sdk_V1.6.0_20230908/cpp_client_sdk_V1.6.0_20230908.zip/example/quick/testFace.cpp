#include <fstream>
#include <stdint.h>
#include "FaceSvc.h"

using example::FaceSvc;

const std::string FACE_IMAGE_NAME = "./face.bmp";

void testFace(FaceSvc& svc, uint32_t deviceID) {
	std::cout << std::endl << "(3) Face Test" << std::endl << std::endl;

  FaceConfig config;
	Status status = svc.GetConfig(deviceID, &config);

  if (!status.ok()) {
	  return;
  }

  std::cout << std::endl << "Face config: " << std::endl << config.ShortDebugString() << std::endl;

  std::cout << ">>> Scan a face..." << std::endl;

  gsdk::face::FaceData faceData;
  status = svc.Scan(deviceID, config.enrollthreshold(), &faceData);

  if (!status.ok()) {
	  return;
  }

  for (int i = 0; i < faceData.templates_size(); ++i) {
    std::cout << "Template data[" << i << "]: ";

    for (int j = 0; j < faceData.templates(i).size(); ++j)
      printf("%02x", faceData.templates(i)[j]);
  
    std::cout << std::endl;
  }

  std::cout << std::endl;

  std::string bmpImage;
  std::ofstream bmpFile(FACE_IMAGE_NAME, std::ios::binary);

  bmpFile.write(faceData.imagedata().data(), faceData.imagedata().size());
  bmpFile.close();
}