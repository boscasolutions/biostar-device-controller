#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include "EventSvc.h"

using example::EventSvc;

const int START_EVENT_ID = 0;
const int MAX_NUM_OF_LOG = 16;
const int MAX_NUM_OF_IMAGE_LOG = 2;
const std::string IMAGE_LOG_FILE = "./image_log.jpg";

const int NUM_OF_REALTIME_LOG = 2;
const int EVENT_QUEUE_SIZE = 16;

void testEvent(EventSvc& svc, uint32_t deviceID) {
	std::cout << std::endl << "(6) Event Test" << std::endl << std::endl;

  RepeatedPtrField<EventLog> events;
  Status status = svc.GetLog(deviceID, START_EVENT_ID, MAX_NUM_OF_LOG, &events);

  if (!status.ok()) {
	  return;
  }

  std::cout << "Event logs: " << events.size() << std::endl;

  for(int i = 0; i < events.size(); i++) {
    std::cout << events[i].ShortDebugString() << std::endl;
  }

  RepeatedPtrField<ImageLog> imageEvents;
  status = svc.GetImageLog(deviceID, START_EVENT_ID, MAX_NUM_OF_IMAGE_LOG, &imageEvents);

  if (!status.ok()) {
	  return;
  }

  std::cout << "Image events: " << imageEvents.size() << std::endl;

  if(imageEvents.size() > 0) {
    std::ofstream jpgFile(IMAGE_LOG_FILE, std::ios::binary);
    jpgFile.write(imageEvents[0].jpgimage().data(), imageEvents[0].jpgimage().size());
    jpgFile.close();
  }

  status = svc.EnableMonitoring(deviceID);

  if (!status.ok()) {
	  return;
  }

  ClientContext context;
  std::unique_ptr<ClientReader<EventLog>> eventReader(svc.Subscribe(&context, EVENT_QUEUE_SIZE));

  int numOfRealtimeEvents = 0;

  std::cout << std::endl << ">>> Generate " << NUM_OF_REALTIME_LOG << " realtime events..." << std::endl;

  EventLog realtimeEvent;

  while(numOfRealtimeEvents < NUM_OF_REALTIME_LOG) {
    if(!eventReader->Read(&realtimeEvent)) {
      std::cerr << "Cannot receive realtime events!" << std::endl;
      break;
    }

    std::cout << realtimeEvent.ShortDebugString() << std::endl;

    numOfRealtimeEvents++;
  }

  context.TryCancel();
  eventReader->Finish();
  svc.DisableMonitoring(deviceID);
}