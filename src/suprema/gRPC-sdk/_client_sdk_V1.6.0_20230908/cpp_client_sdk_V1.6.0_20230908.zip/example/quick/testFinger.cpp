#include <fstream>
#include <stdint.h>
#include "FingerSvc.h"

using example::FingerSvc;

const int QUALITY_THRESHOLD = 50;
const std::string FINGERPRINT_IMAGE_NAME = "./finger.bmp";

void testFinger(FingerSvc& svc, uint32_t deviceID) {
	std::cout << std::endl << "(3) Finger Test" << std::endl << std::endl;

  FingerConfig config;
	Status status = svc.GetConfig(deviceID, &config);

  if (!status.ok()) {
	  return;
  }

  std::cout << std::endl << "Fingerprint config: " << std::endl << config.ShortDebugString() << std::endl;

  std::cout << ">>> Scan a finger..." << std::endl;

  std::string templateData;
  status = svc.Scan(deviceID, config.templateformat(), QUALITY_THRESHOLD, templateData);

  if (!status.ok()) {
	  return;
  }

  std::cout << "Template data: ";
  for(int i = 0; i < templateData.size(); i++) {
    printf("%02x", templateData[i]);
  }
  std::cout << std::endl;

  std::string bmpImage;
  status = svc.GetImage(deviceID, bmpImage);

  if (!status.ok()) {
	  return;
  }

  std::ofstream bmpFile(FINGERPRINT_IMAGE_NAME, std::ios::binary);
  bmpFile.write(bmpImage.data(), bmpImage.size());
  bmpFile.close();
}