#include <stdio.h>
#include <stdint.h>
#include "DeviceSvc.h"

using example::DeviceSvc;

std::shared_ptr<CapabilityInfo> testDevice(DeviceSvc& svc, uint32_t deviceID) {
	std::cout << std::endl << "(2) Device Test" << std::endl << std::endl;

  FactoryInfo devInfo;
  Status status = svc.GetInfo(deviceID, &devInfo);

  if (!status.ok()) {
	  return NULL;
  }

  std::cout << "Device info: " << std::endl << devInfo.ShortDebugString() << std::endl;

  auto devCapability = std::make_shared<CapabilityInfo>();
  status = svc.GetCapabilityInfo(deviceID, devCapability.get());

  if (!status.ok()) {
	  return NULL;
  }

  std::cout << "Device capability: " << std::endl << devCapability->ShortDebugString() << std::endl;

  return devCapability;
}
