#include <fstream>
#include <stdint.h>
#include "DisplaySvc.h"

using example::DisplaySvc;

void testDisplay(DisplaySvc& svc, uint32_t deviceID) {
	std::cout << std::endl << "(3) Display Test" << std::endl << std::endl;

  DisplayConfig config;
	Status status = svc.GetConfig(deviceID, &config);

  if (!status.ok()) {
	  return;
  }

  std::cout << std::endl << "Display config: " << std::endl << config.ShortDebugString() << std::endl;
}