#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <fstream>
#include "UserSvc.h"
#include "FingerSvc.h"
#include "FaceSvc.h"
#include "DeviceSvc.h"

using example::UserSvc;
using example::FingerSvc;
using example::FaceSvc;

using gsdk::user::UserFinger;

using gsdk::finger::FingerData;
using gsdk::finger::TemplateFormat;

using gsdk::user::UserFace;

using gsdk::face::FaceData;

const int NUM_OF_NEW_USER = 3;
const int QUALITY_THRESHOLD = 50;

Status testFinger(UserSvc& svc, FingerSvc& fingerSvc, uint32_t deviceID, std::string userID) {
  std::vector<std::string> userIDs = {userID};

  RepeatedPtrField<UserInfo> userInfos;
  Status status = svc.GetUser(deviceID, userIDs, &userInfos);  

  if (!status.ok()) {
	  return status;
  }

  std::cout << "User without fingerprint: " << userInfos[0].ShortDebugString() << std::endl << std::endl;  

  FingerData fingerData;

  std::cout << ">>> Scan a finger for " << userID << std::endl;
  std::string templateData;

  status = fingerSvc.Scan(deviceID, gsdk::finger::TEMPLATE_FORMAT_SUPREMA, QUALITY_THRESHOLD, templateData);

  if (!status.ok()) {
	  return status;
  }

  fingerData.add_templates(templateData);

  std::cout << ">>> Scan the same finger for " << userID << std::endl;

  status = fingerSvc.Scan(deviceID, gsdk::finger::TEMPLATE_FORMAT_SUPREMA, QUALITY_THRESHOLD, templateData);

  if (!status.ok()) {
	  return status;
  }

  fingerData.add_templates(templateData);  

  RepeatedPtrField<UserFinger> userFingers;
  
  UserFinger userFinger;
  userFinger.set_userid(userID);
  userFinger.mutable_fingers()->Add(std::forward<FingerData>(fingerData));

  userFingers.Add(std::forward<UserFinger>(userFinger));

  status = svc.SetFinger(deviceID, userFingers);

  if (!status.ok()) {
	  return status;
  }

  status = svc.GetUser(deviceID, userIDs, &userInfos);  

  if (!status.ok()) {
	  return status;
  }

  std::cout << "User after adding fingerprint: " << userInfos[0].ShortDebugString() << std::endl << std::endl;    

  return status;
}

Status testFace(UserSvc& svc, FaceSvc& faceSvc, uint32_t deviceID, std::string userID) {
  std::vector<std::string> userIDs = {userID};

  RepeatedPtrField<UserInfo> userInfos;
  Status status = svc.GetUser(deviceID, userIDs, &userInfos);  

  if (!status.ok()) {
	  return status;
  }

  std::cout << "User without face: " << userInfos[0].ShortDebugString() << std::endl << std::endl;  

  FaceData faceData;

  std::cout << ">>> Scan a face for " << userID << std::endl;

  status = faceSvc.Scan(deviceID, gsdk::face::BS2_FACE_ENROLL_THRESHOLD_DEFAULT, &faceData);

  if (!status.ok()) {
	  return status;
  }

  RepeatedPtrField<UserFace> userFaces;
  
  UserFace userFace;
  userFace.set_userid(userID);
  userFace.mutable_faces()->Add(std::forward<FaceData>(faceData));

  userFaces.Add(std::forward<UserFace>(userFace));

  status = svc.SetFace(deviceID, userFaces);

  if (!status.ok()) {
	  return status;
  }

  status = svc.GetUser(deviceID, userIDs, &userInfos);  

  if (!status.ok()) {
	  return status;
  }

  std::cout << "User after adding face: " << userInfos[0].ShortDebugString() << std::endl << std::endl;    

  return status;
}

void testUser(UserSvc& svc, FingerSvc& fingerSvc, FaceSvc& faceSvc, uint32_t deviceID, CapabilityInfo& capabilityInfo) {
	std::cout << std::endl << "(5) User Test" << std::endl << std::endl;

  RepeatedPtrField<UserHdr> userList;
  Status status = svc.GetList(deviceID, &userList);

  if (!status.ok()) {
	  return;
  }

  std::cout << "User list: " << userList.size() << std::endl;

  std::vector<std::string> userIDs;

  for(int i = 0; i < userList.size(); i++) {
    std::cout << userList[i].ShortDebugString() << std::endl;

	  userIDs.push_back(userList[i].id()); 
  }

  RepeatedPtrField<UserInfo> userInfos;
  status = svc.GetUser(deviceID, userIDs, &userInfos);

  if (!status.ok()) {
	  return;
  }

  std::cout << "User information: " << std::endl;

  for(int i = 0; i < userInfos.size(); i++) {
    std::cout << userInfos[i].ShortDebugString() << std::endl;
  }

  RepeatedPtrField<UserInfo> newUserInfos;
  std::vector<std::string> newUserIDs;

  srand(time(NULL));

  for(int i = 0; i < NUM_OF_NEW_USER; i++) {
    UserInfo userInfo;

    std::string userID = std::to_string(rand());
    *userInfo.mutable_hdr()->mutable_id() = userID;
    
    newUserInfos.Add(std::forward<UserInfo>(userInfo));
    newUserIDs.push_back(userID);
  }

  status = svc.Enroll(deviceID, newUserInfos);

  if (!status.ok()) {
	  return;
  }

  status = svc.GetList(deviceID, &userList);

  if (!status.ok()) {
	  return;
  }

  std::cout << "User list after enrolling new users: " << userList.size() << std::endl;

  if (capabilityInfo.fingersupported()) {
    status = testFinger(svc, fingerSvc, deviceID, newUserIDs[0]);

    if (!status.ok()) {
      return;
    }
  }

  if (capabilityInfo.facesupported()) {
    status = testFace(svc, faceSvc, deviceID, newUserIDs[0]);

    if (!status.ok()) {
      return;
    }
  }

  status = svc.Delete(deviceID, newUserIDs);

  if (!status.ok()) {
	  return;
  }

  status = svc.GetList(deviceID, &userList);

  if (!status.ok()) {
	  return;
  }

  std::cout << "User list after deleting new users: " << userList.size() << std::endl;
}