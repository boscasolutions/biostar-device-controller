#include <string>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <iostream>
#include <grpcpp/grpcpp.h>
#include <stdlib.h>
#include "GatewayClient.h"
#include "MasterClient.h"
#include "ConnectSvc.h"
#include "ConnectMasterSvc.h"
#include "DeviceSvc.h"
#include "FingerSvc.h"
#include "FaceSvc.h"
#include "CardSvc.h"
#include "UserSvc.h"
#include "EventSvc.h"
#include "TenantSvc.h"

using grpc::Channel;
using grpc::Status;

using example::GrpcClient;
using example::GatewayClient;
using example::MasterClient;
using example::ConnectSvc;
using example::ConnectMasterSvc;
using example::DeviceSvc;
using example::FingerSvc;
using example::FaceSvc;
using example::CardSvc;
using example::UserSvc;
using example::EventSvc;
using example::TenantSvc;

using gsdk::tenant::TenantInfo;

using google::protobuf::RepeatedPtrField;

const std::string GATEWAY_CA_FILE = "../cert/gateway/192.168.28.111/ca.crt";
const std::string GATEWAY_ADDR = "192.168.28.111";
const int GATEWAY_PORT = 4000;

const std::string DEVICE_IP = "192.168.28.205";
const int DEVICE_PORT = 51211;
const bool USE_SSL = false;

const std::string MASTER_CA_FILE = "../cert/master/master_ca.crt";
const std::string MASTER_ADDR = "192.168.28.21";
const int MASTER_PORT = 4010;
const std::string TENANT_CERT_FILE = "../cert/master/192.168.28.21/tenant1.crt";
const std::string TENANT_KEY_FILE = "../cert/master/192.168.28.21/tenant1_key.pem";
const std::string ADMIN_CERT_FILE = "../cert/master/192.168.28.21/admin.crt";
const std::string ADMIN_KEY_FILE = "../cert/master/192.168.28.21/admin_key.pem";

const std::string TENANT_ID = "tenant1";
const std::string GATEWAY_ID = "gateway1";

extern uint32_t testConnect(std::shared_ptr<ConnectSvc> svc, std::string deviceIP, int devicePort, bool useSSL);
extern uint32_t testConnectMaster(std::shared_ptr<ConnectMasterSvc> svc, std::string gatewayID, std::string deviceIP, int devicePort, bool useSSL);
extern std::shared_ptr<CapabilityInfo> testDevice(DeviceSvc& svc, uint32_t deviceID);
extern void testFinger(FingerSvc& svc, uint32_t deviceID);
extern void testFace(FaceSvc& svc, uint32_t deviceID);
extern void testCard(CardSvc& svc, uint32_t deviceID, CapabilityInfo& capabilityInfo);
extern void testUser(UserSvc& svc, FingerSvc& fingerSvc, FaceSvc& faceSvc, uint32_t deviceID, CapabilityInfo& capabilityInfo);
extern void testEvent(EventSvc& svc, uint32_t deviceID);


void initTenant() {
  auto masterClient = std::make_shared<MasterClient>();
  if(!masterClient->ConnectAdmin(MASTER_ADDR, MASTER_PORT, MASTER_CA_FILE, ADMIN_CERT_FILE, ADMIN_KEY_FILE)) {
    std::cerr << "Cannot connect to the master gateway" << std::endl;
    exit(1);
  }

  auto tenantSvc = std::make_shared<TenantSvc>(masterClient->GetChannel());

  std::vector<std::string> tenantIDs;
  tenantIDs.push_back(TENANT_ID);  
	RepeatedPtrField<TenantInfo> tenantInfos;
  auto status = tenantSvc->Get(tenantIDs, &tenantInfos);

  if(status.ok()) {
    std::cerr << TENANT_ID << " is already registered" << std::endl;
  } else {
    std::cerr << TENANT_ID << " is not registered. Trying to add the tenant..." << std::endl;

    RepeatedPtrField<TenantInfo> newTenantInfos;
    TenantInfo tenantInfo;
    tenantInfo.set_tenantid(TENANT_ID);
    tenantInfo.add_gatewayids(GATEWAY_ID);
		newTenantInfos.Add(std::forward<TenantInfo>(tenantInfo));

    status = tenantSvc->Add(newTenantInfos);

    if(status.ok()) {
      std::cerr << TENANT_ID << " is registered successfully" << std::endl;
    } else {
      std::cerr << "Cannot add the tenant: " << status.error_message() << std::endl;
    }
  }
}


// To enable gRPC debugging
// $ export GRPC_VERBOSITY=debug && GRPC_TRACE=api


int main(int argc, char** argv) {
  bool masterMode = false;

  for(int i = 1; i < argc; i++) {
    if(strcmp(argv[i], "-mi") == 0) {
      initTenant();
      return 0;
    }

    if(strcmp(argv[i], "-m") == 0) {
      masterMode = true;
      break;
    }
  }

  std::shared_ptr<GrpcClient> client;
  uint32_t deviceID = 0;

  std::shared_ptr<ConnectSvc> connectSvc;
  std::shared_ptr<ConnectMasterSvc> connectMasterSvc;

  if(masterMode) {
    auto masterClient = std::make_shared<MasterClient>();
    if(!masterClient->ConnectTenant(MASTER_ADDR, MASTER_PORT, MASTER_CA_FILE, TENANT_CERT_FILE, TENANT_KEY_FILE)) {
      std::cerr << "Cannot connect to the master gateway" << std::endl;
      exit(1);
    }

    connectMasterSvc = std::make_shared<ConnectMasterSvc>(masterClient->GetChannel());
    deviceID = testConnectMaster(connectMasterSvc, GATEWAY_ID, DEVICE_IP, DEVICE_PORT, USE_SSL);
    if(deviceID == 0) {
      std::cerr << "Cannot connect to the device" << std::endl;
      exit(1);
    } 

    client = masterClient;
  } else {
    auto gatewayClient = std::make_shared<GatewayClient>();
    if(!gatewayClient->Connect(GATEWAY_ADDR, GATEWAY_PORT, GATEWAY_CA_FILE)) {
      std::cerr << "Cannot connect to the gateway" << std::endl;
      exit(1);
    }

    connectSvc = std::make_shared<ConnectSvc>(gatewayClient->GetChannel());
    deviceID = testConnect(connectSvc, DEVICE_IP, DEVICE_PORT, USE_SSL);
    if(deviceID == 0) {
      std::cerr << "Cannot connect to the device" << std::endl;
      exit(1);
    } 

    client = gatewayClient;
  }

  DeviceSvc deviceSvc(client->GetChannel());
  auto capabilityInfo = testDevice(deviceSvc, deviceID);

  FingerSvc fingerSvc(client->GetChannel());
  if (capabilityInfo->fingersupported()) {
    testFinger(fingerSvc, deviceID);
  }

  FaceSvc faceSvc(client->GetChannel());
  if (capabilityInfo->facesupported()) {
    testFace(faceSvc, deviceID);
  }

  CardSvc cardSvc(client->GetChannel());
  if (capabilityInfo->cardsupported()) {
    testCard(cardSvc, deviceID, *capabilityInfo);
  }

  UserSvc userSvc(client->GetChannel());
  testUser(userSvc, fingerSvc, faceSvc, deviceID, *capabilityInfo);

  EventSvc eventSvc(client->GetChannel());
  testEvent(eventSvc, deviceID);

  std::vector<uint32_t> deviceIDs;
  deviceIDs.push_back(deviceID);
  
  if(masterMode) {
    connectMasterSvc->Disconnect(deviceIDs);
  } else {
    connectSvc->Disconnect(deviceIDs);
  }

  return 0;
}