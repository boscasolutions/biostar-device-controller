#include <stdio.h>
#include <stdint.h>
#include "CardSvc.h"
#include "DeviceSvc.h"

using example::CardSvc;

const int NUM_OF_BLACKLIST_ITEM = 2;      
const int FIRST_BLACKLISTED_CARD_ID = 100000;
const int ISSUE_COUNT = 3;

void testCard(CardSvc& svc, uint32_t deviceID, CapabilityInfo& capabilityInfo) {
	std::cout << std::endl << "(4) Card Test" << std::endl << std::endl;

  std::cout << ">>> Scan a card..." << std::endl;

  CardData cardData;
  Status status = svc.Scan(deviceID, &cardData);

  if (!status.ok()) {
	  return;
  }

  std::cout << "Card data: " << cardData.ShortDebugString() << std::endl << std::endl;

  RepeatedPtrField<BlacklistItem> blacklist;
  status = svc.GetBlacklist(deviceID, &blacklist);

  if (!status.ok()) {
	  return;
  }

  std::cout << "Blacklist: " << blacklist.size() << std::endl;

  RepeatedPtrField<BlacklistItem> cardInfos;
  for(int i = 0; i < NUM_OF_BLACKLIST_ITEM; i++) {
    BlacklistItem cardInfo;
    *cardInfo.mutable_cardid() = std::to_string(FIRST_BLACKLISTED_CARD_ID + i);
    cardInfo.set_issuecount(ISSUE_COUNT);

    cardInfos.Add(std::forward<BlacklistItem>(cardInfo));
  }

  status = svc.AddBlacklist(deviceID, &cardInfos);

  if (!status.ok()) {
	  return;
  }

  status = svc.GetBlacklist(deviceID, &blacklist);

  if (!status.ok()) {
	  return;
  }

  std::cout << "Blacklist after adding new items: " << blacklist.size() << std::endl;

  for(int i = 0; i < blacklist.size(); i++) {
    std::cout << blacklist[i].ShortDebugString() << std::endl;
  }

  status = svc.DeleteBlacklist(deviceID, &cardInfos);

  if (!status.ok()) {
	  return;
  }

  status = svc.GetBlacklist(deviceID, &blacklist);

  if (!status.ok()) {
	  return;
  }

  std::cout << "Blacklist after deleting new items: " << blacklist.size() << std::endl;

  CardConfig config;
  status = svc.GetConfig(deviceID, &config);

  if (!status.ok()) {
	  return;
  }

  std::cout << std::endl << "Card config: " << std::endl << config.ShortDebugString() << std::endl;

  if (capabilityInfo.qrsupported()) {
    QRConfig qrConfig;
    status = svc.GetQRConfig(deviceID, &qrConfig);

    if (!status.ok()) {
      return;
    }

    std::cout << std::endl << "QR config: " << std::endl << qrConfig.ShortDebugString() << std::endl;
  }
}