#include <stdio.h>
#include <stdint.h>
#include <grpcpp/grpcpp.h>
#include "ConnectSvc.h"
#include "ConnectMasterSvc.h"

using grpc::Channel;
using grpc::Status;
using example::ConnectSvc;
using example::ConnectMasterSvc;

uint32_t testConnect(std::shared_ptr<ConnectSvc> svc, std::string ipAddr, int port, bool useSSL) {
	std::cout << std::endl << "(1) Connection Test" << std::endl << std::endl;

  RepeatedPtrField<DeviceInfo> deviceInfos;
  Status status = svc->GetDeviceList(&deviceInfos);

  if(!status.ok()) {
    return 0;
  }

  std::cout << "Device list before connection: " << deviceInfos.size() << std::endl;

  for(int i = 0; i < deviceInfos.size(); i++) {
    std::cout << deviceInfos[i].ShortDebugString() << std::endl;
  }

  ConnectInfo connInfo;
  connInfo.set_ipaddr(ipAddr);
  connInfo.set_port(port);
  connInfo.set_usessl(useSSL);

  uint32_t deviceID = 0;
  status = svc->Connect(connInfo, &deviceID);

  if(!status.ok()) {
    return 0;
  }

  std::cout << "Connected to: " << deviceID << std::endl;

  svc->GetDeviceList(&deviceInfos);  

  std::cout << "Device list after connection: " << deviceInfos.size() << std::endl;

  for(int i = 0; i < deviceInfos.size(); i++) {
    std::cout << deviceInfos[i].ShortDebugString() << std::endl;
  }  

  return deviceID;
}


uint32_t testConnectMaster(std::shared_ptr<ConnectMasterSvc> svc, std::string gatewayID, std::string ipAddr, int port, bool useSSL) {
	std::cout << std::endl << "(1) Connection Test" << std::endl << std::endl;

  RepeatedPtrField<DeviceInfo> deviceInfos;
  Status status = svc->GetDeviceList(gatewayID, &deviceInfos);

  if(!status.ok()) {
    return 0;
  }

  std::cout << "Device list before connection: " << deviceInfos.size() << std::endl;

  for(int i = 0; i < deviceInfos.size(); i++) {
    std::cout << deviceInfos[i].ShortDebugString() << std::endl;
  }

  ConnectInfo connInfo;
  connInfo.set_ipaddr(ipAddr);
  connInfo.set_port(port);
  connInfo.set_usessl(useSSL);

  uint32_t deviceID = 0;
  status = svc->Connect(gatewayID, connInfo, &deviceID);

  if(!status.ok()) {
    return 0;
  }

  std::cout << "Connected to: " << deviceID << std::endl;

  svc->GetDeviceList(gatewayID, &deviceInfos);  

  std::cout << "Device list after connection: " << deviceInfos.size() << std::endl;

  for(int i = 0; i < deviceInfos.size(); i++) {
    std::cout << deviceInfos[i].ShortDebugString() << std::endl;
  }  

  return deviceID;
}