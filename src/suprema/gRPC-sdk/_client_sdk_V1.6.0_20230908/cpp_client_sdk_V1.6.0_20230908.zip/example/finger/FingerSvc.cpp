#include <iostream>
#include "FingerSvc.h"

using grpc::ClientContext;

using gsdk::finger::ScanRequest;
using gsdk::finger::ScanResponse;

using gsdk::finger::GetImageRequest;
using gsdk::finger::GetImageResponse;

using gsdk::finger::GetConfigRequest;
using gsdk::finger::GetConfigResponse;

namespace example {
	Status FingerSvc::Scan(uint32_t deviceID, TemplateFormat templateFormat, uint32_t threshold, std::string& templateData) {
		ScanRequest request;
		request.set_deviceid(deviceID);
		request.set_templateformat(templateFormat);
		request.set_qualitythreshold(threshold);

		ScanResponse response;

		ClientContext context;

		Status status = stub_->Scan(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot scan a finger: " << status.error_message() << std::endl;
			return status;
		}

		templateData = response.templatedata();

		return status;
	}

	Status FingerSvc::GetImage(uint32_t deviceID, std::string& bmpImage) {
		GetImageRequest request;
		request.set_deviceid(deviceID);

		GetImageResponse response;

		ClientContext context;

		Status status = stub_->GetImage(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the image: " << status.error_message() << std::endl;
			return status;
		}

		bmpImage = response.bmpimage(); 

		return status;
	}

	Status FingerSvc::GetConfig(uint32_t deviceID, FingerConfig* config) {
		GetConfigRequest request;
		request.set_deviceid(deviceID);

		GetConfigResponse response;

		ClientContext context;

		Status status = stub_->GetConfig(&context, request, &response);

		if (!status.ok()) {
			std::cerr << "Cannot get the fingerprint config: " << status.error_message() << std::endl;
			return status;
		}

		*config = response.config(); 

		return status;
	}	
}