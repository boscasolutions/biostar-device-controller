#ifndef __FINGER_SVC__H__
#define __FINGER_SVC__H__

#include <stdint.h>
#include <grpcpp/grpcpp.h>

#include "finger.grpc.pb.h"

using grpc::Channel;
using grpc::Status;

using gsdk::finger::Finger;
using gsdk::finger::TemplateFormat;
using gsdk::finger::FingerConfig;

namespace example {
	class FingerSvc {
	public:
		FingerSvc(std::shared_ptr<Channel> channel)
			: stub_(Finger::NewStub(channel)) {}

		Status Scan(uint32_t deviceID, TemplateFormat templateFormat, uint32_t threshold, std::string& templateData);

		Status GetImage(uint32_t deviceID, std::string& bmpImage);

		Status GetConfig(uint32_t deviceID, FingerConfig* config);

	private:
		std::unique_ptr<Finger::Stub> stub_;
	};
}

#endif
