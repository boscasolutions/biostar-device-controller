const login = require('./login');

module.exports.initClient = login.initClient;
module.exports.login = login.login;
module.exports.loginAdmin = login.loginAdmin;
