const util = require('./util');

module.exports.toObjectArray = util.toObjectArray;
