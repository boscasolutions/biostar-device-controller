const action = require('./action');

module.exports.initClient = action.initClient;
module.exports.getClient = action.getClient;
module.exports.getConfig = action.getConfig;
module.exports.setConfig = action.setConfig;
module.exports.actionMessage = action.actionMessage;
