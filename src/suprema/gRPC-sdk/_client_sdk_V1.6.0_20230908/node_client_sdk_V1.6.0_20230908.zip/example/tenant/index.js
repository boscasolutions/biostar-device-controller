const tenant = require('./tenant');

module.exports.initClient = tenant.initClient;
module.exports.get = tenant.get;
module.exports.add = tenant.add;
