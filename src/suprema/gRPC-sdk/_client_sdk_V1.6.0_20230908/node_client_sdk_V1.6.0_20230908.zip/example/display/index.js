const display = require('./display');

module.exports.initClient = display.initClient;
module.exports.getConfig = display.getConfig;
module.exports.displayMessage = display.displayMessage;
