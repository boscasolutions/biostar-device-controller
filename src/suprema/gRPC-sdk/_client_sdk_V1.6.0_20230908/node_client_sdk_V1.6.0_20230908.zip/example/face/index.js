const face = require('./face');

module.exports.initClient = face.initClient;
module.exports.scan = face.scan;
module.exports.getConfig = face.getConfig;
module.exports.faceMessage = face.faceMessage;