const rtsp = require('./rtsp');

module.exports.initClient = rtsp.initClient;
module.exports.getConfig = rtsp.getConfig;
module.exports.setConfig = rtsp.setConfig;
module.exports.rtspMessage = rtsp.rtspMessage;
