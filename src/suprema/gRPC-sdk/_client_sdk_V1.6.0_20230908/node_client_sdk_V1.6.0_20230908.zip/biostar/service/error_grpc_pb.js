// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var error_pb = require('./error_pb.js');


var ErrorService = exports.ErrorService = {
};

exports.ErrorClient = grpc.makeGenericClientConstructor(ErrorService);
