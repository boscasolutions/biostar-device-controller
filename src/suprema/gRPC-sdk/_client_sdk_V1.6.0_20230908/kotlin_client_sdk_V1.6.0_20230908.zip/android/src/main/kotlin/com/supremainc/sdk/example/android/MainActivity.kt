package com.supremainc.sdk.example.android

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.grpc.ManagedChannel
import io.grpc.okhttp.OkHttpChannelBuilder;
import java.io.InputStream
import java.net.URL
import java.util.logging.Logger
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.TrustManagerFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asExecutor
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope

import com.supremainc.sdk.example.connect.ConnectSvc
import com.supremainc.sdk.connect.ConnectInfo
import com.supremainc.sdk.example.event.EventSvc
import com.supremainc.sdk.event.EventLog

const val GATEWAY_ADDR = "192.168.8.98"
const val GATEWAY_PORT = 4000

const val DEVICE_ADDR = "192.168.8.209"
const val DEVICE_PORT = 51211
const val DEVICE_USE_SSL = false
const val MAX_REALTIME_EVENT = 2

class MainActivity : AppCompatActivity() {
    private val logger = Logger.getLogger(this.javaClass.name)

    private fun getSslSocketFactory(rootCa: InputStream?): SSLSocketFactory {
        if (rootCa == null) {
            return SSLSocketFactory.getDefault() as SSLSocketFactory
        }

        val context = SSLContext.getInstance("TLS")
        context.init(null, getTrustManagers(rootCa), null)
        return context.getSocketFactory()
    }

    private fun getTrustManagers(rootCa: InputStream): Array<TrustManager> {
        val ks = KeyStore.getInstance(KeyStore.getDefaultType())
        ks.load(null)
        val cf = CertificateFactory.getInstance("X.509")
        val cert = cf.generateCertificate(rootCa) as X509Certificate
        val principal = cert.getSubjectX500Principal()
        ks.setCertificateEntry(principal.getName("RFC2253"), cert)
        // Set up trust manager factory to use our key store.
        val trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        trustManagerFactory.init(ks)
        return trustManagerFactory.getTrustManagers()
    }    

    private var channel: ManagedChannel? = null
    private var connectSvc: ConnectSvc? = null
    private var eventSvc: EventSvc? = null
    private var button: Button? = null
    private var cmdText: TextView? = null
    private var msgText: TextView? = null
    private var monitoringJob: Job? = null
    private var numOfEvent = 0
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button = findViewById<Button>(R.id.button)

        val gatewayText = findViewById<EditText>(R.id.gateway)
        gatewayText.setText("Gateway: $GATEWAY_ADDR:$GATEWAY_PORT")

        val deviceText = findViewById<EditText>(R.id.device)
        deviceText.setText("Device: $DEVICE_ADDR:$DEVICE_PORT (SSL:$DEVICE_USE_SSL)")

        cmdText = findViewById<TextView>(R.id.command)
        msgText = findViewById<TextView>(R.id.response)

        button?.setOnClickListener {
            button?.isEnabled = false
            lifecycleScope.launch {
                test()
            }
        }
    }

    private suspend fun test() {
        channel = OkHttpChannelBuilder.forAddress(GATEWAY_ADDR, GATEWAY_PORT)
            .sslSocketFactory(getSslSocketFactory(getResources().openRawResource(R.raw.ca_cert)))
            .executor(Dispatchers.Default.asExecutor()).build()

        connectSvc = ConnectSvc(channel!!)
        eventSvc = EventSvc(channel!!)

        var deviceID = testConnect()
        testEvent(deviceID)

        connectSvc?.disconnectAll()
        channel?.shutdown()
    }

    private suspend fun testConnect(): Int {
        try {
            cmdText?.text = "Trying to connect..."
            msgText?.text = ""

            var devList = connectSvc?.getDeviceList()
            msgText?.text = msgText?.text.toString() + "\nOriginal Device List: " + devList.toString() + "\n\n"

            var connInfo = ConnectInfo.newBuilder().setIPAddr(DEVICE_ADDR).setPort(DEVICE_PORT).setUseSSL(DEVICE_USE_SSL).build()
            var deviceID = connectSvc?.connect(connInfo)

            devList = connectSvc?.getDeviceList()
            msgText?.text = msgText?.text.toString() + "New Device List: " + devList.toString() + "\n\n"

            cmdText?.text = "Connected. Generate " + MAX_REALTIME_EVENT.toString() + " events..."

            return deviceID!!
        } catch (e: Exception) {
            msgText?.text = e.message
            e.printStackTrace()
        }

        return -1
    }

    private suspend fun testEvent(deviceID: Int) = coroutineScope {
        eventSvc?.startMonitoring(deviceID)

        monitoringJob = launch{
            eventSvc?.subscribeRealtimeLog(deviceID, ::eventCallback)
        }

        monitoringJob?.join()

        eventSvc?.stopMonitoring(deviceID)        

        button?.isEnabled = true
        cmdText?.text = "Finished. Press Connect to restart"
    }

    private fun eventCallback(evt: EventLog) {
        msgText?.text = msgText?.text.toString() + "Event: " + evt.toString() + "\n\n"

        if(++numOfEvent >= MAX_REALTIME_EVENT) {
            monitoringJob?.cancel()
        }
    }

}
