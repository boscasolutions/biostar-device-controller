package com.supremainc.sdk.example.quick

import java.io.FileOutputStream
import com.supremainc.sdk.example.display.DisplaySvc
import com.supremainc.sdk.display.DisplayConfig

suspend fun displayTest(displaySvc: DisplaySvc, deviceID: Int) {
  var displayConfig = displaySvc.getConfig(deviceID)
  println("Display config: $displayConfig")
}