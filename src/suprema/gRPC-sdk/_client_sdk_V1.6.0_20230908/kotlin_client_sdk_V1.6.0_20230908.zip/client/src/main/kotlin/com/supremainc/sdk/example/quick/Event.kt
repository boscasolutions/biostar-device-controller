package com.supremainc.sdk.example.quick

import java.io.FileOutputStream
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import com.supremainc.sdk.example.event.EventSvc
import com.supremainc.sdk.event.EventLog
import com.supremainc.sdk.event.ImageLog
import com.supremainc.sdk.device.CapabilityInfo

const val MAX_NUM_OF_LOG = 16
const val MAX_NUM_OF_IMAGE_LOG = 2
const val LOG_IMAGE_FILE = "./image_log.jpg"
const val MAX_REALTIME_EVENT = 2

var monitoringJob: Job? = null

suspend fun eventTest(eventSvc: EventSvc, deviceID: Int, capabilityInfo: CapabilityInfo) = coroutineScope {
  var events = eventSvc.getLog(deviceID, 0, MAX_NUM_OF_LOG)
  println("Events: $events")

  if(capabilityInfo.getImageLogSupported()) {
    var imageEvents = eventSvc.getImageLog(deviceID, 0, MAX_NUM_OF_IMAGE_LOG)
    println("Num of image events: ${imageEvents.size}")

    if(imageEvents.size > 0) {
      var jpgFile = FileOutputStream(LOG_IMAGE_FILE)
      jpgFile.write(imageEvents.get(0).getJPGImage().toByteArray())
      jpgFile.close()
    }
  }

  eventSvc.startMonitoring(deviceID)

  println(">>> Generate $MAX_REALTIME_EVENT real-time events...");

  monitoringJob = launch {
    eventSvc.subscribeRealtimeLog(deviceID, ::eventCallback)
  }

  monitoringJob?.join()

  eventSvc.stopMonitoring(deviceID)
}


var numOfEvent = 0

fun eventCallback(evt: EventLog) {
  println("Event ${++numOfEvent}/$MAX_REALTIME_EVENT: ${evt}")
  if(numOfEvent >= MAX_REALTIME_EVENT) monitoringJob?.cancel()
}
