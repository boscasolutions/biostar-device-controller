package com.supremainc.sdk.example.quick

import io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder
import io.grpc.netty.shaded.io.grpc.netty.GrpcSslContexts
import java.io.File
import java.util.concurrent.TimeUnit
import com.supremainc.sdk.example.connect.ConnectSvc
import com.supremainc.sdk.example.device.DeviceSvc
import com.supremainc.sdk.example.display.DisplaySvc
import com.supremainc.sdk.example.rtsp.RtspSvc
import com.supremainc.sdk.example.voip.VoipSvc
import com.supremainc.sdk.example.finger.FingerSvc
import com.supremainc.sdk.example.face.FaceSvc
import com.supremainc.sdk.example.card.CardSvc
import com.supremainc.sdk.example.user.UserSvc
import com.supremainc.sdk.example.event.EventSvc

const val GATEWAY_CA_FILE = "../cert/gateway/192.168.28.111/ca.crt"
const val GATEWAY_ADDR = "192.168.28.111"
const val GATEWAY_PORT = 4000

const val DEVICE_ADDR = "192.168.28.172"
const val DEVICE_PORT = 51211
const val DEVICE_USE_SSL = false

suspend fun main(args: Array<String>) {
  val channel = NettyChannelBuilder.forAddress(GATEWAY_ADDR, GATEWAY_PORT)
  .sslContext(GrpcSslContexts.forClient().trustManager(File(GATEWAY_CA_FILE)).build())
  .build()

  val connectSvc = ConnectSvc(channel)
  var deviceID = connectTest(connectSvc, DEVICE_ADDR, DEVICE_PORT, DEVICE_USE_SSL)

  var deviceSvc = DeviceSvc(channel)
  var capabilityInfo = deviceTest(deviceSvc, deviceID)

  var rtspSvc = RtspSvc(channel)
  rtspTest(rtspSvc, deviceID)

  var voipSvc = VoipSvc(channel)
  voipTest(voipSvc, deviceID)

  var faceSvc = FaceSvc(channel)
  if (capabilityInfo.getFaceSupported()) {
    faceTest(faceSvc, deviceID)
  }

  var fingerSvc = FingerSvc(channel)
  if (capabilityInfo.getFingerSupported()) {
    fingerTest(fingerSvc, deviceID)
  }

  var cardSvc = CardSvc(channel)
  if (capabilityInfo.getCardSupported()) {
    cardTest(cardSvc, deviceID, capabilityInfo)
  }

  var userSvc = UserSvc(channel)
  userTest(userSvc, fingerSvc, faceSvc, deviceID, capabilityInfo)

  var eventSvc = EventSvc(channel)
  eventTest(eventSvc, deviceID, capabilityInfo)

  connectSvc.disconnectAll()
  channel.shutdown().awaitTermination(5, TimeUnit.SECONDS)
}




