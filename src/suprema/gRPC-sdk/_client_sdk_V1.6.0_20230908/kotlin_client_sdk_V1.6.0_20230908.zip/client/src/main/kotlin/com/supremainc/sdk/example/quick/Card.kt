package com.supremainc.sdk.example.quick

import java.util.ArrayList
import com.google.protobuf.ByteString
import com.supremainc.sdk.example.card.CardSvc
import com.supremainc.sdk.card.BlacklistItem
import com.supremainc.sdk.device.CapabilityInfo

const val NUM_OF_BLACKLIST_ITEM = 2
const val FIRST_BLACKLISTED_CARD_ID = 100000
const val ISSUE_COUNT = 3

suspend fun cardTest(cardSvc: CardSvc, deviceID: Int, capabilityInfo: CapabilityInfo) {
  println(">>> Scan a card...")
  var cardData = cardSvc.scan(deviceID)
  println("Card data: $cardData")  

  var blacklist = cardSvc.getBlacklist(deviceID)
  println("Blacklist: $blacklist")

  var newBlacklist = ArrayList<BlacklistItem>()

  for(i in 0..NUM_OF_BLACKLIST_ITEM - 1) {
    var item = BlacklistItem.newBuilder().setCardID(ByteString.copyFromUtf8((FIRST_BLACKLISTED_CARD_ID + i).toString())).setIssueCount(ISSUE_COUNT).build()
    newBlacklist.add(item)
  }

  cardSvc.addBlacklist(deviceID, newBlacklist)

  blacklist = cardSvc.getBlacklist(deviceID)
  println("Blacklist after adding new items: $blacklist")

  cardSvc.deleteBlacklist(deviceID, newBlacklist)

  blacklist = cardSvc.getBlacklist(deviceID)
  println("Blacklist after deleting new items: $blacklist")

  var config = cardSvc.getConfig(deviceID)
  println("Card config: $config")

  if (capabilityInfo.getQRSupported()) {
    var qrConfig = cardSvc.getQRConfig(deviceID)
    println("QR config: $qrConfig")
  }
}