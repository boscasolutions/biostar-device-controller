package com.supremainc.sdk.example.quick

import java.io.FileOutputStream
import com.supremainc.sdk.example.rtsp.RtspSvc
import com.supremainc.sdk.rtsp.RTSPConfig

suspend fun rtspTest(rtspSvc: RtspSvc, deviceID: Int) {
  var rtspConfig = rtspSvc.getConfig(deviceID)
  println("Rtsp config: $rtspConfig")
}