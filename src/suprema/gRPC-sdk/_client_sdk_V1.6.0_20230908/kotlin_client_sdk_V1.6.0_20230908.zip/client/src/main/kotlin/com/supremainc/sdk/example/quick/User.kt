package com.supremainc.sdk.example.quick

import java.util.ArrayList
import com.google.protobuf.ByteString
import com.supremainc.sdk.example.user.UserSvc
import com.supremainc.sdk.example.finger.FingerSvc
import com.supremainc.sdk.example.face.FaceSvc
import com.supremainc.sdk.user.UserHdr
import com.supremainc.sdk.user.UserInfo
import com.supremainc.sdk.user.UserFinger
import com.supremainc.sdk.user.UserFace
import com.supremainc.sdk.finger.FingerData
import com.supremainc.sdk.face.FaceData
import com.supremainc.sdk.face.FaceEnrollThreshold
import com.supremainc.sdk.device.CapabilityInfo

const val NUM_OF_NEW_USER = 3

suspend fun userTest(userSvc: UserSvc, fingerSvc: FingerSvc, faceSvc: FaceSvc, deviceID: Int, capabilityInfo: CapabilityInfo) {
  var userHdrs = userSvc.getList(deviceID)
  println("User list: $userHdrs")  

  var userIDs = ArrayList<String>()
  var hdrIter = userHdrs.listIterator()
  while(hdrIter.hasNext()) {
    userIDs.add(hdrIter.next().getID())
  }

  var userInfos = userSvc.getUser(deviceID, userIDs)
  var userIter = userInfos.listIterator()
  while(userIter.hasNext()) {
    var info = userIter.next()
    println("User: ${info.getName()} ${info.getHdr()} ${info.getSetting()}")
  }

  var newUsers = ArrayList<UserInfo>()
  var newUserIDs = ArrayList<String>()

  for(i in 0..NUM_OF_NEW_USER - 1) {
    var hdr = UserHdr.newBuilder().setID(String.format("%d", (Math.random() * Int.MAX_VALUE).toInt())).build()
    newUsers.add(UserInfo.newBuilder().setHdr(hdr).build())
    newUserIDs.add(hdr.getID())
  }

  userSvc.enroll(deviceID, newUsers)

  userHdrs = userSvc.getList(deviceID)
  println("User list after enrolling new users: $userHdrs")  

  if (capabilityInfo.getFingerSupported()) {
    testFinger(userSvc, fingerSvc, deviceID, newUserIDs.get(0))
  }

  if (capabilityInfo.getFaceSupported()) {
    testFace(userSvc, faceSvc, deviceID, newUserIDs.get(0))
  }

  userSvc.delete(deviceID, newUserIDs)

  userHdrs = userSvc.getList(deviceID)
  println("User list after deleting new users: $userHdrs")  
}

suspend fun testFinger(userSvc: UserSvc, fingerSvc: FingerSvc, deviceID: Int, userID: String) {
  var userIDs = ArrayList<String>()
  userIDs.add(userID)

  var userInfos = userSvc.getUser(deviceID, userIDs)
  var userIter = userInfos.listIterator()

  if(userIter.hasNext()) {
    println("User without fingerprint: ${userIter.next()}")
  }

  var fingerConfig = fingerSvc.getConfig(deviceID)

  var userFingers = ArrayList<UserFinger>()
  var templateData = ArrayList<ByteString>()

  println(">>> Scan a finger for user $userID ...")
  templateData.add(fingerSvc.scan(deviceID, fingerConfig.getTemplateFormat(), QUALITY_THRESHOLD))

  println(">>> Scan the same finger for user $userID ...")
  templateData.add(fingerSvc.scan(deviceID, fingerConfig.getTemplateFormat(), QUALITY_THRESHOLD))

  var fingerData = FingerData.newBuilder().setIndex(0).setFlag(0).addAllTemplates(templateData).build()
  userFingers.add(UserFinger.newBuilder().setUserID(userID).addFingers(fingerData).build())

  userSvc.setFinger(deviceID, userFingers)

  userInfos = userSvc.getUser(deviceID, userIDs)
  userIter = userInfos.listIterator()

  if(userIter.hasNext()) {
    println("User after adding fingerprint: ${userIter.next()}")
  }
}

suspend fun testFace(userSvc: UserSvc, faceSvc: FaceSvc, deviceID: Int, userID: String) {
  var userIDs = ArrayList<String>()
  userIDs.add(userID)

  var userInfos = userSvc.getUser(deviceID, userIDs)
  var userIter = userInfos.listIterator()

  if(userIter.hasNext()) {
    println("User without face: ${userIter.next()}")
  }

  var faceConfig = faceSvc.getConfig(deviceID)

  var userFaces = ArrayList<UserFace>()

  println(">>> Scan a face for user $userID ...")
  
  var faceData = faceSvc.scan(deviceID, faceConfig.getEnrollThreshold())

  userFaces.add(UserFace.newBuilder().setUserID(userID).addFaces(faceData).build())

  userSvc.setFace(deviceID, userFaces)

  userInfos = userSvc.getUser(deviceID, userIDs)
  userIter = userInfos.listIterator()

  if(userIter.hasNext()) {
    println("User after adding face: ${userIter.next()}")
  }
}
