package com.supremainc.sdk.example.quick

import com.supremainc.sdk.example.connect.ConnectSvc
import com.supremainc.sdk.connect.ConnectInfo

suspend fun connectTest(connectSvc: ConnectSvc, deviceAddr: String, devicePort: Int, useSSL: Boolean): Int {
  var devList = connectSvc.getDeviceList()

  println("Device list before connection: $devList")

  var connInfo = ConnectInfo.newBuilder().setIPAddr(deviceAddr).setPort(devicePort).setUseSSL(useSSL).build()
  var deviceID = connectSvc.connect(connInfo)

  devList = connectSvc.getDeviceList()

  println("Device list after connection:: $devList")

  return deviceID
}