package com.supremainc.sdk.example.quick

import java.io.FileOutputStream
import com.supremainc.sdk.example.voip.VoipSvc
import com.supremainc.sdk.voip.VOIPConfig

suspend fun voipTest(voipSvc: VoipSvc, deviceID: Int) {
  var voipConfig = voipSvc.getConfig(deviceID)
  println("Voip config: $voipConfig")
}