package com.supremainc.sdk.example.quick

import java.io.FileOutputStream
import com.supremainc.sdk.example.finger.FingerSvc
import com.supremainc.sdk.finger.FingerConfig
import com.supremainc.sdk.finger.TemplateFormat

const val QUALITY_THRESHOLD = 50
const val FINGERPRINT_IMAGE_NAME = "./finger.bmp"

suspend fun fingerTest(fingerSvc: FingerSvc, deviceID: Int) {
  var fingerConfig = fingerSvc.getConfig(deviceID)
  println("Finger config: $fingerConfig")

  println(">>> Scan a finger...")
  var templateData = fingerSvc.scan(deviceID, fingerConfig.getTemplateFormat(), QUALITY_THRESHOLD)
  println("Template data: $templateData") 

  var bmpImage = fingerSvc.getImage(deviceID).toByteArray()
  var bmpFile = FileOutputStream(FINGERPRINT_IMAGE_NAME)
  bmpFile.write(bmpImage)
  bmpFile.close()
}