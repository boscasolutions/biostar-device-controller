package com.supremainc.sdk.example.quick

import java.io.FileOutputStream
import com.supremainc.sdk.example.face.FaceSvc
import com.supremainc.sdk.face.FaceConfig
import com.supremainc.sdk.face.FaceEnrollThreshold

const val FACE_IMAGE_NAME = "./face.bmp"

suspend fun faceTest(faceSvc: FaceSvc, deviceID: Int) {
  var faceConfig = faceSvc.getConfig(deviceID)
  println("Face config: $faceConfig")

  println(">>> Scan a face...")
  var faceData = faceSvc.scan(deviceID, faceConfig.getEnrollThreshold())
  println("Face data: $faceData")

  var bmpFile = FileOutputStream(FACE_IMAGE_NAME)
  bmpFile.write(faceData.getImageData().toByteArray())
  bmpFile.close()
}