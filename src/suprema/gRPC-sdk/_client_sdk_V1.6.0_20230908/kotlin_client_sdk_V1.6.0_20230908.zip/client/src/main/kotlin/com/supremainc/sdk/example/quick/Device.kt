package com.supremainc.sdk.example.quick

import com.supremainc.sdk.example.device.DeviceSvc
import com.supremainc.sdk.device.CapabilityInfo

suspend fun deviceTest(deviceSvc: DeviceSvc, deviceID: Int): CapabilityInfo {
  var factoryInfo = deviceSvc.getInfo(deviceID)

  println("Device info: $factoryInfo")

  var capabilityInfo = deviceSvc.getCapabilityInfo(deviceID)

  println("Capability info: $capabilityInfo")

  return capabilityInfo
}