plugins {
    application
    kotlin("jvm")
}

dependencies {
    implementation(kotlin("stdlib"))
    implementation(project(":stub"))
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.3.8")

    api("com.google.protobuf:protobuf-java-util:${rootProject.ext["protobufVersion"]}")

    implementation("io.grpc:grpc-netty-shaded:${rootProject.ext["grpcVersion"]}")
}

sourceSets.main {
    java.srcDirs("../example/src/main/java", "../example/src/main/kotlin", "src/main/kotlin")
}

tasks.register<JavaExec>("QuickStart") {
    dependsOn("classes")
    classpath = sourceSets["main"].runtimeClasspath
    main = "com.supremainc.sdk.example.quick.QuickStartKt"
}

val quickStartStartScripts = tasks.register<CreateStartScripts>("quickStartStartScripts") {
    mainClassName = "com.supremainc.sdk.example.quick.QuickStartKt"
    applicationName = "quick-start"
    outputDir = tasks.named<CreateStartScripts>("startScripts").get().outputDir
    classpath = tasks.named<CreateStartScripts>("startScripts").get().classpath
}

tasks.named("startScripts") {
    dependsOn(quickStartStartScripts)
}
