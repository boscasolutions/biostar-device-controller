package com.supremainc.sdk.example.face

import io.grpc.ManagedChannel
import com.google.protobuf.ByteString
import com.supremainc.sdk.face.FaceGrpcKt.FaceCoroutineStub
import com.supremainc.sdk.face.GetConfigRequest
import com.supremainc.sdk.face.FaceConfig
import com.supremainc.sdk.face.FaceData
import com.supremainc.sdk.face.FaceEnrollThreshold
import com.supremainc.sdk.face.ScanRequest

class FaceSvc(private val channel: ManagedChannel) {
  private val stub: FaceCoroutineStub = FaceCoroutineStub(channel)

  suspend fun getConfig(deviceID: Int): FaceConfig {
    var request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getConfig(request)

    return response.getConfig()
  }

  suspend fun scan(deviceID: Int, enrollThreshold: FaceEnrollThreshold): FaceData {
    var request = ScanRequest.newBuilder().setDeviceID(deviceID).setEnrollThreshold(enrollThreshold).build()
    var response = stub.scan(request)

    return response.getFaceData()
  } 
}
