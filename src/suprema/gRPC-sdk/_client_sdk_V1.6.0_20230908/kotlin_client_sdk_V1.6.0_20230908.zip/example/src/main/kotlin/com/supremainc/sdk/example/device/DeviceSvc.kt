package com.supremainc.sdk.example.device

import io.grpc.ManagedChannel
import com.supremainc.sdk.device.DeviceGrpcKt.DeviceCoroutineStub
import com.supremainc.sdk.device.FactoryInfo
import com.supremainc.sdk.device.GetInfoRequest
import com.supremainc.sdk.device.DeviceCapability
import com.supremainc.sdk.device.GetCapabilityRequest
import com.supremainc.sdk.device.CapabilityInfo
import com.supremainc.sdk.device.GetCapabilityInfoRequest

class DeviceSvc(private val channel: ManagedChannel) {
  private val stub: DeviceCoroutineStub = DeviceCoroutineStub(channel)

  suspend fun getInfo(deviceID: Int): FactoryInfo {
    var request = GetInfoRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getInfo(request)

    return response.getInfo()
  }

  suspend fun getCapability(deviceID: Int): DeviceCapability {
    var request = GetCapabilityRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getCapability(request)

    return response.getDeviceCapability()
  }

  suspend fun getCapabilityInfo(deviceID: Int): CapabilityInfo {
    var request = GetCapabilityInfoRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getCapabilityInfo(request)

    return response.getCapInfo()
  }
}
