package com.supremainc.sdk.example.finger

import io.grpc.ManagedChannel
import com.google.protobuf.ByteString
import com.supremainc.sdk.finger.FingerGrpcKt.FingerCoroutineStub
import com.supremainc.sdk.finger.TemplateFormat
import com.supremainc.sdk.finger.ScanRequest
import com.supremainc.sdk.finger.GetImageRequest
import com.supremainc.sdk.finger.GetConfigRequest
import com.supremainc.sdk.finger.FingerConfig

class FingerSvc(private val channel: ManagedChannel) {
  private val stub: FingerCoroutineStub = FingerCoroutineStub(channel)

  suspend fun scan(deviceID: Int, templateFormat: TemplateFormat, qualityThreshold: Int): ByteString {
    var request = ScanRequest.newBuilder().setDeviceID(deviceID).setTemplateFormat(templateFormat).setQualityThreshold(qualityThreshold).build()
    var response = stub.scan(request)

    println("Template Score: ${response.getQualityScore()}")

    return response.getTemplateData()
  } 

  suspend fun getImage(deviceID: Int): ByteString {
    var request = GetImageRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getImage(request)

    return response.getBMPImage()
  } 

  suspend fun getConfig(deviceID: Int): FingerConfig {
    var request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getConfig(request)

    return response.getConfig()
  }
}
