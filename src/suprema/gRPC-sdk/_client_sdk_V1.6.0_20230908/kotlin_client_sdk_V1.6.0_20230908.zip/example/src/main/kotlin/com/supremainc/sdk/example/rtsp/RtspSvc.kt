package com.supremainc.sdk.example.rtsp

import io.grpc.ManagedChannel
import com.google.protobuf.ByteString
import com.supremainc.sdk.rtsp.RTSPGrpcKt.RTSPCoroutineStub
import com.supremainc.sdk.rtsp.GetConfigRequest
import com.supremainc.sdk.rtsp.RTSPConfig

class RtspSvc(private val channel: ManagedChannel) {
  private val stub: RTSPCoroutineStub = RTSPCoroutineStub(channel)

  suspend fun getConfig(deviceID: Int): RTSPConfig {
    var request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getConfig(request)

    return response.getConfig()
  }
}
