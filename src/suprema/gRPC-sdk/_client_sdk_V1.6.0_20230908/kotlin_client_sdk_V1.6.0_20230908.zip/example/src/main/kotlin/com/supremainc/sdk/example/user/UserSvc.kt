package com.supremainc.sdk.example.user

import io.grpc.ManagedChannel
import com.google.protobuf.ByteString
import com.supremainc.sdk.user.UserGrpcKt.UserCoroutineStub
import com.supremainc.sdk.user.UserHdr
import com.supremainc.sdk.user.GetListRequest
import com.supremainc.sdk.user.UserInfo
import com.supremainc.sdk.user.GetRequest
import com.supremainc.sdk.user.EnrollRequest
import com.supremainc.sdk.user.UpdateRequest
import com.supremainc.sdk.user.DeleteRequest
import com.supremainc.sdk.user.UserFinger
import com.supremainc.sdk.user.SetFingerRequest
import com.supremainc.sdk.user.UserFace
import com.supremainc.sdk.user.SetFaceRequest

class UserSvc(private val channel: ManagedChannel) {
  private val stub: UserCoroutineStub = UserCoroutineStub(channel)

  suspend fun getList(deviceID: Int): List<UserHdr> {
    var request = GetListRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getList(request)

    return response.getHdrsList()
  } 

  suspend fun getUser(deviceID: Int, userIDs: List<String>): List<UserInfo> {
    var request = GetRequest.newBuilder().setDeviceID(deviceID).addAllUserIDs(userIDs).build()
    var response = stub.get(request)

    return response.getUsersList()
  } 

  suspend fun enroll(deviceID: Int, users: List<UserInfo>) {
    var request = EnrollRequest.newBuilder().setDeviceID(deviceID).addAllUsers(users).build()
    stub.enroll(request)
  } 

  suspend fun update(deviceID: Int, users: List<UserInfo>) {
    var request = UpdateRequest.newBuilder().setDeviceID(deviceID).addAllUsers(users).build()
    stub.update(request)
  } 

  suspend fun delete(deviceID: Int, userIDs: List<String>) {
    var request = DeleteRequest.newBuilder().setDeviceID(deviceID).addAllUserIDs(userIDs).build()
    stub.delete(request)
  } 

  suspend fun setFinger(deviceID: Int, userFingers: List<UserFinger>) {
    var request = SetFingerRequest.newBuilder().setDeviceID(deviceID).addAllUserFingers(userFingers).build()
    stub.setFinger(request)
  } 

  suspend fun setFace(deviceID: Int, userFaces: List<UserFace>) {
    var request = SetFaceRequest.newBuilder().setDeviceID(deviceID).addAllUserFaces(userFaces).build()
    stub.setFace(request)
  } 
}
