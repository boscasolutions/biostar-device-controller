package com.supremainc.sdk.example.connect

import io.grpc.ManagedChannel
import com.supremainc.sdk.connect.ConnectGrpcKt.ConnectCoroutineStub
import com.supremainc.sdk.connect.DeviceInfo
import com.supremainc.sdk.connect.GetDeviceListRequest
import com.supremainc.sdk.connect.ConnectRequest
import com.supremainc.sdk.connect.DisconnectAllRequest
import com.supremainc.sdk.connect.ConnectInfo

class ConnectSvc(private val channel: ManagedChannel) {
  private val stub: ConnectCoroutineStub = ConnectCoroutineStub(channel)

  suspend fun getDeviceList(): List<DeviceInfo> {
    var request = GetDeviceListRequest.newBuilder().build()
    var response = stub.getDeviceList(request)

    return response.getDeviceInfosList()
  }

  suspend fun connect(connInfo: ConnectInfo): Int {
    var request = ConnectRequest.newBuilder().setConnectInfo(connInfo).build()
    var response = stub.connect(request)

    return response.getDeviceID()
  }

  suspend fun disconnectAll() {
    var request = DisconnectAllRequest.newBuilder().build()
    stub.disconnectAll(request)
  }
}
