package com.supremainc.sdk.example.display

import io.grpc.ManagedChannel
import com.google.protobuf.ByteString
import com.supremainc.sdk.display.DisplayGrpcKt.DisplayCoroutineStub
import com.supremainc.sdk.display.GetConfigRequest
import com.supremainc.sdk.display.DisplayConfig

class DisplaySvc(private val channel: ManagedChannel) {
  private val stub: DisplayCoroutineStub = DisplayCoroutineStub(channel)

  suspend fun getConfig(deviceID: Int): DisplayConfig {
    var request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getConfig(request)

    return response.getConfig()
  }
}
