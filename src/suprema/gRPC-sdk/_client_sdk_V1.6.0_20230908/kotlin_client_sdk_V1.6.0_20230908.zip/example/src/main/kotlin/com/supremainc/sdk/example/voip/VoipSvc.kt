package com.supremainc.sdk.example.voip

import io.grpc.ManagedChannel
import com.google.protobuf.ByteString
import com.supremainc.sdk.voip.VOIPGrpcKt.VOIPCoroutineStub
import com.supremainc.sdk.voip.GetConfigRequest
import com.supremainc.sdk.voip.VOIPConfig

class VoipSvc(private val channel: ManagedChannel) {
  private val stub: VOIPCoroutineStub = VOIPCoroutineStub(channel)

  suspend fun getConfig(deviceID: Int): VOIPConfig {
    var request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getConfig(request)

    return response.getConfig()
  }
}
