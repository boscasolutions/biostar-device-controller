package com.supremainc.sdk.example.card

import io.grpc.ManagedChannel
import com.google.protobuf.ByteString
import com.supremainc.sdk.card.CardGrpcKt.CardCoroutineStub
import com.supremainc.sdk.card.CardData
import com.supremainc.sdk.card.ScanRequest
import com.supremainc.sdk.card.BlacklistItem
import com.supremainc.sdk.card.GetBlacklistRequest
import com.supremainc.sdk.card.AddBlacklistRequest
import com.supremainc.sdk.card.DeleteBlacklistRequest
import com.supremainc.sdk.card.GetConfigRequest
import com.supremainc.sdk.card.CardConfig
import com.supremainc.sdk.card.GetQRConfigRequest
import com.supremainc.sdk.card.QRConfig

class CardSvc(private val channel: ManagedChannel) {
  private val stub: CardCoroutineStub = CardCoroutineStub(channel)

  suspend fun scan(deviceID: Int): CardData {
    var request = ScanRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.scan(request)

    return response.getCardData()
  } 

  suspend fun getBlacklist(deviceID: Int): List<BlacklistItem> {
    var request = GetBlacklistRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getBlacklist(request)

    return response.getBlacklistList()
  } 

  suspend fun addBlacklist(deviceID: Int, cardInfos: List<BlacklistItem>) {
    var request = AddBlacklistRequest.newBuilder().setDeviceID(deviceID).addAllCardInfos(cardInfos).build()
    stub.addBlacklist(request)
  } 

  suspend fun deleteBlacklist(deviceID: Int, cardInfos: List<BlacklistItem>) {
    var request = DeleteBlacklistRequest.newBuilder().setDeviceID(deviceID).addAllCardInfos(cardInfos).build()
    stub.deleteBlacklist(request)
  } 

  suspend fun getConfig(deviceID: Int): CardConfig {
    var request = GetConfigRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getConfig(request)

    return response.getConfig()
  }

  suspend fun getQRConfig(deviceID: Int): QRConfig {
    var request = GetQRConfigRequest.newBuilder().setDeviceID(deviceID).build()
    var response = stub.getQRConfig(request)

    return response.getConfig()
  }
}
