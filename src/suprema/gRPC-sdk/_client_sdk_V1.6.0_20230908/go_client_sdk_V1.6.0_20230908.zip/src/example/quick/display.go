package main

import (
	"fmt"
)

func testDisplay(deviceID uint32) error {
	displayConfig, err := displaySvc.GetConfig(deviceID)

	if err != nil {
		return err
	}

	fmt.Printf("Display config: %v\n\n", displayConfig)

	return nil
}
