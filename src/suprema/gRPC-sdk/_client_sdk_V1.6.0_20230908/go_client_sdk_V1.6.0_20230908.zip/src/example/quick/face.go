package main

import (
	"fmt"
	"io/ioutil"
)

const (
	FACE_IMAGE_NAME = "./face.bmp"
)

func testFace(deviceID uint32) error {
	faceConfig, err := faceSvc.GetConfig(deviceID)

	if err != nil {
		return err
	}

	fmt.Printf("Face config: %v\n\n", faceConfig)

	fmt.Printf(">>> Scan a face...\n")

	faceData, err := faceSvc.Scan(deviceID, faceConfig.EnrollThreshold)

	if err != nil {
		return err
	}

	for i := 0; i < len(faceData.Templates); i++ {
		fmt.Printf("Template[%d]: %v\n\n", i, faceData.Templates[i])
	}

	ioutil.WriteFile(FACE_IMAGE_NAME, faceData.ImageData, 0644)

	return nil
}
