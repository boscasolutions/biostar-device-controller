package main

import (
	"biostar/service/device"
	"fmt"
)

func testDevice(deviceID uint32) (*device.CapabilityInfo, error) {
	devInfo, err := deviceSvc.GetInfo(deviceID)

	if err != nil {
		return nil, err
	}

	fmt.Printf("Device info: %v\n\n", devInfo)

	capabilityInfo, err := deviceSvc.GetCapabilityInfo(deviceID)

	if err != nil {
		return nil, err
	}

	fmt.Printf("Capability info: %v\n\n", capabilityInfo)

	return capabilityInfo, nil
}
