package rtsp

import (
	"biostar/service/rtsp"
	"context"
	"fmt"

	"google.golang.org/grpc"
)

type RtspSvc struct {
	client rtsp.RTSPClient
}

func NewRtspSvc(conn *grpc.ClientConn) *RtspSvc {
	return &RtspSvc{
		client: rtsp.NewRTSPClient(conn),
	}
}

func (s *RtspSvc) GetConfig(deviceID uint32) (*rtsp.RTSPConfig, error) {
	req := &rtsp.GetConfigRequest{
		DeviceID: deviceID,
	}

	resp, err := s.client.GetConfig(context.Background(), req)

	if err != nil {
		fmt.Printf("Cannot get the rtsp config: %v\n", err)

		return nil, err
	}

	return resp.GetConfig(), nil
}

func (s *RtspSvc) SetConfig(deviceID uint32, config *rtsp.RTSPConfig) error {
	req := &rtsp.SetConfigRequest{
		DeviceID: deviceID,
		Config:   config,
	}

	_, err := s.client.SetConfig(context.Background(), req)

	if err != nil {
		fmt.Printf("Cannot set the rtsp config: %v\n", err)

		return err
	}

	return nil
}
