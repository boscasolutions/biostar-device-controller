package main

import (
	"biostar/service/rtsp"
	"example/cli"
	"fmt"

	"github.com/golang/protobuf/proto"
)

func testConfig(deviceID uint32, config *rtsp.RTSPConfig) error {
	// Backup the original configuration
	origConfig := proto.Clone(config)

	// Set options for the test
	config.ServerURL = "rtsp.server.com"
	config.ServerPort = 554
	config.UserID = "RTSP User ID"
	config.UserPW = "2378129307"
	config.Enabled = true

	fmt.Printf("\n===== Test for RTSPConfig =====\n\n")

	err := rtspSvc.SetConfig(deviceID, config)
	if err != nil {
		return err
	}

	config, err = rtspSvc.GetConfig(deviceID)

	if err != nil {
		return err
	}

	fmt.Printf("Rtsp Config: %+v\n\n", *config)

	cli.PressEnter(">> Press ENTER if you finish testing this mode.\n")

	// Restore the original configuration
	err = rtspSvc.SetConfig(deviceID, origConfig.(*rtsp.RTSPConfig))
	if err != nil {
		return err
	}

	return nil
}
