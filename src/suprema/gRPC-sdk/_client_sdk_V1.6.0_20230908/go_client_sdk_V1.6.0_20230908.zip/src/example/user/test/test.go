package main

import (
	"fmt"
	"os"

	"example/auth"
	"example/card"
	"example/client"
	"example/connect"
	"example/device"
	"example/event"
	"example/face"
	"example/finger"
	"example/user"
)

const (
	GATEWAY_CA_FILE = "../../../../../cert/gateway/ca.crt"
	GATEWAY_IP      = "192.168.8.98"
	GATEWAY_PORT    = 4000

	DEV_IP   = "192.168.8.227"
	DEV_PORT = 51211
	USE_SSL  = false

	CODE_MAP_FILE = "../../event/event_code.json"
)

var (
	connectSvc *connect.ConnectSvc
	deviceSvc  *device.DeviceSvc

	userSvc   *user.UserSvc
	cardSvc   *card.CardSvc
	authSvc   *auth.AuthSvc
	eventSvc  *event.EventSvc
	fingerSvc *finger.FingerSvc
	faceSvc   *face.FaceSvc
)

func main() {
	gatewayClient := &client.GatewayClient{}

	err := gatewayClient.Connect(GATEWAY_CA_FILE, GATEWAY_IP, GATEWAY_PORT)
	if err != nil {
		fmt.Printf("Cannot connect the device gateway: %v", err)
		os.Exit(1)
	}

	connectSvc = connect.NewConnectSvc(gatewayClient.GetConn())

	deviceID, err := connectSvc.Connect(DEV_IP, DEV_PORT, USE_SSL)

	if err != nil {
		fmt.Printf("Cannot connect the device: %v", err)
		gatewayClient.Close()
		os.Exit(1)
	}

	userSvc = user.NewUserSvc(gatewayClient.GetConn())
	deviceSvc = device.NewDeviceSvc(gatewayClient.GetConn())
	authSvc = auth.NewAuthSvc(gatewayClient.GetConn())
	eventSvc = event.NewEventSvc(gatewayClient.GetConn())
	eventSvc.InitCodeMap(CODE_MAP_FILE)

	capability, err := deviceSvc.GetCapability(deviceID)

	if err != nil {
		fmt.Printf("Cannot get the device info: %v", err)
		gatewayClient.Close()
		os.Exit(1)
	}

	origAuthConfig, err := prepareAuthConfig(deviceID)

	if err != nil {
		fmt.Printf("Cannot set the auth config: %v", err)
		gatewayClient.Close()
		os.Exit(1)
	}

	testUserID, err := enrollUser(deviceID, capability.ExtendedAuthSupported)

	if err != nil {
		fmt.Printf("Cannot enroll a test user: %v", err)
		restoreAuthConfig(deviceID, origAuthConfig)
		gatewayClient.Close()
		os.Exit(1)
	}

	if capability.CardInputSupported {
		cardSvc = card.NewCardSvc(gatewayClient.GetConn())
		testCard(deviceID, testUserID)
	} else {
		fmt.Printf("!! The device %v does not support cards. Skip the card test.\n", deviceID)
	}

	if capability.FingerprintInputSupported {
		fingerSvc = finger.NewFingerSvc(gatewayClient.GetConn())
		testFinger(deviceID, testUserID)
	} else {
		fmt.Printf("!! The device %v does not support fingerprints. Skip the fingerprint test.\n", deviceID)
	}

	if capability.FaceInputSupported {
		faceSvc = face.NewFaceSvc(gatewayClient.GetConn())
		testFace(deviceID, testUserID)
	} else {
		fmt.Printf("!! The device %v does not support faces. Skip the face test.\n", deviceID)
	}

	testAuthMode(deviceID, capability.ExtendedAuthSupported)

	printUserLog(deviceID, testUserID)

	restoreAuthConfig(deviceID, origAuthConfig)
	deleteUser(deviceID, testUserID)

	connectSvc.Disconnect([]uint32{deviceID})
	gatewayClient.Close()
}
