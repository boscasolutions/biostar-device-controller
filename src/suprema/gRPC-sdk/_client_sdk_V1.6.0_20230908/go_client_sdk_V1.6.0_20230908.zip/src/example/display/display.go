package display

import (
	"biostar/service/display"
	"context"
	"fmt"

	"google.golang.org/grpc"
)

type DisplaySvc struct {
	client display.DisplayClient
}

func NewDisplaySvc(conn *grpc.ClientConn) *DisplaySvc {
	return &DisplaySvc{
		client: display.NewDisplayClient(conn),
	}
}

func (s *DisplaySvc) GetConfig(deviceID uint32) (*display.DisplayConfig, error) {
	req := &display.GetConfigRequest{
		DeviceID: deviceID,
	}

	resp, err := s.client.GetConfig(context.Background(), req)

	if err != nil {
		fmt.Printf("Cannot get the display config: %v\n", err)

		return nil, err
	}

	return resp.GetConfig(), nil
}
