package main

import (
	"biostar/service/voip"
	"example/cli"
	"fmt"

	"github.com/golang/protobuf/proto"
)

func testConfig(deviceID uint32, config *voip.VOIPConfig) error {
	// Backup the original configuration
	origConfig := proto.Clone(config)

	// Set options for the test
	config.ServerURL = "voip.server.com"
	config.ServerPort = 554
	config.UserID = "VOIP User ID"
	config.UserPW = "2378129307"
	config.Enabled = true

	fmt.Printf("\n===== Test for VOIPConfig =====\n\n")

	err := voipSvc.SetConfig(deviceID, config)
	if err != nil {
		return err
	}

	config, err = voipSvc.GetConfig(deviceID)

	if err != nil {
		return err
	}

	fmt.Printf("Voip Config: %+v\n\n", *config)

	cli.PressEnter(">> Press ENTER if you finish testing this mode.\n")

	// Restore the original configuration
	err = voipSvc.SetConfig(deviceID, origConfig.(*voip.VOIPConfig))
	if err != nil {
		return err
	}

	return nil
}
