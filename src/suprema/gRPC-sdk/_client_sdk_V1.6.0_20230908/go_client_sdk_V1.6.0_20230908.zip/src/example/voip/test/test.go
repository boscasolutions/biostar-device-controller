package main

import (
	"fmt"
	"os"

	"example/client"
	"example/connect"
	"example/voip"
)

const (
	GATEWAY_CA_FILE = "../../../../../cert/gateway/ca.crt"
	GATEWAY_IP      = "192.168.8.98"
	GATEWAY_PORT    = 4000

	DEV_IP   = "192.168.8.236"
	DEV_PORT = 51211
	USE_SSL  = false

	CODE_MAP_FILE = "../../event/event_code.json"
)

var (
	connectSvc *connect.ConnectSvc

	voipSvc *voip.VoipSvc
)

func main() {
	gatewayClient := &client.GatewayClient{}

	err := gatewayClient.Connect(GATEWAY_CA_FILE, GATEWAY_IP, GATEWAY_PORT)
	if err != nil {
		fmt.Printf("Cannot connect the device gateway: %v", err)
		os.Exit(1)
	}

	connectSvc = connect.NewConnectSvc(gatewayClient.GetConn())

	deviceID, err := connectSvc.Connect(DEV_IP, DEV_PORT, USE_SSL)

	if err != nil {
		fmt.Printf("Cannot connect the device: %v", err)
		gatewayClient.Close()
		os.Exit(1)
	}

	voipSvc = voip.NewVoipSvc(gatewayClient.GetConn())
	voipConfig, err := voipSvc.GetConfig(deviceID)

	if err != nil {
		fmt.Printf("Voip service is not supported by the device %v: %v", deviceID, err)
		connectSvc.Disconnect([]uint32{deviceID})
		gatewayClient.Close()

		os.Exit(1)
	}

	fmt.Printf("Original Voip Config: %+v\n\n", *voipConfig)

	testConfig(deviceID, voipConfig)

	connectSvc.Disconnect([]uint32{deviceID})
	gatewayClient.Close()
}
