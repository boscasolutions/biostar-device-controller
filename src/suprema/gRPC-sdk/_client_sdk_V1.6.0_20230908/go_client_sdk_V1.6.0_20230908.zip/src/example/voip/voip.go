package voip

import (
	"biostar/service/voip"
	"context"
	"fmt"

	"google.golang.org/grpc"
)

type VoipSvc struct {
	client voip.VOIPClient
}

func NewVoipSvc(conn *grpc.ClientConn) *VoipSvc {
	return &VoipSvc{
		client: voip.NewVOIPClient(conn),
	}
}

func (s *VoipSvc) GetConfig(deviceID uint32) (*voip.VOIPConfig, error) {
	req := &voip.GetConfigRequest{
		DeviceID: deviceID,
	}

	resp, err := s.client.GetConfig(context.Background(), req)

	if err != nil {
		fmt.Printf("Cannot get the voip config: %v\n", err)

		return nil, err
	}

	return resp.GetConfig(), nil
}

func (s *VoipSvc) SetConfig(deviceID uint32, config *voip.VOIPConfig) error {
	req := &voip.SetConfigRequest{
		DeviceID: deviceID,
		Config:   config,
	}

	_, err := s.client.SetConfig(context.Background(), req)

	if err != nil {
		fmt.Printf("Cannot set the voip config: %v\n", err)

		return err
	}

	return nil
}
